RunAutoDailyProcess();

async function RunAutoDailyProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoFood();
}

async function InjectAutoFood(){
    const isAutoDailyEnabled = await IsAutoDailyEnabled();

    if(!isAutoDailyEnabled){
        CloseWindow();
        return;
    }

    setDEFAULT("HAS_FOOD_QUEST", false);
    setDEFAULT("FOOD_ITEM", "");

    const URL = window.location.href,
          hasFoodQuest = await getVARIABLE("HAS_FOOD_QUEST");

    if(!hasFoodQuest) return;

    const itemName = await getVARIABLE("FOOD_ITEM");

    if(URL.includes("inventory")){
        InventoryConsumeItem(itemName, "Feed to", "HAS_FOOD_QUEST", "FOOD_ITEM", "https://www.neopets.com/generalstore.phtml");
    } else {
        if(itemName == ""){
            setVARIABLE("FOOD_ITEM", "Coffee and Marshmallows");

            GeneralStorePushForm();
        } else {
            window.location.href = "https://www.neopets.com/inventory.phtml";
        }
    }
}

