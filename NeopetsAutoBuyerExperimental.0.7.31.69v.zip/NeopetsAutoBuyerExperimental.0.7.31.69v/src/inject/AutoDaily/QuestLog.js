RunAutoDailyProcess();

async function RunAutoDailyProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoDaily();
}

async function InjectAutoDaily(){
    const isAutoDailyEnabled = await IsAutoDailyEnabled();

    if(!isAutoDailyEnabled) return;

    const currentDate = TimezoneDate(new Date()).toDateString();

    setDEFAULT("AUTODAILY_LIST", []);

    var endOfWeekPrize,
        prizesOfInterestList = await getVARIABLE("AUTODAILY_LIST");

    try {
        endOfWeekPrize = document.querySelector(".ql-bonus-item").textContent;
    } catch {
        // 100K NPs prize;
        endOfWeekPrize = document.querySelector(".ql-bonus-amt").textContent;
    }

    if(!prizesOfInterestList.includes(endOfWeekPrize)){
        const lastDateChecked = await getVARIABLE("LAST_DATE_CHECKED");

        if(lastDateChecked != currentDate){
            setVARIABLE("LAST_DATE_CHECKED", currentDate);
            await Sleep(500);
            CloseWindow();
        }

        return;
    }

    const quests = document.querySelectorAll(".ql-quest-details"),
          questPrizes = document.querySelectorAll(".ql-reward-label");

    const minWaitToClickClaimButton = await getVARIABLE("MIN_WAIT_ACCEPT_QUEST"),
    maxWaitToClickClaimButton = await getVARIABLE("MAX_WAIT_ACCEPT_QUEST");

    ProcessQuests();
    CompleteQuests();

    const claimDailyRewardButton = document.getElementById("QuestLogDailyAlert"),
          hasNotClaimedDaily = !claimDailyRewardButton.classList.contains("ql-bonus-check");

    // If all quests have been claimed, then claim the daily;
    if(quests.length == 0){
        setVARIABLE("LAST_DATE_CHECKED", currentDate);

        if(hasNotClaimedDaily){
            claimDailyRewardButton.click();
    
            await Sleep(minWaitToClickClaimButton, maxWaitToClickClaimButton);
    
            window.location.reload();
        }
    }

    async function CompleteQuests(){
        setDEFAULT("AUTODAILY_TRACKER", []);

        var history = await getVARIABLE("AUTODAILY_TRACKER");

        const accountName = GetAccountName();

        setDEFAULT("MIN_WAIT_ACCEPT_QUEST", 2000);
        setDEFAULT("MAX_WAIT_ACCEPT_QUEST", 5000);

        for(var i = 0; i < quests.length; i++){
            const quest = quests[i],
                  title = quest.querySelector(".ql-quest-title").textContent,
                  claimQuestButton = quest.querySelector(".ql-claim");

            var type, prize = questPrizes[i].textContent;

            if(prize.includes("NP")) prize = "Neopoints";

            switch(title){
                default: type = 0; break;
                case "Spin the Wheel": type = 1; break;
                case "Play a Game": type = 2; break;
                case "Feed a Pet": type = 3; break;
                case "Groom a Pet": type = 4; break;
                case "Customise a Pet": type = 5; break;
            }

            var entry = {
                "Account": accountName,
                "Date & Time": new Date().toLocaleString(),
                "Quest Type": type,
                "Prize": prize,
            };

            await Sleep(minWaitToClickClaimButton, maxWaitToClickClaimButton);

            claimQuestButton.click();
            history.push(entry);
            setVARIABLE("AUTODAILY_TRACKER", history);
        }

        setVARIABLE("COMPLETED_DATE", new Date());

        var clickClaimButton = setInterval(function(){
            const claimRewardButton = document.querySelector(".ql-bonus-claim"),
                  claimedRewardCheck = document.querySelector(".ql-bonus-check");

            if(claimRewardButton) {
                claimRewardButton.click();
                clearInterval(clickClaimButton);
            } else if(claimedRewardCheck) {
                clearInterval(clickClaimButton);
            }
        }, 1000);
    }
    
    function ProcessQuests(){
        for(var i = 0; i < quests.length; i++){
            const quest = quests[i];

            const description = quest.querySelector(".ql-task-description"),
                text = description.textContent,
                claimQuestButton = quest.querySelector(".ql-claim");
    
            if(claimQuestButton.hasAttribute("disabled")){
                switch (text){
                    case "Purchase Item(s)":
                        setDEFAULT("ITEMS_TO_PURCHASE_TODAY", 0);
                        setDEFAULT("ITEMS_PURCHASED_TODAY", 0);
                        setDEFAULT("HAS_PURCHASE_QUEST", false);
    
                        var itemsToBuyToday = 1;
                        
                        console.log(itemsToBuyToday);

                        try { 
                            itemsToBuyToday = quest.querySelector(".ql-task-num").textContent;
                            itemsToBuyToday = itemsToBuyToday.split("/")[1]; 
                        } catch { itemsToBuyToday = 1; }
    
                        setVARIABLE("ITEMS_TO_PURCHASE_TODAY", itemsToBuyToday);
                        setVARIABLE("ITEMS_PURCHASED_TODAY", 0);
                        setVARIABLE("HAS_PURCHASE_QUEST", true);
    
                        window.location.href = "https://www.neopets.com/generalstore.phtml";

                        return;
                    break;
            
                    case "Play a game":
                        console.log("Game!");
                    break;
    
                    case "Feed your Neopet":
                        setDEFAULT("HAS_FOOD_QUEST", false);
                        setDEFAULT("FOOD_ITEM", "");
    
                        window.location.href = "https://www.neopets.com/inventory.phtml";
    
                        setVARIABLE("HAS_FOOD_QUEST", true);
                        setVARIABLE("FOOD_ITEM", "Coffee and Marshmallows");

                        return;
                    break;
            
                    case "Groom your Neopet":
                        setDEFAULT("HAS_GROOMING_QUEST", false);
    
                        setVARIABLE("HAS_GROOMING_QUEST", true);
                        window.location.href = "https://www.neopets.com/safetydeposit.phtml?obj_name=&category=10";

                        return;
                    break;
            
                    case "Customise your Neopet":
                        setDEFAULT("HAS_CUSTOMIZE_QUEST", false);
    
                        setVARIABLE("HAS_CUSTOMIZE_QUEST", true);
                        setVARIABLE("HAS_REMOVED_CLOTHES", false);
                        window.location.href = "https://www.neopets.com/customise/";

                        return;
                    break;
            
                    // Wheels;
                    default:
                        var wheel = text.replace("Spin the Wheel of ", "").split(" in")[0];
    
                        switch(wheel){
                            case "Excitement":
                                window.location.href = "https://www.neopets.com/faerieland/wheel.phtml";
                            break;
    
                            case "Knowledge":
                                window.location.href = "https://www.neopets.com/medieval/knowledge.phtml";
                            break;
    
                            case "Mediocrity":
                                window.location.href = "https://www.neopets.com/prehistoric/mediocrity.phtml";
                            break;
    
                            case "Misfortune":
                                window.location.href = "https://www.neopets.com/halloween/wheel/index.phtml";
                            break;
                        }
    
                        setVARIABLE("SPINNING_WHEEL_TYPE", wheel);

                        return;
                    break;
                }
            }
        };
    }
}

