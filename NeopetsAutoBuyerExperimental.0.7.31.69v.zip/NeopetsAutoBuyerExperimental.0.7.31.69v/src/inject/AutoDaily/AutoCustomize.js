RunAutoSDBProcess();

async function RunAutoSDBProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoCustomize();
}

async function InjectAutoCustomize(){
    const isAutoDailyEnabled = await IsAutoDailyEnabled();

    if(!isAutoDailyEnabled){
        CloseWindow();
        return;
    }

    setDEFAULT("HAS_REMOVED_CLOTHES", false);
    setDEFAULT("HAS_CUSTOMIZE_QUEST", false);
    
    const hasCustomizeQuest = await getVARIABLE("HAS_CUSTOMIZE_QUEST"),
          hasRemovedClothes = await getVARIABLE("HAS_REMOVED_CLOTHES");

    const clickEvent = GenerateMouseEvent();

    if(!hasCustomizeQuest) return;

    if(hasRemovedClothes){
        const removedPiece = await getVARIABLE("REMOVED_PIECE");

        await Sleep(5000);

        const clothingItems = await WaitForElement(".ddcontainer", 3);

        const selectedPiece = Array.from(clothingItems).filter(item => item.innerText.includes(removedPiece))[0],
              dropArea = await WaitForElement(".droptarget"); 

        SimulateDragAndDrop(selectedPiece, dropArea);

        await ClickSaveButton();

        setVARIABLE("REMOVED_PIECE", "");
        setVARIABLE("HAS_REMOVED_CLOTHES", false);
        setVARIABLE("HAS_CUSTOMIZE_QUEST", false);

        window.location.href = "https://www.neopets.com/questlog/";
    } else {
        const wornButton = await WaitForElement("#npcma_neopetsCustomisationContainer > div > div > div.npcma-list_section > div.npcma-ryt_head > label > span.npcma-slider.npcma-round");

        wornButton.dispatchEvent(clickEvent);

        const wornText = await WaitForElement("#npcma_neopetsCustomisationContainer > div > div > div.npcma-list_section > span");

        await WaitForTextContent(wornText, "Worn");

        const wornItems = document.querySelector("#npcma_AppliedpetItems"),
            closeButtons = wornItems.querySelectorAll(".npcma-icon-close");

        const itemToRemove = closeButtons[0].parentElement.querySelector(".npcma-pet_name").textContent;
        setVARIABLE("REMOVED_PIECE", itemToRemove);

        closeButtons[0].dispatchEvent(clickEvent);

        await ClickSaveButton();

        setVARIABLE("HAS_REMOVED_CLOTHES", true);
        window.location.reload();
    }
}

// Function to simulate dragging an element to a target position
function SimulateDragAndDrop(source, target) {
    console.log(source, target);

    // Create the necessary events
    const dragStartEvent = new MouseEvent('mousedown', {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: source.getBoundingClientRect().left,
        clientY: source.getBoundingClientRect().top
    });

    const dragMoveEvent = new MouseEvent('mousemove', {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: target.getBoundingClientRect().left + target.offsetWidth / 2,
        clientY: target.getBoundingClientRect().top + target.offsetHeight / 2
    });

    const dragEndEvent = new MouseEvent('mouseup', {
        bubbles: true,
        cancelable: true,
        view: window,
        clientX: target.getBoundingClientRect().left + target.offsetWidth / 2,
        clientY: target.getBoundingClientRect().top + target.offsetHeight / 2
    });

    // Dispatch events
    source.dispatchEvent(dragStartEvent);
    document.dispatchEvent(dragMoveEvent);
    document.dispatchEvent(dragEndEvent);
}

async function ClickSaveButton(){
    return new Promise(async (resolve, reject) => {
        const saveButton = await WaitForElement(".npcma-icon-save-snap");
              saveButton.dispatchEvent(GenerateMouseEvent());

        await Sleep(1000);

        resolve();
    });
}