RunAutoDailyProcess();

async function RunAutoDailyProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoGroom();
}

async function InjectAutoGroom(){
    if(!(await IsAutoDailyEnabled())) return;

    const URL = window.location.href,
          hasGroomingQuest = await getVARIABLE("HAS_GROOMING_QUEST");

    if(!hasGroomingQuest) return;

    const savedItemName = await getVARIABLE("GROOMING_ITEM_NAME");

    if(URL.includes("safetydeposit")){
        if(savedItemName != ""){
            window.location.href = "https://www.neopets.com/inventory.phtml";
            return;
        }

        const sdbTable = document.querySelector("#content > table > tbody > tr > td.content > form > table:nth-child(3)"),
              rows = sdbTable.querySelectorAll("tr");

        const firstRow = rows[1];

        if(firstRow == null) return;

        setDEFAULT("GROOMING_ITEM_NAME", "");

        const itemName = firstRow.querySelector("b").textContent;
        setVARIABLE("GROOMING_ITEM_NAME", itemName);

        const inputRow = firstRow.querySelector("input");
        inputRow.value = 1;
        inputRow.setAttribute("data-remove_val", "y");

        const PINField = document.getElementById("pin_field");

        if(PINField) {
            const playerPIN = await getVARIABLE("NEOPETS_SECURITY_PIN");

            PINField.value = playerPIN;
        }

        const submitButton = document.querySelector("input.submit_data"),
              mouseEvent = GenerateMouseEvent();

        submitButton.dispatchEvent(mouseEvent);
    } else {
        InventoryConsumeItem(savedItemName, "Groom", "HAS_GROOMING_QUEST", "GROOMING_ITEM_NAME", "https://www.neopets.com/safetydeposit.phtml?obj_name=&category=10");
    }
}