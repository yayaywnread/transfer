RunAutoSDBProcess();

async function RunAutoSDBProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoPurchase();
}

async function InjectAutoPurchase(){
    const isAutoDailyEnabled = await IsAutoDailyEnabled();

    if(!isAutoDailyEnabled){
        CloseWindow();
        return;
    }

    setDEFAULT("ITEMS_TO_PURCHASE_TODAY", 0);
    setDEFAULT("ITEMS_PURCHASED_TODAY", 0);
    setDEFAULT("HAS_PURCHASE_QUEST", false);

    const itemsToPurchaseToday = await getVARIABLE("ITEMS_TO_PURCHASE_TODAY"),
          hasPurchaseQuest = await getVARIABLE("HAS_PURCHASE_QUEST");

    var itemsPurchasedToday = await getVARIABLE("ITEMS_PURCHASED_TODAY")

    if(itemsPurchasedToday >= itemsToPurchaseToday){
        if(hasPurchaseQuest){
            setVARIABLE("HAS_PURCHASE_QUEST", false);
            window.location.href = "https://www.neopets.com/questlog/";
        }
        return;
    } 

    if(PageIncludes("Congratulations, you just purchased")){
        window.location.href = "https://www.neopets.com/generalstore.phtml";

        setVARIABLE("ITEMS_PURCHASED_TODAY", ++itemsPurchasedToday);

        await Sleep(1000);
    } else {
        GeneralStorePushForm();
    }
}