RunAutoSDBProcess();

async function RunAutoSDBProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoDaily();
}

async function InjectAutoDaily(){
    if(!(await IsAutoDailyEnabled())) return;

    const wheelType = await getVARIABLE("SPINNING_WHEEL_TYPE");

    if(PageIncludes(wheelType)){
        for(var i = 0; i < 5; i++){
            var spinButton = await WaitForElement("#wheelButtonSpin");
            spinButton.dispatchEvent(GenerateMouseEvent());
            await Sleep(500);
        }

        setVARIABLE("SPINNING_WHEEL_TYPE", "nowheel");

        window.location.href = "https://www.neopets.com/questlog/";
    }
}