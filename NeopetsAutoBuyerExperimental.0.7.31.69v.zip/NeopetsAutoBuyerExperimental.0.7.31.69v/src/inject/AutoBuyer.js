RunAutoBuyerProcess();

async function RunAutoBuyerProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } else {
        setVARIABLE("HAS_UPDATE_ALERT_TRIGGERED", false);
    }

    HandleServerErrors();

    DisplayAutoBuyerBanner();

    InjectAutoBuyer();
}


//######################################################################################################################################


function InjectAutoBuyer() {
    chrome.storage.local.get({
        BUY_UNKNOWN_ITEMS_PROFIT: 1e5,
        ITEM_DB_MIN_RARITY: 1,
        USE_BLACKLIST: !1,
        BLACKLIST: [],
        ENABLED: !0,
        USE_ITEM_DB: !0,
        ITEM_DB_MIN_PROFIT_NPS: 1e4,
        ITEM_DB_MIN_PROFIT_PERCENT: .5,
        HIGHLIGHT: !0,
        CLICK_ITEM: !0,
        CLICK_CONFIRM: !0,
        SHOULD_BYPASS_CONFIRM: false,
        SHOULD_OPEN_NEW_TABS_FOR_HAGGLING: false,
        MIN_REFRESH: 3500,
        MAX_REFRESH: 5300,
        MIN_REFRESH_STOCKED: 37500,
        MAX_REFRESH_STOCKED: 45000,
        SHOULD_ONLY_REFRESH_ON_CLEAR: false,
        ITEMS_TO_CONSIDER_STOCKED: 1,
        MIN_CLICK_ITEM_IMAGE: 500,
        MAX_CLICK_ITEM_IMAGE: 1e3,
        MIN_CLICK_CONFIRM: 100,
        MAX_CLICK_CONFIRM: 200,
        STORES_TO_CYCLE_THROUGH_WHEN_STOCKED: [2, 58],
        RUN_AUTOBUYER_FROM_MS: 1712473200000,
		RUN_AUTOBUYER_TO_MS: 1712559599000,
        IS_DEFAULT_SHOP_TIME: true,
        PAUSE_BETWEEN_MINUTES: [],
        RESTOCK_LIST: defaultDesiredItems,
        SHOPS_SETTINGS: {
            "0": {
                "refreshWhenCleared": false,
                "goForSecond": false,
                "minRefresh": 37500,
                "maxRefresh": 45000,
                "minUnstockedRefresh": 3500,
                "maxUnstockedRefresh": 5000,
                "minItemsToConsiderStocked": 1,
            }
        },
    }, (async function(autobuyerVariables) {
        // Destructing the variables extracted from the extension;
        const {
            BUY_UNKNOWN_ITEMS_PROFIT: buyUnknownItemsIfProfitMargin,
            USE_BLACKLIST: isBlacklistActive,
            BLACKLIST: blacklist,
            ENABLED: isAutoBuyerEnabled,
            USE_ITEM_DB: isBuyingWithItemDB,
            ITEM_DB_MIN_PROFIT_NPS: minProfitNPs,
            ITEM_DB_MIN_PROFIT_PERCENT: minProfitPercent,
            HIGHLIGHT: isHighlightingItemsInShops,
            CLICK_ITEM: isClickingItems,
            CLICK_CONFIRM: isClickingConfirm,
            SHOULD_BYPASS_CONFIRM: isBypassingConfirm,
            SHOULD_OPEN_NEW_TABS_FOR_HAGGLING: isOpeningNewTabs,
            PAUSE_BETWEEN_MINUTES: pauseBetweenMinutes,
            MIN_CLICK_ITEM_IMAGE: minClickImageInterval,
            MAX_CLICK_ITEM_IMAGE: maxClickImageInterval,
            MIN_CLICK_CONFIRM: minClickConfirmInterval,
            MAX_CLICK_CONFIRM: maxClickConfirmInterval,
            RESTOCK_LIST: restockList,
            SHOPS_SETTINGS: shopSettings,
        } = autobuyerVariables;

        setDEFAULT("SHOPS_SETTINGS", {
            "0": {
                "refreshWhenCleared": false,
                "goForSecond": false,
                "minRefresh": 37500,
                "maxRefresh": 45000,
                "minUnstockedRefresh": 3500,
                "maxUnstockedRefresh": 5000,
                "minItemsToConsiderStocked": 1,
            }
        });

        var shopId = window.location.toString().match(/obj_type=(\d+)/)[1],
            settingsKeys = Object.keys(shopSettings),
            settings;
        // Selecting the default settings for shops not included in the dictionary;
        if(!settingsKeys.includes(shopId)){
            settings = shopSettings[0];
        } else {
            settings = shopSettings[shopId];
        }
        
        const minRefreshIntervalStocked = settings["minRefresh"],
              maxRefreshIntervalStocked = settings["maxRefresh"],
              minRefreshIntervalUnstocked = settings["minUnstockedRefresh"],
              maxRefreshIntervalUnstocked = settings["maxUnstockedRefresh"],
              isBuyingSecondMostProfitable = settings["goForSecond"],
              minItemsToConsiderStocked = settings["minItemsToConsiderStocked"],
              shouldOnlyRefreshOnClear = settings["refreshWhenCleared"];
        
        // Check if the user is in a main shop;
        if(!isAutoBuyerEnabled) return;

        // This includes the obelisk items too;
        var itemElements = Array.from(document.querySelectorAll(".item-img"));

        // Setting the bypass for shop items;
        if(isBypassingConfirm){
            // Define the confirmPurchase function in the webpage's global context
            window.confirmPurchase = function(item) {
                let link = item.dataset.link;

                if(isOpeningNewTabs) window.open(link, '_blank').focus();
                else window.location.href = link;
            };

            // Attach event listeners to each 'shop-item' element;
            itemElements.forEach(shopItem => shopItem.addEventListener('click', () => confirmPurchase(shopItem)));
        }

        // Filtering item information;
        var items = itemElements.map(element => {
            var itemName = element.getAttribute("data-name");
            var itemPrice = parseInt(element.getAttribute("data-price").replaceAll(",", ""));
            return {
                name: itemName,
                price: itemPrice,
            };
        });
        
        const mapNames = items.map((item) => item.name),
              mapPrices = items.map((item) => item.price);

        var itemProfits;
        
        var database

        if(isBuyingWithItemDB){
            database = await getVARIABLE("DATABASE");
            itemProfits = CalculateItemProfits(database, mapNames, mapPrices, buyUnknownItemsIfProfitMargin, isBlacklistActive, blacklist);
        } 
        
        const itemToBuyExtracted = GetBestItemToBuy();
        
        // GetBestItemToBuy(); Extracts the most valuable item to purchase from either the DB or the Restocking List;
        function GetBestItemToBuy() {
            var selectedName;

            if (isBuyingWithItemDB) {
                var bestIndexes = [];
                var maxProfit = -Infinity;

                // Reading the parsed items;
                for (var index = 0; index < items.length; index++) {
                    const item = items[index],
                          price = item.price;
                    
                    try {
                        const profit = itemProfits[index],
                          isProfitable = profit > minProfitNPs && profit / price > minProfitPercent;

                        // If it's profitable and above the profit percentage, mark it as a best item;
                        if (isProfitable) {
                            if (profit > maxProfit) {
                                maxProfit = profit;
                                bestIndexes = [index];
                            } else if (profit === maxProfit) {
                                bestIndexes.push(index);
                            }
                        }
                    } catch {}
                }           

                const bestItemCount = bestIndexes.length;
                
                // No best item to buy
                if (bestItemCount === 0) return;

                // Select the most profitable item based on settings;
                else if (bestItemCount === 1) selectedName = items[bestIndexes[0]].name;
                else if (isBuyingSecondMostProfitable && bestItemCount > 1) selectedName = items[bestIndexes[1]].name;
                else selectedName = items[bestIndexes[0]].name;
            } 
            
            //If the user is not using the item DB;
            else {
                // Assuming restockList is an array with the desired order;
                const filteredNames = restockList.filter((itemName) => mapNames.includes(itemName) && !IsItemInBlacklist(itemName, isBlacklistActive, blacklist));

                // If there are items to buy, pick the first one
                selectedName = PickSecondBestItem(filteredNames, isBuyingSecondMostProfitable);
            }

            if (selectedName) {
                var actionMessage,
                    detailedMessage;
            
                if (isClickingItems) {
                    actionMessage = `Buying ${selectedName}`;
                    detailedMessage = `Buying ${selectedName} from the main shop`;
                } else {
                    actionMessage = `${selectedName} is in stock`;
                    detailedMessage = `${selectedName} is in stock in the main shop`;
                }
            
                UpdateBannerAndDocument(actionMessage, detailedMessage);
            }
            
            return selectedName
        }

        var shopIntervals,
            confirmWindowInterval = 50;

        if (itemToBuyExtracted) {
            // Clicking the selected item;
            if (isClickingItems) {
                // Selecting the element;
                var itemToBuyElement = document.querySelector(`.item-img[data-name="${itemToBuyExtracted}"]`);
                await Sleep(minClickImageInterval, maxClickImageInterval);
                itemToBuyElement.click();
            }

            // Clicking the confirm window if there's an item to buy and the user is not bypassing the confirm screen;
            if (isClickingConfirm && !isBypassingConfirm) {
                var isClicked = false;

                clearInterval(shopIntervals);

                // Multi-click the button if possible;
                shopIntervals = setInterval(() => {
                    var confirmButton = document.getElementById("confirm-link");

                    if (confirmButton.offsetWidth || confirmButton.offsetHeight || confirmButton.getClientRects().length) {
                        setTimeout(() => {
                            if (!isClicked) {
                                confirmButton.click();
                                isClicked = true;
                            }
                        }, GetRandomFloat(minClickConfirmInterval, maxClickConfirmInterval));
                    }
                }, confirmWindowInterval);
            }
        } 
        // If there are no items to buy, then wait until the next refresh;
        else {            
            const now = new Date();
            const minutes = now.getMinutes();
            
            if(pauseBetweenMinutes.length != 0){
                // If it's not, check if it's the current minute pause;
                for (let i = 0; i < pauseBetweenMinutes.length; i += 2) {
                    const startMinute = pauseBetweenMinutes[i];
                    const endMinute = pauseBetweenMinutes[i + 1];
            
                    // If it's time to pause, add a pause based on the leftover minutes between the end and current time;
                    if (minutes >= startMinute && minutes <= endMinute) {
                        UpdateBannerAndDocument(`Paused until ${hours}:${(endMinute < 10 ? '0' : '') + endMinute}`, "Waiting for scheduled time in main shop");

                        const delayMinutes = (endMinute - minutes + 1) * 60000;
                        
                        await Sleep(delayMinutes);
                    }
                }
            }
        }

        ReloadPageBasedOnConditions();

        if (isHighlightingItemsInShops) {
            if (isBuyingWithItemDB) {
                var bestItemName = BestItemName(mapNames, mapPrices, itemProfits, minProfitNPs, minProfitPercent),
                    filteredDBItems = FilterItemsByProfitCriteria(mapNames, mapPrices, itemProfits, minProfitNPs, minProfitPercent);
        
                if (bestItemName) {
                    for (var itemName of filteredDBItems) {
                        document.querySelector(`.item-img[data-name="${itemName}"]`).parentElement.style.backgroundColor = "lightgreen";
                    }

                    document.querySelector(`.item-img[data-name="${bestItemName}"]`).parentElement.style.backgroundColor = "orangered";
                }
            } else {
                const itemNames = new Set(mapNames),
                      filteredNames = restockList.filter(itemName => itemNames.has(itemName) && !IsItemInBlacklist(itemName, isBlacklistActive, blacklist)),
                      selectedName = filteredNames.length > 0 ? filteredNames[0] : null;
        
                if (selectedName) {
                    for (var itemName of filteredNames) {
                        document.querySelector(`.item-img[data-name="${itemName}"]`).parentElement.style.backgroundColor = "lightgreen";
                    }

                    document.querySelector(`.item-img[data-name="${itemToBuyExtracted}"]`).parentElement.style.backgroundColor = "orangered";
                }
            }
        }
        
        async function ReloadPageBasedOnConditions() {
            // Calculate the number of stocked items
            var currentStockedItems = itemElements.length;
            UpdateDocument(currentStockedItems + " stocked items", "", false);
        
            // If the bot should only refresh if the shop is cleared and the shop is not cleared, then stop refreshing;
            if (shouldOnlyRefreshOnClear && currentStockedItems > 0) {
                UpdateBannerStatus("Shop Stocked, Stopping. Refreshing Only on Clears.");
                return;
            }
        
            var cooldown;
            
            if (currentStockedItems < minItemsToConsiderStocked) {
                cooldown = GetRandomFloat(minRefreshIntervalUnstocked, maxRefreshIntervalUnstocked);
                UpdateBannerStatus("Waiting " + FormatMillisecondsToSeconds(cooldown) + " to reload page...");
            } else {
                cooldown = GetRandomFloat(minRefreshIntervalStocked, maxRefreshIntervalStocked);
                UpdateBannerStatus("Waiting " + FormatMillisecondsToSeconds(cooldown) + " to reload page...");
            }

            if(itemToBuyExtracted == null) OpenQuickstockPage();

            await Sleep(cooldown);

            if (currentStockedItems < minItemsToConsiderStocked) {
                location.reload();
            } else {
                HandleCyclingThroughShops();
            }
        }
        
        function HandleCyclingThroughShops() {
            if (shopSettings.Count <= 1) {
                location.reload();
            } else {
                const currentIndex = settingsKeys.findIndex(id => id == shopId);
        
                if (currentIndex === -1) {
                    location.reload();
                } else {
                    var nextIndex = currentIndex + 1;

                    if(nextIndex > settingsKeys.length - 1) nextIndex = 1;

                    const nextShopId = settingsKeys[nextIndex];

                    window.location.href = `http://www.neopets.com/objects.phtml?type=shop&obj_type=${nextShopId}`;
                }
            }
        }
    }));
}