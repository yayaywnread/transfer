RunAutoBDProcess();

async function RunAutoBDProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoBD();
}

async function InjectAutoBD(){
    const selector1Element = document.getElementById("p1e1m"),
          selector2Element = document.getElementById("p1e2m"),
          abilityElement = document.getElementById("p1am");

    const selector1Form = document.getElementById("p1e1"),
          selector2Form = document.getElementById("p1e2"),
          abilityForm = document.getElementById("p1a");

    const originalStates = {
        selector1Element: {
            className: selector1Element.getAttribute("class"),
            style: selector1Element.lastChild.getAttribute("style"),
        },
        selector1Form: {
            value: selector1Form.getAttribute("value")
        },
        selector2Element: {
            className: selector2Element.getAttribute("class"),
            style: selector2Element.lastChild.getAttribute("style"),
        },
        selector2Form: {
            value: selector2Form.getAttribute("value")
        },
        abilityElement: {
            className: abilityElement.getAttribute("class"),
            style: abilityElement.lastChild.getAttribute("style"),
        },
        abilityForm: {
            value: abilityForm.getAttribute("value")
        }
    };

    setDEFAULT("AUTOBD_ENABLED", false);

    const isAutoBDEnabled = await getVARIABLE("AUTOBD_ENABLED");

    if(!isAutoBDEnabled) return;

    setDEFAULT("BD_TURNS", {
        "1": {
            "Attack 1": "Nothing",
            "Attack 2": "Nothing",
            "Ability": "Nothing",
        }
    });

    const startButton = await WaitForElement("start", 1);

    startButton.click();

    const turnData = await getVARIABLE("BD_TURNS"),
          turnKeys = Object.keys(turnData);
          
    const enemyHPElement = document.getElementById("p2hp"),
          currentTurnElement = document.getElementById("flround");

    currentTurnElement.textContent = "0";

    var extensionCurrentTurn = 0,
        enemyHP = parseInt(enemyHPElement.textContent),
        turn;

    while(enemyHP > 0){
        await WaitForTextContent(currentTurnElement, "0", false, 1);

        extensionCurrentTurn = currentTurnElement.textContent,

        enemyHP = enemyHPElement.textContent;

        turn = turnData[extensionCurrentTurn];
        if (turn == undefined) turn = turnData[turnKeys.length];

        await SelectWeapons(turn["Attack 1"], turn["Attack 2"], turn["Ability"]);

        const skipButton = document.getElementById("skipreplay");
        skipButton.click();

        const fightButton = document.getElementById("fight");
        try { 
            if(!fightButton.classList.contains("inactive")) fightButton.click(); 
        } catch { break; }

        skipButton.click();

        extensionCurrentTurn++;
    }

    const collectRewards = await WaitForElement(".end_ack.collect");

    if(collectRewards.classList.contains("nextwave")) return;

    collectRewards.click();

    const playAgainButton = await WaitForElement("bdplayagain", 1);

    if(playAgainButton){
        const itemLimitReached = PageIncludes("You have reached the item limit for today!"),
              plotPointMessage = PageIncludes("You have also been rewarded"),
              plotPointLimitReached = PageIncludes("You have reached the Plot Points limit for today!");

        if(!itemLimitReached){
            playAgainButton.click();
        } else {
            if(plotPointLimitReached){
                const lastDateBattled = await getVARIABLE("LAST_DATE_BATTLED"),
                      NSTTime = TimezoneDate(new Date()),
                      NSTTimeString = NSTTime.toDateString();

                if(lastDateBattled != NSTTimeString){
                    setVARIABLE("LAST_DATE_BATTLED", NSTTimeString);
                    window.close();
                }

                return;
            }
            else {
                if(!plotPointMessage) return;
                else playAgainButton.click();
            }
        }
    }

    async function SelectWeapons(attack1, attack2, ability) {
        // Wait for the item images to be available
        const itemTable = await WaitForElement("#p1equipment > div.fsmid img", 3);

        let elementAttack1, elementAttack2;

        if (attack1 !== "Nothing") {
            elementAttack1 = Array.from(itemTable).find(img => ManageAltNames(img) === attack1);

            if (elementAttack1) {
                SetWeaponInfo(elementAttack1.getAttribute("src"), elementAttack1.getAttribute("id"), selector1Element, selector1Form);
            }
        } else {
            ReturnToOriginalState(selector1Element, selector1Form, originalStates.selector1Element, originalStates.selector1Form);
        }

        if (attack2 !== "Nothing") {
            elementAttack2 = Array.from(itemTable).find(img => ManageAltNames(img) === attack2);

            if (elementAttack2) {
                SetWeaponInfo(elementAttack2.getAttribute("src"), elementAttack2.getAttribute("id"), selector2Element, selector2Form);
            }
        } else {
            ReturnToOriginalState(selector2Element, selector2Form, originalStates.selector2Element, originalStates.selector2Form);
        }

        function ManageAltNames(img){
            return img.getAttribute("alt").replace(":", "").trim();
        }

        if (ability === "Nothing") {
            ReturnToOriginalState(abilityElement, abilityForm, originalStates.abilityElement, originalStates.abilityForm);
            return;
        }

        // Wait for the ability images to be available
        const abilityTable = await WaitForElement("#p1ability > div.fsmid td img", 3);
        const abilityDictionary = {};

        abilityTable.forEach(img => {
            const src = img.getAttribute("src");
            const value = img.parentElement.getAttribute("data-ability");
            const name = img.parentElement.parentElement.getAttribute("title").trim();

            abilityDictionary[name] = {
                value: value,
                src: src,
            };
        });

        const selectedAbility = abilityDictionary[ability];

        if (selectedAbility) {
            SetWeaponInfo(selectedAbility.src, selectedAbility.value, abilityElement, abilityForm);
        }
    
        await Sleep(1000);

        function SetWeaponInfo(src, value, selector, form) {
            selector.setAttribute("class", "menu p1 selected");
            selector.lastChild.setAttribute("style", `background-position: 0px 0px; opacity: 1; background-image: url(${src}); background-size: 60px 60px;`);
            form.setAttribute("value", value);
        }

        function ReturnToOriginalState(element, form, originalElementData, originalFormData){
            element.setAttribute("class", originalElementData.className);
            element.lastChild.setAttribute("style", originalElementData.style);
            form.setAttribute("value", originalFormData.value);
        }
    }
    
}