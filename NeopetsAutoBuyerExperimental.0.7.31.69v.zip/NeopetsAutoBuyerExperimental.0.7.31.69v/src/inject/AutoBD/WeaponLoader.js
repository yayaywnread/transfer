RunWeaponLoaderProcess();

async function RunWeaponLoaderProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectWeaponLoader();
}

async function InjectWeaponLoader(){
    setDEFAULT("BD_WEAPONS", {});
    setDEFAULT("IS_LOADING_BD_WEAPONS", false);

    const isLoadingWeapons = await getVARIABLE("IS_LOADING_BD_WEAPONS");

    if(!isLoadingWeapons) return;

    const weaponData = {};

    const petContainer = document.querySelectorAll(".petContainer");

    petContainer.forEach(function(element) {
        const petName = element.dataset.name,
              equipTable = element.querySelector(".equipTable"),
              weapons = equipTable.querySelectorAll(".equipFrame"),
              abilities = element.querySelectorAll("#bdNPabil td p");

        weapons.forEach(function(weapon){
            AddToDictionary(petName, weapon.textContent.trim())
        });

        for(var i = 0; i < abilities.length; i++){
            const abilityName = abilities[i].textContent.trim();

            if(abilityName == "") continue;
            else if(!isNaN(parseInt(abilityName))) continue;

            AddToDictionary(petName, abilityName, false);
        }
    });

    function AddToDictionary(key, value, isWeapon = true){
        if(!weaponData[key]){
            weaponData[key] = {
                "Weapons": [],
                "Abilities": [],
            }
        }

        if(isWeapon) weaponData[key]["Weapons"].push(value);
        else weaponData[key]["Abilities"].push(value);
    }

    console.log(weaponData);
    setVARIABLE("BD_WEAPONS", weaponData);
    setVARIABLE("IS_LOADING_BD_WEAPONS", false);

    await Sleep(1000);
    window.close();
};