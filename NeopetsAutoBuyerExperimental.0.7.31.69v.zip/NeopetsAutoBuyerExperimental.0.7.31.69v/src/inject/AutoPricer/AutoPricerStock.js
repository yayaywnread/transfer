RunLoadShopStockProcess();

async function RunLoadShopStockProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectShopStockLoader();
}

async function InjectShopStockLoader(){
    StartInventoryScrapingOrSubmitting();
}


// Loading or submitting of prices;
async function StartInventoryScrapingOrSubmitting(){
    var marketURL = "https://www.neopets.com/market.phtml?";

    //If the player is in the market;
    if(window.location.href.includes(marketURL)){
        // Check if the system can submit prices;
        var canSubmit = await getVARIABLE("SUBMIT_PRICES_PROCESS");

        if(!canSubmit){
            var canScrapeInventory = await getVARIABLE("START_INVENTORY_PROCESS");

            //If it can't, then it will be loading the stock into the extension;
            if(canScrapeInventory){
                ProcessAllPages();
                setVARIABLE("START_INVENTORY_PROCESS", false);
            }
            
            return;
        } else {
            StartPriceSubmitting();
        }
    }
}

///////# Loading the Shop Stock in the Extension;
const hrefLinks = [];

// Calling all the shop pages for processing;
async function ProcessAllPages() {
    // If there are no other pages, then this is the only page the shop has;
    if(hrefLinks.length == 0){
        hrefLinks.push(window.location.href);
    }

    // Checking all links;
    for (let pageIndex = 0; pageIndex < hrefLinks.length; pageIndex++) {
        await ProcessPageData(pageIndex);

        // If it's the last page, let the user know the process is complete;
        if(pageIndex == hrefLinks.length - 1){
            setVARIABLE("SHOP_INVENTORY", rowsItems);
            setVARIABLE("AUTOPRICER_STATUS", "Inactive");
            UpdateBannerAndDocument("The shop inventory has been successfully saved!");
            setVARIABLE("INVENTORY_UPDATED", true);
            await Sleep(1000);
            window.close();
        }
    }
}

var rowsItems = [];
var currentIndex = 0;
const vetoWords = ['Enter your PIN:', 'Remove All', 'Name'];

// Process the contents inside the page;
async function ProcessPageData(pageIndex) {
    // Fetching the page and getting its contents;
    const response = await fetch(hrefLinks[pageIndex]);
    const pageContent = await response.text();

    // Parsing the page's contents;
    const parser = new DOMParser();
    const pageDocument = parser.parseFromString(pageContent, 'text/html');
    const form = pageDocument.querySelector('form[action="process_market.phtml"][method="post"]');
    const table = form.querySelector('table[cellspacing="0"][cellpadding="3"][border="0"]');
    const rows = table.querySelectorAll('tr');

    // Processing all the rows of the stocked table;
    rows.forEach((row, rowIndex) => {
        // Extracting the item row and name;
        const nameRow = row.querySelector('td:first-child');
        const itemName = nameRow.textContent.trim();

        // Extracting the input box;
        const inputElements = row.querySelectorAll('td input[name^="cost_"]');
        var priceContent = 0;
        try { priceContent = inputElements[0].value; } catch {}

        // Checking if it's a veto word;
        const isVetoWord = vetoWords.includes(itemName);

        //If it's not a veto word, store the data in the shop list;
        if (!isVetoWord) {
            const stockCell = row.querySelector('td:nth-child(3)').querySelector("b");
            const inStock = parseInt(stockCell.textContent); // Stores the amount of 'X' item in stock;

            // Saving in the shop list;
            const item = new Item(itemName, priceContent, true, rowIndex, currentIndex, inStock);
            currentIndex++;
            rowsItems.push(item);
        }
    });

    const shouldImportSales = await getVARIABLE("SHOULD_IMPORT_SALES");

    if(!shouldImportSales) return;

    // Fetching history data;
    const salesResponse = await fetch("https://www.neopets.com/market.phtml?type=sales");
    const salesContent = await salesResponse.text();

    // Parsing the history's contents;
    const historyParser = new DOMParser();
    const historyDocument = historyParser.parseFromString(salesContent, 'text/html');
    const tableElement = historyDocument.querySelector('form[action="market.phtml"]')?.parentElement.parentElement.parentElement;
    if (!tableElement) {
        return;
    }
    const trElements = tableElement.querySelectorAll("tr");

    var historyItems = [];

    var now = new Date(),
    todayDate = now.getDate(),
    todayMonth = now.getMonth() + 1,
    todayYear = now.getFullYear();

    // Processing all the history data into an array;
    trElements.forEach(function(tr){
        const tdElements = tr.querySelectorAll("td");
        
        // Parsing the data;
        try{
            var dateParts = tdElements[0].textContent.split("/");

            var entry = {
                "Date & Time": dateParts[1] + "/" + dateParts[0] + "/" + dateParts[2],
                Item: tdElements[1].textContent,
                Buyer: tdElements[2].textContent,
                Price: ParseNPNumber(tdElements[3].textContent),
                Entries: 1,
                Profit: 0,
            }
            
            var isASaleFromToday = todayYear == Number(dateParts[2]) && todayMonth == Number(dateParts[1]) && Number(todayDate == dateParts[0]);

            // Do not include today's sales;
            if(!isASaleFromToday){
                // Find the entry to edit its data later;
                var foundEntry = historyItems.find(item =>
                    item["Date & Time"] === entry["Date & Time"] &&
                    item.Item === entry.Item &&
                    item.Buyer === entry.Buyer &&
                    item.Price === entry.Price
                );

                if(foundEntry == undefined){
                    historyItems.push(entry);
                } 
                // Increase the number of times this item has appeared in the shop sales history and increment the profit;
                else { 
                    foundEntry.Entries += 1;
                    foundEntry.Profit = foundEntry.Price * foundEntry.Entries;
                }
            }
        } catch {}
    });

    const shopHistory = await getVARIABLE("SHOP_HISTORY");

    // Filter objects out of the historyItems that are in the extension's local shopHistory;
    var filteredHistoryItems = historyItems.filter(shopItem => {
        // If the information matches, then the item is already listed, returning true;
        var matchingObject = shopHistory.find(historyItem =>
            historyItem["Date & Time"] === shopItem["Date & Time"] &&
            historyItem.Item === shopItem.Item &&
            historyItem.Buyer === shopItem.Buyer &&
            historyItem.Price === shopItem.Price
        );
        
        return !matchingObject;
    // Filtering invalid items;
    }).filter(item => item["Date & Time"] != "undefined/Date/undefined");

    setVARIABLE("SHOP_HISTORY", [...shopHistory, ...filteredHistoryItems]);
}

LoadPageLinks();

// Parsing the shop pages links to access them later;
function LoadPageLinks(){
    document.querySelectorAll('p[align="center"] a').forEach(link => {
        const href = link.getAttribute('href');
        hrefLinks.push(href);
    });
    
    hrefLinks.shift();
}

async function StartPriceSubmitting(){
    await PriceItemsInPage();
    await NavigateToNextPage();
}

// Loads elements from the shop page to inject the calculated prices;
async function PriceItemsInPage() {
    return new Promise(async (resolve) => {
        setVARIABLE("AUTOPRICER_STATUS", "Navigating to Shop's Stock...");

        var form = null;
        form = await WaitForElement('form[action="process_market.phtml"][method="post"]', 0);

        // Extract all the table from the form;
        const table = form.querySelector('table[cellspacing="0"][cellpadding="3"][border="0"]');

        // Extracting all the input and read parameters of the table;
        const rows = table.querySelectorAll('tr');
        const pinInput = document.querySelector('input[type="password"][name="pin"]');
        const updateButton = document.querySelector('input[type="submit"][value="Update"]');

        // Saving all the data in its respective array;
        await InputDataInShop(rows);
        await PressUpdateButton(pinInput, updateButton);

        resolve(); // Resolve the PriceItemsInPage promise after all operations are done
    });
}

var updatedPrices = false;

// Saving the data in the shop input values;
async function InputDataInShop(rows){
    for (let rowIndex = 0; rowIndex < rows.length; rowIndex++) {
        // Getting the row data in the table;
        const row = rows[rowIndex];
        const nameRow = row.querySelector('td:first-child');
        const inputElements = row.querySelector('td input[name^="cost_"]');

        // Checking if the name is not a veto word;
        const itemName = nameRow.textContent.trim();
        const isVetoWord = vetoWords.includes(itemName);

        if(!isVetoWord){
            await new Promise(async (resolve) => {
                var list = await getVARIABLE("SHOP_INVENTORY");

                // Extracting the items from the list;
                const item = list.find(item => item.Name === itemName); // Finding the Item object based on its name in the table;

                var itemPrice;

                try {
                    itemPrice = parseInt(item.Price);
                } catch {
                    resolve();
                    return;
                }
                
                // If the price is NOT worth changing;
                if (itemPrice == parseInt(inputElements.value) || !item.IsPricing) {
                    resolve(); // Skip the current item and move to the next
                    return;
                }

                setVARIABLE("AUTOPRICER_STATUS", `Pricing ${itemName} at ${itemPrice} NPs...`);

                // Get a reference to the input element
                const inputElement = document.querySelector(`input[name="cost_${rowIndex}"]`);

                // Clear the current value in the input field
                inputElement.value = "";

                // The value you want to input
                const desiredValue = itemPrice.toString();
                inputElement.value = desiredValue;

                updatedPrices = true;
                resolve(); // Continue to the next item
            });
        }
    }
}

// Go to the next page in the page for pricing;
async function GetNextPage(){
    var index = await getVARIABLE("NEXT_PAGE_INDEX");

    if(index < hrefLinks.length){
        setVARIABLE("NAVIGATE_TO_NEXT_PAGE", true);
    } else {
        var canSubmit = await getVARIABLE("SUBMIT_PRICES_PROCESS");
        
        if(canSubmit){
            setVARIABLE("SUBMIT_PRICES_PROCESS", false);
            setVARIABLE("AUTOPRICER_STATUS", `The AutoPricing Process has Completed Successfully!`);
            UpdateBannerAndDocument("The AutoPricing process has completed successfully!");
            await Sleep(1000);
            window.close();
        }
    }
}

// Press the 'Update' button in the shop to update its prices;
async function PressUpdateButton(pinInput, updateButton){
    const isEnteringPINAutomatically = await getVARIABLE("SHOULD_ENTER_PIN");

    if(!isEnteringPINAutomatically){
        UpdateBannerAndDocument("Please Enter your PIN manually. The AutoPricing process has priced page, to continue fill the PIN input box.");
        
        async function WaitForPIN(pinInput){
            return new Promise(async (resolve) => {
                var intervalID = setInterval(() => {
                    var isValidPIN = pinInput.value.length === 4;

                    if (isValidPIN) {
                        clearInterval(intervalID);
                        resolve();
                    }
                }, 100);
            });
        }

        await WaitForPIN(pinInput);
    }

    if(updatedPrices){
        if(pinInput && isEnteringPINAutomatically){
            const playerPIN = await getVARIABLE("NEOPETS_SECURITY_PIN");

            pinInput.value = playerPIN;
        }
    }

    try {
        if(pinInput.value != "") updateButton.click();
    } catch {
        updateButton.click();
    }

    GetNextPage();
    setVARIABLE("AUTOPRICER_STATUS", `Prices Updated!`);
}

var currentPageLink = null;

async function NavigateToNextPage(){
    const sleepWaitForUpdateMin = await getVARIABLE("MIN_SHOP_CLICK_UPDATE"),
          sleepWaitForUpdateMax = await getVARIABLE("MAX_SHOP_CLICK_UPDATE");

    return new Promise(async (resolve) => {
        await Sleep(sleepWaitForUpdateMin, sleepWaitForUpdateMax);
        var canNavigate = await getVARIABLE("NAVIGATE_TO_NEXT_PAGE");
        var index = await getVARIABLE("NEXT_PAGE_INDEX");

        currentPageLink = hrefLinks[index];
        if(currentPageLink === undefined || currentPageLink === null) return;
        window.location.href = currentPageLink;
        setVARIABLE("NAVIGATE_TO_NEXT_PAGE", false);
        setVARIABLE("NEXT_PAGE_INDEX", ++index);
        if(canNavigate) setVARIABLE("AUTOPRICER_STATUS", `Navigating to the Shop's Next Page...`);

        resolve();
    });
}