function IsInVetoShopPage(){
    if(window.location.href.includes("market.phtml?type=sales") 
    || window.location.href.includes("market.phtml?type=till")
    || window.location.href.includes("market.phtml?type=edit")) return true;

    return false;
}

var usernameElement, username;

function LoadUsernameData(){
    try {
        usernameElement = document.querySelector('a.text-muted');
        username = usernameElement.textContent;
    } catch {}
}

function CancelSWProcess(){
    setVARIABLE("START_AUTOPRICING_PROCESS", false);
    setVARIABLE("AUTOPRICER_INVENTORY", []);
    setVARIABLE("INVENTORY_UPDATED", true);
    setVARIABLE("CURRENT_PRICING_INDEX", 0);
    setVARIABLE("SUBMIT_PRICES_PROCESS", false);
    setVARIABLE("START_AUTOKQ_PROCESS", false);
}

function DetectFaerieQuest(){
    if(PageIncludes("Ancient laws of magic and all that")){
        UpdateBannerAndDocument("You are currently in a Faerie Quest.");
        setVARIABLE("AUTOPRICER_STATUS", "Faerie Quest Detected, Process Stopped.");
        CancelSWProcess();
        return true;
    }
}

const swBannedMessage = 'I am too busy right now, please come back in about ';

async function CheckForBan(){
    // Find all paragraphs;
    const paragraphs = document.querySelectorAll('p');
    
    return new Promise(async (resolve) => {
        for (const paragraph of paragraphs) {
            const contents = paragraph.textContent;
    
            if (contents.includes(swBannedMessage)) {
                var bannedMinutes = contents.replace("I am too busy right now, please come back in about ", "");
                    bannedMinutes = Number(bannedMinutes.replace(" minutes and I can help you out.", ""));
                setVARIABLE("AUTOPRICER_STATUS", `Shop Wizard Ban Detected! Sleeping for ${bannedMinutes} Minutes or so...`);
                setVARIABLE("AUTOKQ_STATUS", `Shop Wizard Ban Detected! Sleeping for ${bannedMinutes} Minutes or so...`);

                UpdateBannerAndDocument("You are currently Shop Wizard Banned.");

                bannedMinutes *= 60000;

                // Sleep for the SW banned minutes and refresh the window;
                const sleepIfBannedMin = await getVARIABLE("MIN_WAIT_BAN_TIME"),
                      sleepIfBannedMax = await getVARIABLE("MAX_WAIT_BAN_TIME");

                await Sleep(bannedMinutes + Number(sleepIfBannedMin), bannedMinutes + Number(sleepIfBannedMax))
                setVARIABLE("AUTOPRICER_STATUS", `Shop Wizard is Usable Again!`);
                setVARIABLE("AUTOKQ_STATUS", "Shop Wizard is Usable Again!");
                resolve();
                window.location.reload();
            }
        }

        resolve();
    });
}

// PressSearch(); Press the search button in the SW page;
async function PressSearch(){
    // Click the button for the search;
    WaitForElement(".button-search-white", 0).then((searchButton) => {
        searchButton.click();
    });
}

// PressResubmit(); Press the "Resubmit" button in the SW page;
async function PressResubmit(){
    var resubmits = 0;
    const resubmitType = await getVARIABLE("RESUBMIT_TYPE");

    if(resubmitType == "Absolute"){
        const resubmitPresses = await getVARIABLE("RESUBMITS_PER_ITEM");

        resubmits = resubmitPresses;
    } else {
        const minResubmitsPerItem = await getVARIABLE("MIN_RESUBMITS_PER_ITEM"),
              maxResubmitsPerItem = await getVARIABLE("MAX_RESUBMITS_PER_ITEM");

        resubmits = GetRandomInt(minResubmitsPerItem, maxResubmitsPerItem);
    }

    const sleepThroughSearchesMin = await getVARIABLE("MIN_RESUBMIT_WAIT_TIME"),
          sleepThroughSearchesMax = await getVARIABLE("MAX_RESUBMIT_WAIT_TIME");

    // The amount of times the extension should search for lower prices;
    for(var i = 1; i <= resubmits; i++){
        await CheckForBan();
        
        FindLowestPricedShop(false, false);

        await Sleep(sleepThroughSearchesMin, sleepThroughSearchesMax);

        // The AutoPricer did not find any results in the table so it may need to refresh the page in order to find new results;
        try {
            await WaitForElement("#resubmitWizard", 0).then((resubmitButton) => {
                resubmitButton.click();
            });
        } catch {

            if(!PageIncludes(swBannedMessage)) window.location.reload();
        }
    }
}

async function FindLowestPricedShop(mustTriggerNavigation = false, isLastSearch = false){
    const isKQRunning = await getVARIABLE("START_AUTOKQ_PROCESS");

    // Automatically buys an item if its below a certain price threshold;
    if(isKQRunning){
        await WaitForElement('.wizard-results-grid li', 3).then(async (searchResults) => {
            // Removing the table head;
            searchResults = Array.from(searchResults);
            searchResults.shift();
            LoadUsernameData();

            const maxSpendablePrice = await getVARIABLE("MAX_SPENDABLE_PRICE"),
                  maxInstaBuyPrice = await getVARIABLE("MAX_INSTA_BUY_PRICE");

            RecursivelyProcessSearchResults(0);
            
            function RecursivelyProcessSearchResults(index) {
                // Exit the recursion in case no price is good;
                if (index >= searchResults.length) {
                    if(isLastSearch) window.location.reload();
                    return;
                }
            
                const result = searchResults[index];
                const ownerElement = result.querySelector("a");
                const priceElement = result.querySelector("div");
            
                const lowestPrice = ParseNPNumber(priceElement.textContent);
                const ownerName = ownerElement.textContent;
            
                // If the lowest price is greater than the price the user is willing to pay, search again;
                if (lowestPrice >= maxSpendablePrice && isLastSearch) {
                    window.location.reload();
                    setVARIABLE("AUTOKQ_STATUS", `Retrying Search as the Price ${lowestPrice} Goes Above the NP Limit...`);
                    return;
                }
            
                // Buy an item if it's not from the user and is within the payable price;
                if ((lowestPrice <= maxInstaBuyPrice || mustTriggerNavigation) && (username != ownerName)) {
                    ownerElement.click();
                    setVARIABLE("AUTOKQ_STATUS", `Navigating to a Shop Owned by ${ownerName}...`);
                    return;
                }
            
                // Check for the next item if necessary;
                RecursivelyProcessSearchResults(index + 1);
            }
        });
    }
}