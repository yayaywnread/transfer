RunAutoSWKQ();

async function RunAutoSWKQ(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectKQSearcher();
}

async function InjectKQSearcher() {
    const isKQRunning = await getVARIABLE("START_AUTOKQ_PROCESS");
    const isAutoPricerRunning = await getVARIABLE("START_AUTOPRICING_PROCESS");

    if(isAutoPricerRunning) return;
    if(!isKQRunning) return;
    if(IsInVetoShopPage()) return;

    // Setting KQ Searches for AutoBuying;
    KQSearch();

    async function KQSearch(){
        if(DetectFaerieQuest()) return;

        await CheckForBan();
        
        await PressSearch();

        await PressResubmit();

        await FindLowestPricedShop(true, true);
    }
}