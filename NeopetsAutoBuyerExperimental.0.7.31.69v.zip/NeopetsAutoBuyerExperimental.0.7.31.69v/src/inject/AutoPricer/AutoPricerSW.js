RunAutoPricer();

async function RunAutoPricer(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoPricer();
}

async function InjectAutoPricer(){
    const isKQRunning = await getVARIABLE("START_AUTOKQ_PROCESS");
    const isAutoPricerRunning = await getVARIABLE("START_AUTOPRICING_PROCESS");

    if(isKQRunning) return;
    if(!isAutoPricerRunning) return;
    if(IsInVetoShopPage()) return;

    await AutoPricerCore();
}

var nameToSearch = "",
    autoPricingList = [];

async function AutoPricerCore(){
    setVARIABLE("AUTOPRICER_STATUS", "Navigating to SW...");

    autoPricingList = await getVARIABLE("AUTOPRICER_INVENTORY");
    var currentPricingIndex = await getVARIABLE("CURRENT_PRICING_INDEX");

    //If the pricing list has been completed, end the AutoPricing process;
    AutoSubmitPrices(autoPricingList.length, currentPricingIndex);

    var itemToSearch = autoPricingList[currentPricingIndex];
    try { nameToSearch = itemToSearch.Name; } catch {}

    if(DetectFaerieQuest()) return;

    // If the box exists, then introduce the name on it;
    setVARIABLE("AUTOPRICER_STATUS", `Searching ${nameToSearch}...`);

    await CheckForBan();

    // Click the button for the search;
    await PressSearch();

    // The amount of times the extension should search for lower prices;
    await PressResubmit();

    await GetLowestPrice(itemToSearch, currentPricingIndex);
}

const abnormalPriceThreshold = 10000;

async function GetLowestPrice(itemToSearch, currentPricingIndex){
    // Getting the lowest price;
    await WaitForElement(".wizard-results-grid-header", 0).then(async (searchResults) => {
        // If the AutoPricer cannot find any results, retry the search. If the next search yields no results, then continue;
        if(searchResults == null){
            const isRetryingSearch = await getVARIABLE("IS_RETRYING_SEARCH");

            if(isRetryingSearch == undefined){
                setVARIABLE("IS_RETRYING_SEARCH", false);
            }

            if(isRetryingSearch){
                setVARIABLE("IS_RETRYING_SEARCH", false);
                ContinueAutoPricing(currentPricingIndex);
                UpdateBannerAndDocument(`The Shop Wizard has no price for ${itemToSearch.Name}. The AutoPricer process will not price this item`, `${itemToSearch.Name} without a price`);
                await Sleep(2000);
                return;
            } else {
                setVARIABLE("IS_RETRYING_SEARCH", true);
                setVARIABLE("CURRENT_PRICING_INDEX", --currentPricingIndex);
                window.location.reload();
                return;
            }
        }

        var ownerElements = searchResults.parentNode.querySelectorAll("li"),
            ownerName = '', 
            bestPrice = 0;

        LoadUsernameData();

        if(ownerElements == 1){
            setVARIABLE("IS_RETRYING_SEARCH", true);
            await Sleep(1000);
            return;
        }

        // Checking if an owner is frozen;
        for(var i = 1; i < ownerElements.length; i++){
            // Extracting all the table data;
            var entry = ownerElements[i];
            var ownerElement = entry.querySelector("a");
            var ownerLink = ownerElement.getAttribute("href");
            var currentOwnerPrice = ParseNPNumber(entry.querySelector("div").textContent);
            var percentageDifference = 0;

            /* Measuring the price difference to see if the user has an abnormally low 
             * price, maybe meaning it was frozen. This saves in requests and processing 
             * time for AutoPricing */
            try {
                var nextOwnerPrice = ParseNPNumber(ownerElements[i + 1].querySelector("div").textContent);

                percentageDifference = CalculatePercentageDifference(currentOwnerPrice, nextOwnerPrice);
            } catch (error) { 
                console.log(error);
            }

            ownerName = ownerElement.textContent;
            bestPrice = currentOwnerPrice;

            //Don't change the price if it's already the cheapest item in the list;
            if(username == ownerName){
                setVARIABLE("AUTOPRICER_STATUS", `${username} Already has the Lowest Price Available! Skipping...`);
                UpdateShopInventoryWithValue(itemToSearch);
                break;
            }

            const shouldCheckIfFrozenShop = await getVARIABLE("SHOULD_CHECK_IF_FROZEN_SHOP");

            // Sending and reading a request to know if the shop user is frozen;
            if(bestPrice >= abnormalPriceThreshold && shouldCheckIfFrozenShop && percentageDifference > 50){
                var isFrozen = await CheckShopFrozenStatus(ownerLink);

                if(!isFrozen){
                    UpdateBannerAndDocument(`Abnormally low priced ${nameToSearch} detected. The AutoPricer process will not price this item.`, 
                                            "Abnormally priced item");

                    UpdateShopInventoryWithValue(itemToSearch, 0);

                    return;
                }
            // If the user decided to not check if the user's shop is frozen, then return the first value;
            } else {
                if(bestPrice > abnormalPriceThreshold && percentageDifference > 50){
                    UpdateBannerAndDocument(`Abnormally low priced ${nameToSearch} detected. The AutoPricer process will not price this item.`, 
                                            "Abnormally priced item");

                    UpdateShopInventoryWithValue(itemToSearch, 0);

                    return;
                }

                break;
            }
        }

        // Calculates the percentage difference between 2 numbers to know if a user has been frozen or not;
        function CalculatePercentageDifference(oldValue, newValue) {
            return Math.abs((newValue - oldValue) / oldValue) * 100;
        }

        // Check if the owner of a shop is frozen;
        async function CheckShopFrozenStatus(ownerLink, maxRetries = 3, retryDelay = 2000) {
            let retries = 0;
        
            while (retries < maxRetries) {
                try {
                    const shopResponse = await fetch(ownerLink);
                    
                    if (shopResponse.ok) {
                        const shopContent = await shopResponse.text();
                        const shopDocument = new DOMParser().parseFromString(shopContent, 'text/html');
                        const isOwnerFrozen = shopDocument.body.textContent.includes("Sorry - The owner of this shop has been frozen!");
                        return isOwnerFrozen;
                    }
                } catch (error) {
                    console.error('Error fetching data:', error);
                }
        
                // If the request fails, wait for a while before retrying
                await new Promise(resolve => setTimeout(resolve, retryDelay));
                retries++;
            }
        
            throw new Error(`Failed to fetch data from ${ownerLink} after ${maxRetries} retries.`);
        }

        
        //////////////////////////////////////////////////////////////////////////////


        var deductedPrice = 0;

        const pricingType = await getVARIABLE("PRICING_TYPE"),
              isRandomPercentage = await getVARIABLE("SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING"),
              percentageDeductionMin = await getVARIABLE("MIN_PRICING_PERCENTAGE"),
              percentageDeductionMax = await getVARIABLE("MAX_PRICING_PERCENTAGE"),
              fixedAlgorithmType = await getVARIABLE("FIXED_PRICING_ALGORITHM_TYPE"),
              fixedPricingDeduction = await getVARIABLE("FIXED_PRICING_VALUE"),
              minFixedPricingDeduction = await getVARIABLE("MIN_FIXED_PRICING"),
              maxFixedPricingDeduction = await getVARIABLE("MAX_FIXED_PRICING"),
              fixedPercentageDeduction = await getVARIABLE("FIXED_PRICING_PERCENTAGE");

        switch(pricingType){
            case "Percentage":
                await PercentagePricingCalculation();
            break;

            case "Absolute":
                await AbsolutePricingCalculation();
            break;

            case "Random":
                var pricingAlgorithmOptions = ["Percentage", "Absolute"];
                var randomIndex = GetRandomInt(0, pricingAlgorithmOptions.length);

                switch(pricingAlgorithmOptions[randomIndex]){
                    case "Percentage":
                        await PercentagePricingCalculation();
                    break;

                    case "Absolute":
                        await AbsolutePricingCalculation();
                    break;
                }
            break;
        }

        async function PercentagePricingCalculation(){
            var percentageBestPrice = Math.floor(CalculatePercentagePrices(bestPrice, true));

            const percentageAlgorithmType = await getVARIABLE("PERCENTAGE_PRICING_ALGORITHM_TYPE");

            switch(percentageAlgorithmType){
                case "Zeroes":
                    deductedPrice = RoundToNearestUnit(percentageBestPrice);
                break;

                case "Nines":
                    deductedPrice = RoundToNearestUnit(percentageBestPrice, true);
                break;

                case "Random":
                    const percentagePricingOptions = ["Zeroes", "Nines", "Unchanged"];
                    var randomIndex = GetRandomIntExclusive(0, percentagePricingOptions.length);

                    switch(percentagePricingOptions[randomIndex]){
                        case "Zeroes": deductedPrice = RoundToNearestUnit(percentageBestPrice); break;
                        case "Nines": deductedPrice = RoundToNearestUnit(percentageBestPrice, true); break;
                        case "Unchanged": deductedPrice = percentageBestPrice; break;
                    }
                break;

                case "Unchanged":
                    deductedPrice = percentageBestPrice;
                break;
            }
        }

        async function AbsolutePricingCalculation(){
            switch(fixedAlgorithmType){
                case "True Absolute":
                    deductedPrice = Clamp(bestPrice - fixedPricingDeduction, 0, 999999);
                break;

                case "Random Absolute":
                    deductedPrice = Clamp(bestPrice - GetRandomInt(minFixedPricingDeduction, maxFixedPricingDeduction), 0, 999999);
                break;

                case "Both":
                    var absolutePricingOptions = ["True Absolute", "Random Absolute"];
                    var randomIndex = GetRandomInt(0, absolutePricingOptions.length);

                    switch(absolutePricingOptions[randomIndex]){
                        case "True Absolute":
                            deductedPrice = Clamp(bestPrice - fixedPricingDeduction, 0, 999999);
                        break;

                        case "Random Absolute":
                            deductedPrice = Clamp(bestPrice - GetRandomInt(minFixedPricingDeduction, maxFixedPricingDeduction), 0, 999999);
                        break;
                    }
                break;
            }
        }

        function RoundToNearestUnit(number, hasNines = false){
            var zeroesToAdd = number.toString().length - 2;
            var unitString, unit;

            try {
                unitString = "1" + "0".repeat(zeroesToAdd);
                unit = Number(unitString);
            } catch {
                UpdateShopInventoryWithValue(itemToSearch, 0);

                return;
            }

            if(hasNines) return CalculateThousand(number, unit, 1);
            return CalculateThousand(number, unit);
        }

        function CalculateThousand(number, unit, subtraction = 0){
            return Math.round(number / unit) * unit - subtraction;
        }

        function CalculatePercentagePrices(number, isSubtractingPercentage = false){
            if(isRandomPercentage || isSubtractingPercentage) {
                return number * (1 - parseFloat((GetRandomFloat(percentageDeductionMin, percentageDeductionMax) * 0.01).toFixed(3)));
            } else { // If the subtracted percentage is fixed;
                return number * (1 - (fixedPercentageDeduction * 0.01));
            }
        }

        if(!isNaN(deductedPrice)){
            deductedPrice = Math.floor(deductedPrice);
            try { autoPricingList[currentPricingIndex].Price = deductedPrice; } 
            catch {
                AutoSubmitPrices(autoPricingList.length, autoPricingList.length);
            }
        } else {
            autoPricingList[currentPricingIndex].Price = 0;
            UpdateBannerAndDocument(`An error occurred while pricing ${nameToSearch}. The AutoPricer process will not price this item.`, 
                                    "An error occurred in the AutoPricer");
        }

        setVARIABLE("AUTOPRICER_INVENTORY", autoPricingList);

        UpdateShopInventoryWithValue(itemToSearch, deductedPrice);

        setVARIABLE("AUTOPRICER_STATUS", `${nameToSearch} Best Price Found! Priced at ${bestPrice}...`);
    });

    ContinueAutoPricing(currentPricingIndex);
}

async function ContinueAutoPricing(currentPricingIndex){
    // Increment currentIndex
    setVARIABLE("CURRENT_PRICING_INDEX", ++currentPricingIndex);
    await Sleep(1000);

    try{
        window.location.href = `https://www.neopets.com/shops/wizard.phtml?string=${encodeURIComponent(autoPricingList[currentPricingIndex].Name)}`;
    } catch {
        window.location.reload();
    }
}

async function AutoSubmitPrices(listLength, currentPricingIndex){
    const isRetryingSearch = await getVARIABLE("IS_RETRYING_SEARCH");

    if(isRetryingSearch) return;

    if(listLength - 1 < currentPricingIndex){
        setVARIABLE("CURRENT_PRICING_INDEX", 0);
        setVARIABLE("START_AUTOPRICING_PROCESS", false);
        setVARIABLE("AUTOPRICER_STATUS", "AutoPricing Complete!");

        // Submitting the prices automatically;
        var isSubmittingAutomatically = await getVARIABLE("SHOULD_SUBMIT_AUTOMATICALLY");

        if(isSubmittingAutomatically){
            setVARIABLE("NEXT_PAGE_INDEX", 1);
            setVARIABLE("SUBMIT_PRICES_PROCESS", true);
            setVARIABLE("START_INVENTORY_PROCESS", false);

            var entireShopStock = await getVARIABLE("SHOP_INVENTORY");

            for(var i = 0; i < entireShopStock.length; i++){
                entireShopStock[i].IsPricing = true;
            }

            setVARIABLE("INVENTORY_UPDATED", true);
            setVARIABLE("SHOP_INVENTORY", entireShopStock);
            window.location.href = 'https://www.neopets.com/market.phtml?type=your';
        } else {
            UpdateBannerAndDocument("AutoPricing done! Return to the AutoPricer page and press the 'Submit Prices' button.", "Process Complete!");
        }
    }
}

// Loads and edits the stored shop inventory and sets a price to items;
async function UpdateShopInventoryWithValue(itemToSearch, price = null){
    var shopList = await getVARIABLE("SHOP_INVENTORY");

    if(price != null) shopList[itemToSearch.Index - 1].Price = price;
    shopList[itemToSearch.Index - 1].IsPricing = false;
    setVARIABLE("SHOP_INVENTORY", shopList);
    setVARIABLE("INVENTORY_UPDATED", true);
}