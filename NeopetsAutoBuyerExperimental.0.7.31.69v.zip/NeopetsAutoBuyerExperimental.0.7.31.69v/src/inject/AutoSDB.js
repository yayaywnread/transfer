RunAutoSDBProcess();

async function RunAutoSDBProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } 

    HandleServerErrors();

    InjectAutoSDB();
}

async function InjectAutoSDB(){
    setDEFAULT("AUTOSDB_ENABLED", false);

    const isAutoSDBEnabled = await getVARIABLE("AUTOSDB_ENABLED");

    if(!isAutoSDBEnabled) return;

    if(PageIncludes("Error: ")){
        window.location.href = "https://www.neopets.com/quickstock.phtml";
        return;
    }
    
    setDEFAULT("SDB_LIST", []);

    var sdbList = await getVARIABLE("SDB_LIST");

    if(sdbList.length == 0) return;

    /*if(sdbList.length == 0){
        CloseWindow();
        return;
    }
    else setVARIABLE("IS_QUICKSTOCK_WINDOW_OPEN", true);

    // If the window is closed by accident by the user;
    window.addEventListener('beforeunload', (event) => {
        setVARIABLE("IS_QUICKSTOCK_WINDOW_OPEN", false);
    });*/

    const quickStockTable = document.querySelector("#content > table > tbody > tr > td.content > form > table"),
          submitButton = document.querySelector('input[type="submit"][value="Submit"]'),
          tableRows = quickStockTable.querySelectorAll("tr");

    setDEFAULT("GALLERY_LIST", []);
    setDEFAULT("SDB_HISTORY", []);

    const galleryList = await getVARIABLE("GALLERY_LIST");
    var sdbHistory = await getVARIABLE("SDB_HISTORY");

    const itemsInInventory = [];

    tableRows.forEach(async function(row){
        const itemName = row.firstElementChild.textContent.trim(),
              isItemName = !itemName.includes("Object Name") && !itemName.includes("Check All") && itemName != "";

        if(isItemName){
            const foundItem = sdbList.find(item => item["Item Name"] === itemName);

            itemsInInventory.push(itemName);

            sdbHistory = await getVARIABLE("SDB_HISTORY");

            if(foundItem){
                const deposit = foundItem["Deposit"];

                const index = sdbList.findIndex(item => 
                    item["Account"] === foundItem["Account"] &&
                    item["Date & Time"] === foundItem["Date & Time"] &&
                    item["Item Name"] === foundItem["Item Name"] &&
                    item["Shop Name"] === foundItem["Shop Name"]
                );

                if(galleryList.includes(itemName)){
                    row.children[6].querySelector("input").click();
    
                    var isDepositCorrect = sdbHistory[index]["Deposit"] == "Gallery";
    
                    if(!isDepositCorrect) sdbHistory[index]["Deposit"] = "Gallery";
    
                    setVARIABLE("SDB_HISTORY", sdbHistory);
                } else {
                    switch(deposit){
                        case "Stock":
                            row.children[2].querySelector("input").click();
                        break;
    
                        case "Deposit":
                            row.children[3].querySelector("input").click();
                        break;
                    }
                }

                sdbList.splice(index, 1);
            }
        }
    });

    // Remove items not found from the list;
    sdbList.forEach(function(item, index){
        if(!itemsInInventory.includes(item["Item Name"])) sdbList.splice(index, 1);
    });

    const sleepWaitForUpdateMin = await getVARIABLE("MIN_SUBMIT_QUICKSTOCK"),
          sleepWaitForUpdateMax = await getVARIABLE("MAX_SUBMIT_QUICKSTOCK");

    setDEFAULT("MIN_SUBMIT_QUICKSTOCK", 5000);
    setDEFAULT("MAX_SUBMIT_QUICKSTOCK", 10000);
    
    /*const isQuickStockWindowOpen = await getVARIABLE("IS_QUICKSTOCK_WINDOW_OPEN");*/

    await Sleep(sleepWaitForUpdateMin, sleepWaitForUpdateMax);

    /*setVARIABLE("IS_QUICKSTOCK_WINDOW_OPEN", false);*/
    setVARIABLE("SDB_LIST", sdbList);
    submitButton.click();

    chrome.runtime.sendMessage({ action: 'closeTab' });
}