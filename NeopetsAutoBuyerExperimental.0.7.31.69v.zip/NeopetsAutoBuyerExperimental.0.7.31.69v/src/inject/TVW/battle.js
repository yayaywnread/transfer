RunAutoBuyerProcess();

async function RunAutoBuyerProcess(){
    var status = await getVARIABLE("UPDATE_STATUS_A");

    if(!status){
        UpdateBannerAndDocument(updateAlert, updateBanner);
        chrome.runtime.sendMessage({ action: "outdatedVersion" });
        return;
    } else {
        setVARIABLE("HAS_UPDATE_ALERT_TRIGGERED", false);
    }

    HandleServerErrors();

    DisplayAutoBuyerBanner();

    InjectAutoTVWBattler();
}

async function InjectAutoTVWBattler(){
    const isAutoTVWBattlerEnabled = await getVARIABLE("TVW_AUTOBD_ENABLED");

    if(!isAutoTVWBattlerEnabled) return;

    setDEFAULT("TVW_BATTLES", []);
    setDEFAULT("TVW_BATTLE_SELECTED", "");

    var fights = Array.from(document.querySelectorAll('[id*="fight"]')),
    validFights = fights.filter(parent => {
        if(parent.id == "rbfightStep1") return;

        return parent.querySelector(".tvw-fight_fightChallengersButton") != null;
    });

    var fightNames = [], fightButtons = [];

    validFights.forEach(function(fight){
        const title = fight.querySelector(".tvw-fight_title").textContent;

        fightNames.push(title);
        fightButtons.push(fight.querySelector(".tvw-fight_fightChallengersButton"));
    });

    const tvwBattles = await getVARIABLE("TVW_BATTLES");

    if(tvwBattles.length != validFights.length){
        setVARIABLE("TVW_BATTLES", fightNames);

        var fights = await getVARIABLE("TVW_BATTLES");
    }

    const lastDateBattled = await getVARIABLE("LAST_DATE_BATTLED"),
          NSTTime = TimezoneDate(new Date()),
          NSTTimeString = NSTTime.toDateString();

    if(lastDateBattled == NSTTimeString) return;

    if(!isAutoTVWBattlerEnabled) return;

    const selectedBattle = await getVARIABLE("TVW_BATTLE_SELECTED");

    if(selectedBattle == "") return;

    const selectedBattleIndex = fightNames.indexOf(selectedBattle);

    fightButtons[selectedBattleIndex].click();

    const ImReadyButton = await WaitForElement("button[onclick='rb.goToStepTwo()']");

    ImReadyButton.click();

    const petThumbContainers = await WaitForElement(".petThumbContainer", 3),
          bdPet = await getVARIABLE("BD_PET");

    const petToSelect = Array.from(petThumbContainers).filter(element => element.getAttribute("data-name") == bdPet);

    if(petToSelect.length == 0) return;

    petToSelect[0].click();

    const continueToBattledomeButton = await WaitForElement("#container__2020 .challenger_container .tvw-battle_continueBattle.button-yellow__2020");

    continueToBattledomeButton.click();
}
