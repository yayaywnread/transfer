AutoBD();

async function AutoBD(){
    await BattledomeData();

    //######################################################################################################################################

    // Loading turn information;
    var turnsTable = document.getElementById("data"),
    turnsToRunContainer = document.querySelector(".data-point"),
    turnsToRunContainerClone = turnsToRunContainer.cloneNode(true),
    containers;

    var turns = {};

    // Adding the default row;
    setTimeout(async function(){
        setDEFAULT("BD_TURNS", {
            "1": {
                "Attack 1": "Nothing",
                "Attack 2": "Nothing",
                "Ability": "Nothing",
                "Ability Name": "Nothing",
            }
        });

        turns = await getVARIABLE("BD_TURNS");

        Object.keys(turns).forEach(function(id){
            turnsTable.appendChild(CloneWithValues(turnsToRunContainerClone, id));
        });

        turnsToRunContainer.remove();

        ProcessContainers();
    }, 500);

    var hasGeneratedDefaultSettings = false;

    // CloneWithValues(); Clone the default row with values;
    function CloneWithValues(node, id, passDefault = false) {
        var turn;

        if(!passDefault) turn = turns[id];
        else {
            turn = {
                "Attack 1": "Nothing",
                "Attack 2": "Nothing",
                "Ability": "Nothing",
            };
        }


        if(hasGeneratedDefaultSettings){
            if(id == 0) id = 1;
        } else {
            if(id == 0) hasGeneratedDefaultSettings = true;
        }    

        let clone = node.cloneNode(true);
        clone.classList.remove("hidden");

        // Get all form elements in the original node
        let originalElements = node.querySelectorAll('input, select, textarea');
        let clonedElements = clone.querySelectorAll('input, select, textarea');

        // Copy the values from the original elements to the cloned elements
        for(var i = 0; i < originalElements.length; i++){
            const clonedElement = clonedElements[i];

            try {
                switch(i){
                    case 0: clonedElement.value = turn['Attack 1']; break;
                    case 1: clonedElement.value = turn['Attack 2']; break;
                    case 2: clonedElement.value = turn['Ability']; break;
                }
            } catch {}

            clonedElement.addEventListener("change", function(){
                ProcessContainers(false);
            });
        }
        
        return clone;
    }

    // Add turns;
    const addTurnButton = document.getElementById("add-turn");

    addTurnButton.addEventListener("click", function(){
        turnsTable.appendChild(CloneWithValues(turnsToRunContainer, 0, true));

        ProcessContainers();
    });

    ActivateExpandCollapseListeners("expand-turns", ".expand");

    ActivateExpandCollapseListeners("collapse-turns", ".collapse");

    function ActivateExpandCollapseListeners(buttonSelector, classSelector){
        const expandShopsButton = document.getElementById(buttonSelector);

        expandShopsButton.addEventListener("click", function(){
            containers.forEach(function(element){
                if(!element.classList.contains("hidden")){
                    const button = element.querySelector(classSelector);

                    button.click();
                }
            });
        });
    }

    // ProcessContainers(); Process the information inside the containers;
    function ProcessContainers(shouldCollapseTabs = true){
        turns = {};

        containers = document.querySelectorAll(".data-point");

        containers.forEach(function(element, index){
            const turnName = element.querySelector(".controller-name"),
                collapseButton = element.querySelector(".collapse"),
                expandButton = element.querySelector(".expand"),
                removeButton = element.querySelector(".remove"),
                table = element.querySelector(".table");

            turnName.textContent = `Turn ${index + 1}`;

            // Define the default state of buttons;
            if(shouldCollapseTabs){
                expandButton.classList.remove("hidden");
                collapseButton.classList.add("hidden");
                table.classList.add("hidden");
            }

            // Expand the selection;
            expandButton.addEventListener("click", function(){
                table.classList.remove("hidden");
                expandButton.classList.add("hidden");
                collapseButton.classList.remove("hidden");
            });

            // Collapse the selection;
            collapseButton.addEventListener("click", function(){
                table.classList.add("hidden");
                expandButton.classList.remove("hidden");
                collapseButton.classList.add("hidden");
            });
            
            // Remove the selection;
            removeButton.addEventListener("click", function(){
                if(!IsDefaultSettings(turnName)){
                    element.remove();
                    ProcessContainers();
                }
            });

            // Do not allow the user to delete the default row;
            if(IsDefaultSettings(turnName)){
                removeButton.classList.add("hidden");
            }

            if(!element.classList.contains("hidden")) ProcessTurnObject(element, index);
        });

        setVARIABLE("BD_TURNS", turns);
    }

    function IsDefaultSettings(name){
        return name.textContent == "Turn 1";
    }

    function ProcessTurnObject(element, index){
        const selectors = element.querySelectorAll("select");

        var turn = {
            id: index + 1,
            "Attack 1": selectors[0].value,
            "Attack 2": selectors[1].value,
            "Ability": selectors[2].value,
        }

        turns[turn.id] = turn;

        return turn;
    }
}