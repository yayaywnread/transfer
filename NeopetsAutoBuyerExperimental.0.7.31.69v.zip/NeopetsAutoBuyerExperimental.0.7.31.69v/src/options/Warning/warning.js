const menuDisplayButtons = document.querySelectorAll(".image-button"),
      menuPanels = document.querySelectorAll(".right-column > div");

function DeactivateMenuSections(selectedMenu, menuDisplayButtons){
    menuPanels.forEach(function(menu, index){
        if(index == selectedMenu){
            menu.style.display = "inline";
        } else {
            menu.style.display = "none";
        }
    });
}

const nextLandingButton = document.getElementById("next-landing");

function SetSelectedButtonClass(index){
    menuDisplayButtons.forEach(function(option){
        option.classList.remove("selected-menu");
    });
    
    menuDisplayButtons[index].classList.add("selected-menu");
}


nextLandingButton.addEventListener("click", function () { 
    var option = 1;

    DeactivateMenuSections(option);
    SetSelectedButtonClass(option);
});

const nextWarningButton = document.getElementById("next-tos");

nextWarningButton.addEventListener("click", function () { 
    var option = 2;

    DeactivateMenuSections(option);
    SetSelectedButtonClass(option);
});

const acceptToSButton = document.getElementById("accept-tos");

acceptToSButton.addEventListener("click", function () { 
    setVARIABLE("WARNING_ACK", true);
    window.location.href = "../Autobuyer/autobuyer.html" ;
    window.open('https://github.com/Unovamata/AutoBuyerPlus/wiki/FAQs', '_blank');
    window.open('https://github.com/Unovamata/AutoBuyerPlus/wiki', '_blank');
});