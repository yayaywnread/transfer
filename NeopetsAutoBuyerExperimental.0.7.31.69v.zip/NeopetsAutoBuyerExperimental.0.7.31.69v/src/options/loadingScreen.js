// Create the loading logo image
const loadingLogo = document.getElementById("loading-logo");

// Get the URL of the current script and Extract the part before "src"
var currentScriptUrl = document.currentScript.src;
var logoPath = currentScriptUrl.substring(0, currentScriptUrl.indexOf("src") + 3);
loadingLogo.src = `${logoPath}/logo.png`;

// Load the notifications as soon as the page has finished loading;
document.addEventListener("DOMContentLoaded", function () {
    LoadingScreen();
});

function LoadingScreen(){
    const loadingBar = document.getElementById("loading-bar");
    const totalResources = CountResources(); // Function to count total resources

    function CountResources() {
        const totalLinks = document.querySelectorAll("link").length;
        const totalScripts = document.querySelectorAll("script").length;
        const totalImages = document.querySelectorAll("img").length;
        return totalLinks + totalScripts + totalImages;
    }

    var loadedResources = 0;

    function UpdateLoadingProgress() {
        loadedResources++;
        pageProgress = (loadedResources / totalResources) * 100;
        loadingBar.style.width = `${pageProgress}%`;

        // Check if all resources have been loaded
        if (loadedResources >= totalResources) {
            clearInterval(intervalID); // Stop the interval
            document.getElementById("loading-filter").classList.add("loading-fade-out");
        }
    }

    intervalID = setInterval(UpdateLoadingProgress, 2);
}

function Clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}