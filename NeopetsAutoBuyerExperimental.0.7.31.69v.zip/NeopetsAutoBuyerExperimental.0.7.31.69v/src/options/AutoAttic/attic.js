AutoAttic();

async function AutoAttic(){
    const lastRefreshMs = await getVARIABLE("ATTIC_LAST_REFRESH_MS"),
          lastRefreshMoment = moment(lastRefreshMs);

    const date = document.getElementById("ATTIC_LAST_REFRESH_DATE"),
          time = document.getElementById("ATTIC_LAST_REFRESH_TIME");

    date.value = lastRefreshMoment.format("YYYY-MM-DD");
    time.value = lastRefreshMoment.format("HH:mm:ss");

    DisplayAtticTimes();
    setInterval(DisplayAtticTimes, 10000);

    // Updates the next possible windows in the GUI every 10 seconds;
    async function DisplayAtticTimes(){
        const now = new Date();
        const lastRestockTimeMs = await getVARIABLE("ATTIC_LAST_REFRESH_MS");
        var lastRestockingTime = new Date(lastRestockTimeMs);

        const windowTimes = CreateWaitTime(now, lastRestockingTime),
              startTime = windowTimes[0],
              endTime = windowTimes[1];

        console.log(windowTimes);

        const nextStartWindowElement = document.getElementById("ATTIC_NEXT_START_WINDOW"),
              nextEndWindowElement = document.getElementById("ATTIC_NEXT_END_WINDOW");

        nextStartWindowElement.value = moment(startTime).format("HH:mm:ss");
        nextEndWindowElement.value = moment(endTime).format("HH:mm:ss");

        const currentNextStartWindow = await getVARIABLE("ATTIC_NEXT_START_WINDOW"),
              currentNextEndWindow = await getVARIABLE("ATTIC_NEXT_END_WINDOW"),
              expectedStartWindow = startTime.getTime(),
              expectedEndWindow = endTime.getTime();

        // If the dates are the same, there's no need to write them;
        if(currentNextStartWindow == expectedStartWindow && currentNextEndWindow == expectedEndWindow) return;

        setVARIABLE("ATTIC_NEXT_START_WINDOW", startTime.getTime());
        setVARIABLE("ATTIC_NEXT_END_WINDOW", endTime.getTime());
    }

    UpdateAtticRefreshTimes();
  
    async function UpdateAtticRefreshTimes() {
        const atticDateValue = date.value;
        const atticTimeValue = time.value;

        if (atticDateValue !== "" && atticTimeValue !== "") {
            const timestamp = new Date(`${atticDateValue}T${atticTimeValue}`);

            await setVARIABLE("ATTIC_LAST_REFRESH_MS", timestamp.getTime());
            await setVARIABLE("ATTIC_PREV_NUM_ITEMS", 24);
            DisplayAtticTimes();
        }
    }

    $("#ATTIC_LAST_REFRESH_DATE").on("change", (function () {
        UpdateAtticRefreshTimes();
    }));
    
    $("#ATTIC_LAST_REFRESH_TIME").on("change", (function () {
        UpdateAtticRefreshTimes()
    }));
}
