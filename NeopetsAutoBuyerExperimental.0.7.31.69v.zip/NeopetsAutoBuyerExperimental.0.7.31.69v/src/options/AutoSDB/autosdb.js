// GUI Interaction;
const tableContainer = document.getElementById("table-container");

// DisplayChunkData.js
const chunkSize = 30;

async function GetDatabase(){
    const database = await getVARIABLE("DATABASE");

    return database;
}

GetDatabase().then(database => {

    //Update the history data every 5 seconds;
    ProcessPurchaseHistory(false), setInterval((function() {
        ProcessPurchaseHistory(false)
    }), 5e3)

    // Initial load
    LoadCurrentPage();

    LoadCurrentPage = function(){
        ProcessPurchaseHistory(true);

        // Update navigation
        UpdateNavigation();
    }

    // GUI Functions;
    var currentHistorySize = -1;

    async function ProcessPurchaseHistory(forceUpdateHistory) {
        // Processing the history data;
        var sdbHistory = await getVARIABLE("SDB_HISTORY");

        setDEFAULT("SDB_LIST", []);
        setDEFAULT("SDB_HISTORY", []);

        var historySize = sdbHistory.length;
        
        var processedData = sdbHistory;

        // Force updating if necessary;
        if (forceUpdateHistory || currentHistorySize != historySize) {
            historySize = sdbHistory.length;

            processedData = sdbHistory.reverse();

            currentHistorySize = historySize;
            DisplayTableData(processedData, ["Est. Value", "JN"], chunkSize, FilterFunction);            
        }

        // Updating the page data;
        totalPages = Math.ceil(processedData.length / chunkSize);
        UpdateNavigation();
    }


    var totalProfit = 0, totalValue = 0;

    function FilterFunction(header, cell, data){
        switch (header) {
            case "Date & Time":
                cell.appendChild(document.createTextNode(data[0]));
                cell.classList.add('class-DateTime');

                if(IsDateWithinPast24Hours(new Date(data[0]))){
                    const deposit = data[1]["Deposit"];

                    if(deposit == "Stock") cell.classList.add('checked-row');
                    else if(deposit == "Deposit") cell.classList.add('deposit-row');
                    else cell.classList.add('gallery-row');
                } 
            break;

            case "Item Name":
                const name = document.createElement("div");
                name.innerText = data[0];
                cell.appendChild(name);
                lastName = data[0];
                cell.appendChild(name);
            break;

            case "Est. Value":
                console.log();

                var priceValue = parseInt(database[data[1]["Item Name"]]);
                var priceSpan = FormatNPNumber(priceValue);
                cell.appendChild(document.createTextNode(priceSpan));
            break;

            case "JN":
                // Create the <a> element
                var linkElement = document.createElement("a");
                linkElement.href = `https://items.jellyneo.net/search/?name=${lastName}&name_type=3`;

                // Create the <img> element
                var imgElement = document.createElement("img");
                imgElement.src = "../JN.png";
                imgElement.alt = "Info Icon";

                linkElement.appendChild(imgElement);

                cell.appendChild(linkElement);
                cell.classList.add('class-JellyNeo');
            break;

            default:
                cell.appendChild(document.createTextNode(data[0]));
            break;
        }

        return cell;

        function IsDateWithinPast24Hours(dateToCheck) {
            const now = new Date(); // Current date and time
            const past24Hours = new Date(now.getTime() - 24 * 60 * 60 * 1000); // Date and time 24 hours ago
        
            // Check if the dateToCheck is within the past 24 hours
            return dateToCheck >= past24Hours && dateToCheck <= now;
        }
    }

    // Handles the JN link of the item;
    function CreatePurchaseStatusSpan(cellValue){
        var statusSpan = document.createElement("a");
        statusSpan.innerText = cellValue;
        statusSpan.style.fontWeight = "bold";

        // Coloring the span based on the purchase interaction type;
        switch(cellValue){
            case "Bought":
                statusSpan.style.color = "#2196F3";
            break;

            default:
                statusSpan.style.color = "grey";
            break;
        }

        return statusSpan;
    }
});