// Create a select element
/*const selectElement = document.createElement('select');
selectElement.id = 'shopdropdown';*/

const selectElement = document.querySelectorAll(".shop-dropdown");

// Define an array of options (value, text)
const options = [
    { value: "1", text: "Neopian Fresh Foods" },
    { value: "2", text: "Kauvara's Magic Shop" },
    { value: "3", text: "Toy Shop" },
    { value: "4", text: "Unis Clothing Shop" },
    { value: "5", text: "Grooming Parlour" },
    { value: "7", text: "Magical Bookshop" },
    { value: "8", text: "Collectable Card Shop" },
    { value: "9", text: "Battle Magic" },
    { value: "10", text: "Defense Magic" },
    { value: "12", text: "Neopian Garden Centre" },
    { value: "13", text: "Neopian Pharmacy" },
    { value: "14", text: "Chocolate Factory" },
    { value: "15", text: "The Bakery" },
    { value: "16", text: "Neopian Health Foods" },
    { value: "17", text: "Neopian Gift Shop" },
    { value: "18", text: "Smoothie Store" },
    { value: "20", text: "Tropical Food" },
    { value: "21", text: "Tiki Tack" },
    { value: "22", text: "Grundos Cafe" },
    { value: "23", text: "Space Weaponry" },
    { value: "24", text: "Space Armour" },
    { value: "25", text: "Neopian Petpet Shop" },
    { value: "26", text: "Robo-Petpet Shop" },
    { value: "27", text: "The Rock Pool" },
    { value: "30", text: "Spooky Food" },
    { value: "31", text: "Spooky Petpets" },
    { value: "34", text: "The Coffee Cave" },
    { value: "35", text: "Slushie Shop" },
    { value: "36", text: "Ice Crystal Shop" },
    { value: "37", text: "Super Happy Icy Fun Snow Shop" },
    { value: "38", text: "Faerieland Bookshop" },
    { value: "39", text: "Faerie Foods" },
    { value: "40", text: "Faerieland Petpets" },
    { value: "41", text: "Neopian Furniture" },
    { value: "42", text: "Tyrannian Foods" },
    { value: "43", text: "Tyrannian Furniture" },
    { value: "44", text: "Tyrannian Petpets" },
    { value: "45", text: "Tyrannian Weaponry" },
    { value: "46", text: "Hubert's Hot Dogs" },
    { value: "47", text: "Pizzaroo" },
    { value: "48", text: "Usukiland" },
    { value: "49", text: "Lost Desert Foods" },
    { value: "50", text: "Peopatra's Petpets" },
    { value: "51", text: "Sutek's Scrolls" },
    { value: "53", text: "Neopian School Supplies" },
    { value: "54", text: "Sakhmet Battle Supplies" },
    { value: "55", text: "Osiri's Pottery" },
    { value: "56", text: "Merifoods" },
    { value: "57", text: "Ye Olde Petpets" },
    { value: "58", text: "Neopian Post Office" },
    { value: "59", text: "Haunted Weaponry" },
    { value: "60", text: "Spooky Furniture" },
    { value: "61", text: "Wintery Petpets" },
    { value: "62", text: "Jelly Foods" },
    { value: "63", text: "Refreshments" },
    { value: "66", text: "Kiko Lake Treats" },
    { value: "67", text: "Kiko Lake Carpentry" },
    { value: "68", text: "Collectable Coins" },
    { value: "69", text: "Petpet Supplies" },
    { value: "70", text: "Booktastic Books" },
    { value: "71", text: "Kreludan Homes" },
    { value: "72", text: "Cafe Kreludor" },
    { value: "73", text: "Kayla's Potion Shop" },
    { value: "74", text: "Darigan Toys" },
    { value: "75", text: "Faerie Furniture" },
    { value: "76", text: "Roo Island Souvenirs" },
    { value: "77", text: "Brightvale Books" },
    { value: "78", text: "The Scrollery" },
    { value: "79", text: "Brightvale Glaziers" },
    { value: "80", text: "Brightvale Armoury" },
    { value: "81", text: "Brightvale Fruits" },
    { value: "82", text: "Brightvale Motery" },
    { value: "83", text: "Royal Potionery" },
    { value: "84", text: "Neopian Music Shop" },
    { value: "85", text: "Lost Desert Medicine" },
    { value: "86", text: "Collectable Sea Shells" },
    { value: "87", text: "Maractite Marvels" },
    { value: "88", text: "Maraquan Petpets" },
    { value: "89", text: "Geraptiku Petpets" },
    { value: "90", text: "Qasalan Delights" },
    { value: "91", text: "Desert Arms" },
    { value: "92", text: "Words of Antiquity" },
    { value: "93", text: "Faerie Weapon Shop" },
    { value: "94", text: "Illustrious Armoury" },
    { value: "95", text: "Exquisite Ambrosia" },
    { value: "96", text: "Magical Marvels" },
    { value: "97", text: "Legendary Petpets" },
    { value: "98", text: "Plushie Palace" },
    { value: "99", text: "Altador Cup Souvenirs" },
    { value: "100", text: "Wonderous Weaponry" },
    { value: "101", text: "Exotic Foods" },
    { value: "102", text: "Remarkable Restoratives" },
    { value: "103", text: "Fanciful Fauna" },
    { value: "104", text: "Chesterdrawers' Antiques" },
    { value: "105", text: "The Crumpet Monger" },
    { value: "106", text: "Neovian Printing Press" },
    { value: "107", text: "Prigpants & Swolthy, Tailors" },
    { value: "108", text: "Mystical Surroundings" },
    { value: "110", text: "Lampwyck's Lights Fantastic" },
    { value: "111", text: "Cog's Togs" },
    { value: "112", text: "Molten Morsels" },
    { value: "113", text: "Moltaran Petpets" },
    { value: "114", text: "Moltaran Books" },
    { value: "116", text: "Springy Things" },
    { value: "117", text: "Ugga Shinies" },
];

selectElement.forEach(function(select){
    options.forEach(function(option){
        const optionElement = document.createElement('option'),
              value = option.value;
    
        optionElement.value = value;
        optionElement.text = value + "  -  " + option.text;
        select.appendChild(optionElement);
    });
});

//######################################################################################################################################

// Loading shop information;
var shopsTable = document.getElementById("data"),
    shopToVisitContainer = document.querySelector(".data-point"),
    shopToVisitContainerClone = shopToVisitContainer.cloneNode(true),
    containers;

// Adding the default row;
setTimeout(async function(){
    setDEFAULT("SHOPS_SETTINGS", {
        "0": {
            "refreshWhenCleared": false,
            "goForSecond": false,
            "minRefresh": 37500,
            "maxRefresh": 45000,
            "minUnstockedRefresh": 3500,
            "maxUnstockedRefresh": 5000,
            "minItemsToConsiderStocked": 1,
        }
    });

    shops = await getVARIABLE("SHOPS_SETTINGS");
    const keys = Object.keys(shops);

    if(keys.length == 0) {
        setVARIABLE("SHOPS_SETTINGS", {
            "0": {
                "refreshWhenCleared": false,
                "goForSecond": false,
                "minRefresh": 37500,
                "maxRefresh": 45000,
                "minUnstockedRefresh": 3500,
                "maxUnstockedRefresh": 5000,
                "minItemsToConsiderStocked": 1,
            }
        });

        shops = await getVARIABLE("SHOPS_SETTINGS");
    }
    

    Object.keys(shops).forEach(function(id){
        shopsTable.appendChild(CloneWithValues(shopToVisitContainerClone, id));
    });
    
    shopToVisitContainer.remove();
    
    /*shopToVisitContainer.classList.add("hidden");*/
    ProcessShopContainers();
}, 500)

// CloneWithValues(); Clone the default row with values;
function CloneWithValues(node, id, passDefault = false) {
    var shop;

    if(!passDefault) shop = shops[id];
    else {
        shop = {
            "1": {
                "refreshWhenCleared": false,
                "goForSecond": false,
                "minRefresh": 37500,
                "maxRefresh": 45000,
                "minUnstockedRefresh": 3500,
                "maxUnstockedRefresh": 5000,
                "minItemsToConsiderStocked": 1,
            }
        }["1"];
    }

    let clone = node.cloneNode(true);
    clone.classList.remove("hidden");
    
    // Get all form elements in the original node
    let originalElements = node.querySelectorAll('input, select, textarea');
    let clonedElements = clone.querySelectorAll('input, select, textarea');

    // Copy the values from the original elements to the cloned elements
    originalElements.forEach((element, index) => {
        const clonedElement = clonedElements[index];

        switch(index){
            case 0: clonedElement.value = id; break;
            case 1: clonedElement.checked = shop['refreshWhenCleared']; break;
            case 2: clonedElement.checked = shop['goForSecond']; break;
            case 3: clonedElement.value = shop['minRefresh']; break;
            case 4: clonedElement.value = shop['maxRefresh']; break;
            case 5: clonedElement.value = shop['minUnstockedRefresh']; break;
            case 6: clonedElement.value = shop['maxUnstockedRefresh']; break;
            case 7: clonedElement.value = shop['minItemsToConsiderStocked']; break;
        }

        clonedElement.addEventListener("change", function(){
            ProcessShopContainers(false);
        });
    });

    return clone;
}

// Add new shops to visit;
const addShopButton = document.getElementById("add-element");

addShopButton.addEventListener("click", function(){
    shopsTable.appendChild(CloneWithValues(shopToVisitContainer, 1, true));

    ProcessShopContainers();
});

ActivateExpandCollapseListeners("expand-elements", ".expand");

ActivateExpandCollapseListeners("collapse-elements", ".collapse");

var shops = {};

// ProcessShopContainers(); Process the information inside the containers;
function ProcessShopContainers(shouldCollapseTabs = true){
    shops = {};

    containers = document.querySelectorAll(".data-point");

    containers.forEach(function(element){
        const shopName = element.querySelector(".controller-name"),
              shopSelected = element.querySelector("select"),
              collapseButton = element.querySelector(".collapse"),
              expandButton = element.querySelector(".expand"),
              removeButton = element.querySelector(".remove"),
              tooltipButton = element.querySelector(".tooltip"),
              table = element.querySelector(".table");

        // Parse the shop name and display it in the corresponding row;
        DisplaySelectedShopName();

        shopSelected.addEventListener("change", function(){
            DisplaySelectedShopName();
        });

        // DisplaySelectedShopName(); Parse the shop name from the select element;
        function DisplaySelectedShopName(){
            var selectedShopName;

            try { 
                selectedShopName = shopSelected.options[shopSelected.selectedIndex].text.split(" - ")[1];
                shopName.textContent = selectedShopName;
            } catch {}
        }
        
    
        // Define the default state of buttons;
        if(shouldCollapseTabs){
            expandButton.classList.remove("hidden");
            collapseButton.classList.add("hidden");
            table.classList.add("hidden");
        }

        // Expand the selection;
        expandButton.addEventListener("click", function(){
            table.classList.remove("hidden");
            expandButton.classList.add("hidden");
            collapseButton.classList.remove("hidden");
        });

        // Collapse the selection;
        collapseButton.addEventListener("click", function(){
            table.classList.add("hidden");
            expandButton.classList.remove("hidden");
            collapseButton.classList.add("hidden");
        });
        
        // Remove the selection;
        removeButton.addEventListener("click", function(){
            if(!IsDefaultSettings(shopName)){
                element.remove();
                ProcessShopContainers();
            }
        });
    
        // Do not allow the user to delete the default row;
        if(IsDefaultSettings(shopName)){
            removeButton.classList.add("hidden");
            shopSelected.parentElement.parentElement.parentElement.classList.add("hidden");
        }

        if(!element.classList.contains("hidden")) ProcessShopObject(element);
    });

    setVARIABLE("SHOPS_SETTINGS", shops);
}

function IsDefaultSettings(shopName){
    return shopName.textContent == "Default Settings";
}

function ProcessShopObject(element){
    const shopSelect = element.querySelector(".shop-dropdown"),
          inputs = element.querySelectorAll("input");

    var selectedShopValue = shopSelect.value,
          settings = [];

    inputs.forEach(function(input){
        if(input.type == "number"){
            settings.push(Number(input.value));
        } else {
            settings.push(input.checked);
        }
    });

    if(selectedShopValue == "") selectedShopValue = 0;

    var shop = {
        id: selectedShopValue,
        refreshWhenCleared: settings[0],
        goForSecond: settings[1],
        minRefresh: settings[2],
        maxRefresh: settings[3],
        minUnstockedRefresh: settings[4],
        maxUnstockedRefresh: settings[5],
        minItemsToConsiderStocked: settings[6]
    }

    shops[shop.id] = {
        refreshWhenCleared: shop.refreshWhenCleared,
        goForSecond: shop.goForSecond,
        minUnstockedRefresh: shop.minUnstockedRefresh,
        maxUnstockedRefresh: shop.maxUnstockedRefresh,
        minRefresh: shop.minRefresh,
        maxRefresh: shop.maxRefresh,
        minItemsToConsiderStocked: shop.minItemsToConsiderStocked
    };

    return shop;
}