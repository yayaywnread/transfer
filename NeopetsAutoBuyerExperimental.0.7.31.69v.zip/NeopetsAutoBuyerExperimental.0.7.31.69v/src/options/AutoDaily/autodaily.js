AutoDaily();

async function AutoDaily(){
    CheckIfUserLoadedPets();

    // Navigating to Quickref Page for Pet Loading;
    const loadPetsButton = document.getElementById("loadPetData");

    loadPetsButton.addEventListener('click', StartLoadOwnedPetsProcess);

    ProcessPetData("DESTINATION_PET", "OWNED_PETS");


    //######################################################################################################################################


    // DisplayChunkData.js
    const chunkSize = 30;

    // Initial load
    LoadCurrentPage();

    LoadCurrentPage = function(){
        ProcessAutoDaily(true)

        // Update navigation
        UpdateNavigation();
    }


    var currentHistorySize = -1;
    tableContainer = document.getElementById("table-container"),
    kqTracker = await getVARIABLE("AUTODAILY_TRACKER");

    async function ProcessAutoDaily(forceUpdateHistory) {
        const history = kqTracker;
        const historySize = history.length;

        // Force updating if necessary;
        if (forceUpdateHistory || currentHistorySize != historySize) {
            currentHistorySize = historySize;
            DisplayTableData(history, ["JN"], chunkSize, FilterFunction);
        }

        // Updating the page data;
        totalPages = Math.ceil(history.length / chunkSize);
        UpdateNavigation();
    }

    function FilterFunction(header, cell, data){    
        // Setting the information nodes in the table cells;
        switch(header){
            case "Account":
                cell.appendChild(document.createTextNode(data[0]));
                cell.classList.add('class-DateTime');
            break;

            case "Date & Time":
                cell.appendChild(document.createTextNode(data[0]));
                cell.classList.add('class-DateTime');
            break;

            case "Pet Name":
                cell.appendChild(document.createTextNode(data[0]));
                cell.classList.add('class-DateTime');
            break;

            case "Prize":
                cell.appendChild(document.createTextNode(data[0]));
                cell.classList.add('class-Prize');
            break;

            case "Quest Type":
                if(data[0] == ""){
                    data[0] = 0;
                }

                var result = "";

                switch (data[0]){
                    default: result = "Purchase"; break;
                    case 1: result = "Wheel"; break;
                    case 2: result = "Game"; break;
                    case 3: result = "Feed"; break;
                    case 4: result = "Groom"; break;
                    case 5: result = "Customise"; break;
                }

                cell.appendChild(document.createTextNode(result));
                cell.classList.add('class-Type');
            break;

            case "JN":
                if(data[1].Prize != "Neopoints"){
                    var itemName = data[1].Prize;

                    // Create the <a> element
                    var linkElement = document.createElement("a");
                    linkElement.href = `https://items.jellyneo.net/search/?name=${itemName}&name_type=3`;

                    // Create the <img> element
                    var imgElement = document.createElement("img");
                    imgElement.src = "../JN.png";
                    imgElement.alt = "Info Icon";

                    linkElement.appendChild(imgElement);

                    cell.appendChild(linkElement);
                    cell.classList.add('class-JellyNeo');
                }
            break;

            default:
                cell.appendChild(document.createTextNode(data[0]));
            break;
        }

        return cell;
    }

    //######################################################################################################################################

    //Update the history data every 5 seconds;
    ProcessAutoDaily(false), setInterval((function() {
        ProcessAutoDaily(false)
    }), 5e3);
}