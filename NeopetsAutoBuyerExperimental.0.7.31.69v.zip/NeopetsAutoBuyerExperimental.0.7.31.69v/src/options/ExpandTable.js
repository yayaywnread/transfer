const dataContainer = document.getElementById("data");

const dataPoint = document.querySelector(".data-point"),
      dataPointClone = dataPoint.cloneNode(true);

dataPoint.remove();

const addElement = document.getElementById("add-element");

addElement.addEventListener("click", function(){
    AddListenerLogic().then(clone => {
        dataContainer.appendChild(clone);
    });
});

function AddListenerLogic(){
    const clone = dataPointClone.cloneNode(true);

    HandleVisualControllers(clone, true);

    return clone;
}

function HandleVisualControllers(clone, canDeleteAllData = false, isCollapsingData = false){
    const table = clone.querySelector(".table"),
          collapse = clone.querySelector(".collapse"),
          expand = clone.querySelector(".expand"),
          remove = clone.querySelector(".remove"),
          name = clone.querySelector(".controller-name");

    // Collapse the selection;
    collapse.addEventListener("click", function(){
        table.classList.add("hidden");
        expand.classList.remove("hidden");
        collapse.classList.add("hidden");
    });

    // Expand the selection;
    expand.addEventListener("click", function(){
        table.classList.remove("hidden");
        expand.classList.add("hidden");
        collapse.classList.remove("hidden");
    });
    
    // Remove the selection;
    remove.addEventListener("click", function(){
        if(!IsDefault(name)){
            clone.remove();
            ProcessDataPoints();
        }
    });

    // Define the default state of buttons;
    if(isCollapsingData) collapse.click();

    function IsDefault(){
        if(canDeleteAllData){
            return false;
        } else {
            return document.querySelectorAll(".data-point").length == 1;
        }
    }
}

function ProcessDataPoints(){
    console.log("Data Processed!");
}

function ActivateExpandCollapseListeners(buttonSelector, classSelector){
    const button = document.getElementById(buttonSelector);

    button.addEventListener("click", function(){
        const dataRows = document.querySelectorAll(".data-point");

        dataRows.forEach(function(element){
            if(!element.classList.contains("hidden")){
                const button = element.querySelector(classSelector);

                button.click();
            }
        });
    });
}

ActivateExpandCollapseListeners("expand-elements", ".expand");

ActivateExpandCollapseListeners("collapse-elements", ".collapse");

var objects;