const tableContainer = document.getElementById("table-container");

LoadDatabaseData();

async function LoadDatabaseData(){
    // Calling and counting the database dataset;
    const database = await getVARIABLE("DATABASE_ARRAY"),
          itemCount = Object.keys(database).length;

    const dbCount = document.getElementById("item-count");

    dbCount.innerText = itemCount;
    
    // Last update of the database;
    setDEFAULT("DATABASE_LAST_UPDATE", new Date().getTime());
    const lastUpdate = document.getElementById("update-date");

    const options = { day: 'numeric', month: 'long', year: 'numeric' };
    lastUpdate.innerText = new Date(await getVARIABLE("DATABASE_LAST_UPDATE")).toLocaleDateString('en-US', options);

    // DisplayChunkData.js
    const chunkSize = 500;
    totalPages = Math.ceil(itemCount / chunkSize);

    LoadCurrentPage = function(){
        DisplayTableData(database, ["JN"], chunkSize, FilterFunction);

        // Update navigation
        UpdateNavigation();
    }

    function FilterFunction(header, cell, data){
        switch (header) {
            case "Name":
                const name = document.createElement("div");
                name.innerText = data[0];
                cell.appendChild(name);
                lastName = data[0];
                cell.classList.add('class-Name');
            break;
            
            case "Rarity":
                cell.textContent = data[0];
                cell.classList.add('class-Rarity');
            break;

            case "Price":
                const price = data[0],
                      formattedPrice = NumberWithCommas(price) + " NP";

                var priceToInput;

                if(price == "Unpriced") priceToInput = price;
                else priceToInput = formattedPrice

                cell.textContent = priceToInput;
                cell.classList.add('class-Price');
            break;

            case "JN":
                // Create the <a> element
                var linkElement = document.createElement("a");
                linkElement.href = `https://items.jellyneo.net/search/?name=${lastName}&name_type=3`;

                // Create the <img> element
                var imgElement = document.createElement("img");
                imgElement.src = "../JN.png";
                imgElement.alt = "Info Icon";

                linkElement.appendChild(imgElement);

                cell.appendChild(linkElement);
                cell.classList.add('class-JellyNeo');
            break;
        }

        function NumberWithCommas(e) {
            return e.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")
        }

        return cell;
    }

    LoadCurrentPage();
}