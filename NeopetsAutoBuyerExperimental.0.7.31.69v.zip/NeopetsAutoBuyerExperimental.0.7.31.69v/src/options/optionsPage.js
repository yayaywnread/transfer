function setCLICK_ITEM(_) { chrome.storage.local.set({CLICK_ITEM: _}, (function () {})) }
function setCLICK_CONFIRM(_) { chrome.storage.local.set({CLICK_CONFIRM: _}, (function () {})) }
function setSHOULD_GO_FOR_SECOND_MOST_VALUABLE(_) { chrome.storage.local.set({SHOULD_GO_FOR_SECOND_MOST_VALUABLE: _}, (function () {})) }
function setSTORES_TO_CYCLE_THROUGH_WHEN_STOCKED(_) { chrome.storage.local.set({STORES_TO_CYCLE_THROUGH_WHEN_STOCKED: _}, (function () {})) }
function setPAUSE_BETWEEN_MINUTES(_) { chrome.storage.local.set({PAUSE_BETWEEN_MINUTES: _}, (function () {})) }
function setRESTOCK_LIST(_) { chrome.storage.local.set({RESTOCK_LIST: _}, (function () {})) }
function setBLACKLIST(_) { chrome.storage.local.set({BLACKLIST: _}, (function () {})) }

function UpdateDateTimeInputs(firstInputTime, isAttic = true, secondInputTime = "", thirdInputTime = "") {
  var firstDate = moment(firstInputTime)
      .tz("America/Los_Angeles")
      .format("YYYY-MM-DD"),

    firstTime = ProcessTimezone(firstInputTime);

  if(isAttic){
    $("#ATTIC_LAST_REFRESH_DATE").val(firstDate);
    $("#ATTIC_LAST_REFRESH_TIME").val(firstTime);

    var secondTime = ProcessTimezone(secondInputTime);
    var thirdTime = ProcessTimezone(thirdInputTime);

    $("#RUN_AUTOATTIC_FROM").val(secondTime);
    $("#RUN_AUTOATTIC_TO").val(thirdTime);
  } else {
    var secondTime = ProcessTimezone(secondInputTime);

      $("#RUN_AUTOBUYER_FROM").val(firstTime);
      $("#RUN_AUTOBUYER_TO").val(secondTime);
  }

  function ProcessTimezone(time){
    return moment(time)
    .tz("America/Los_Angeles")
    .format("YYYY-MM-DD HH:mm:ss")
    .split(" ")[1];
  }
}

function ShowOrHide() {
  // Handle checkbox toggles
  if($("#USE_ITEM_DB").is(":checked") || $("#ATTIC_USE_ITEM_DB").is(":checked")) {
    $(".db-hide").removeClass("hidden");
    $(".restock-hide").addClass("hidden");
    $("#USE_BLACKLIST").is(":checked") ? $(".blacklist-hide").removeClass("hidden") : $(".blacklist-hide").addClass("hidden");
  } else {
    $(".db-hide").addClass("hidden");
    $(".restock-hide").removeClass("hidden");
    $("#USE_BLACKLIST").addClass("hidden");
  }

  toggleVisibility("#CLICK_ITEM", ".click-hide");
  toggleVisibility("#ATTIC_CLICK_ITEM", ".attic-click-hide");
  toggleVisibility("#ATTIC_SHOULD_REFRESH", ".attic-refresh-hide");
  toggleVisibility("#CLICK_CONFIRM", ".confirm-hide");

  if($("#CLICK_CONFIRM").is(":checked")){
    if($("#SHOULD_BYPASS_CONFIRM").is(":checked")){
      $(".bypass-hide").addClass("hidden");
    } else {
      $(".bypass-hide").removeClass("hidden");
    }
  } else {
    $(".bypass-hide").addClass("hidden");
  }  
  
  const shouldEnterOffer = $("#SHOULD_ENTER_OFFER").is(":checked"),
        shouldUseSimplerHaggles = $("#SHOULD_USE_SIMPLER_HAGGLES").is(":checked"),
        shouldUseCustomMultipliers = $("#SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS").is(":checked");

  if (shouldEnterOffer) {
    $(".offer-hide").removeClass("hidden");

    if(!shouldUseSimplerHaggles){
      $(".complex-hide").removeClass("hidden");

      if(shouldUseCustomMultipliers){
        $(".haggle-hide").removeClass("hidden");
      } else {
        $(".haggle-hide").addClass("hidden");
      }
    } else {
      $(".complex-hide").addClass("hidden");

      $("#SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS").prop("checked", false);
      setVARIABLE("SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS", false)
    }
  } else {
    $(".offer-hide").addClass("hidden");
  }

  toggleVisibility("#ATTIC_ENABLED", ".attic-settings");
  toggleVisibility("#SHOULD_ENTER_PIN", ".enter-pin");
  toggleVisibility("#USE_BLACKLIST_SW", ".blacklist-sw");
  toggleVisibility("#USE_BLACKLIST_KQ", ".blacklist-kq");
  toggleVisibility("#SHOULD_SUBMIT_AUTOMATICALLY", ".submit-automatically");
  toggleVisibility("#SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES", ".refresh-hide");
  toggleVisibility("#SHOULD_CLICK_NEOPET", ".captcha-hide");

  // Handle turbo toggles
  toggleVisibility("#IS_TURBO", ".turbo-tag", ".turbo-hide");

  // Handle resubmit type
  switchVisibility("#RESUBMIT_TYPE", ".resubmit-random", ".resubmit-absolute");

  switch ($("#PRICING_TYPE").val()) {
    case "Absolute":
      $(".percentage").addClass("hidden");
      $(".absolute").removeClass("hidden");

      HideFixedPricingSections();
      break;

    case "Percentage":
      $(".percentage").removeClass("hidden");
      $(".absolute").addClass("hidden");

      HidePricingPercentageSections();
      break;

    default:
      $(".percentage").removeClass("hidden");
      $(".absolute").removeClass("hidden");

      HidePricingPercentageSections();
      HideFixedPricingSections();
      break;
  }
}

function toggleVisibility(selector, showSelector, hideSelector = null, additionalConditionSelector = null) {
  if ($(selector).is(":checked")) {
    $(showSelector).removeClass("hidden");
    if (hideSelector) {
      $(hideSelector).addClass("hidden");
    }
    if (additionalConditionSelector && !$(additionalConditionSelector).is(":checked")) {
      $(showSelector).addClass("hidden");
    }
  } else {
    $(showSelector).addClass("hidden");
    if (hideSelector) {
      $(hideSelector).removeClass("hidden");
    }
  }
}

function switchVisibility(selector, showSelector, hideSelector, showCallback = null, hideCallback = null) {
  switch ($(selector).val()) {
    case "Absolute":
      $(showSelector).removeClass("hidden");
      $(hideSelector).addClass("hidden");
      if (hideCallback) hideCallback();
      break;
    case "Percentage":
      $(showSelector).addClass("hidden");
      $(hideSelector).removeClass("hidden");
      if (showCallback) showCallback();
      break;
    default:
      $(showSelector).removeClass("hidden");
      $(hideSelector).removeClass("hidden");
      if (showCallback) showCallback();
      if (hideCallback) hideCallback();
      break;
  }
}

function HidePricingPercentageSections() {
  if ($("#SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING").is(":checked")) {
    $(".random-percentage").removeClass("hidden");
    $(".fixed-percentage").addClass("hidden");
  } else {
    $(".random-percentage").addClass("hidden");
    $(".fixed-percentage").removeClass("hidden");
  }
}

function HideFixedPricingSections() {
  switch ($("#FIXED_PRICING_ALGORITHM_TYPE").val()) {
    case "True Absolute":
      $(".fixed-absolute").removeClass("hidden");
      $(".random-absolute").addClass("hidden");
      break;

    case "Random Absolute":
      $(".random-absolute").removeClass("hidden");
      $(".fixed-absolute").addClass("hidden");
      break;

    default:
      $(".random-absolute").removeClass("hidden");
      $(".fixed-absolute").removeClass("hidden");
      break;
  }
}

function SwitchOption(variable, shouldShowOrHide = false){
  const variableName = `#${variable}`;

  $(variableName).on("change", function () {
    const isChecked = $(variableName).is(":checked");
    if(shouldShowOrHide) ShowOrHide();
    setVARIABLE(variable, isChecked);
  });
}

function ValueOption(variable, shouldShowOrHide = false){
  const variableName = `#${variable}`;

  $(variableName).bind("input propertychange", (function () {
    if(shouldShowOrHide) ShowOrHide();
    setVARIABLE(variable, $(variableName).val());
  }));
}

function ListOption(variable){
  const variableName = `#${variable}`;

  $(variableName).bind("input propertychange", (function () {
    try {
      const list = $(variableName).val().split("\n").map((_ => _.trim())).filter((_ => "" != _));

      setVARIABLE(variable, list);
    } catch (_) {
      window.alert("Error in parsing your blacklist: " + _)
    }
  }));
}

SwitchOption("USE_BLACKLIST", true);
SwitchOption("SHOULD_SHOW_CHROME_NOTIFICATIONS");
SwitchOption("SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES", true);
ValueOption("BUY_UNKNOWN_ITEMS_PROFIT");

ListOption("BLACKLIST");

SwitchOption("ATTIC_CLICK_ITEM", true);
SwitchOption("ATTIC_HIGHLIGHT");
SwitchOption("ATTIC_SHOULD_REFRESH", true);
SwitchOption("ATTIC_ENABLED", true);
ValueOption("ATTIC_MIN_REFRESH");
ValueOption("ATTIC_MAX_REFRESH");

ValueOption("ATTIC_ITEM_DB_MIN_PROFIT_NPS");
ValueOption("ATTIC_ITEM_DB_MIN_PROFIT_PERCENT");
ValueOption("ATTIC_MIN_BUY_TIME");
ValueOption("ATTIC_MAX_BUY_TIME");

ListOption("RESTOCK_LIST");

ValueOption("MIN_REFRESH");
ValueOption("MAX_REFRESH");
ValueOption("MIN_REFRESH_STOCKED");
ValueOption("MAX_REFRESH_STOCKED");
ValueOption("ITEM_DB_MIN_PROFIT_NPS");
ValueOption("ITEM_DB_MIN_PROFIT_PERCENT");

ValueOption("ITEMS_TO_CONSIDER_STOCKED");
ValueOption("MIN_CLICK_ITEM_IMAGE");
ValueOption("MAX_CLICK_ITEM_IMAGE");
ValueOption("MIN_CLICK_CONFIRM");
ValueOption("MAX_CLICK_CONFIRM");
ValueOption("MIN_OCR_PAGE");
ValueOption("MAX_OCR_PAGE");

$("#PAUSE_BETWEEN_MINUTES").bind("input propertychange", (function () {
  try {
    var _ = JSON.parse($("#PAUSE_BETWEEN_MINUTES").val());
    (!Array.isArray(_) || _.length < 2 || _.length % 2 !== 0) && (_ = []), _[0] < 0 && (_[0] = 0), _[1] > 59 && (_[1] = 59), _[1] < 0 && (_[1] = 0), _[0] > 59 && (_[0] = 59), _[0] > _[1] && (_ = []), setPAUSE_BETWEEN_MINUTES(_)
  } catch (_) {}
}));
$("#STORES_TO_CYCLE_THROUGH_WHEN_STOCKED").bind("input propertychange", (function () {
  try {
    setSTORES_TO_CYCLE_THROUGH_WHEN_STOCKED(JSON.parse($("#STORES_TO_CYCLE_THROUGH_WHEN_STOCKED").val()));
  } catch (_) {}
}));

SwitchOption("ENABLED", true);
SwitchOption("HIGHLIGHT");

$("#CLICK_ITEM").on("change", (function () {
  setCLICK_ITEM($("#CLICK_ITEM").is(":checked"));
  $("#CLICK_ITEM").is(":checked") || ($("#SHOULD_GO_FOR_SECOND_MOST_VALUABLE").prop("checked", !1), setSHOULD_GO_FOR_SECOND_MOST_VALUABLE(!1));
  ShowOrHide();
}));

$("#SHOULD_GO_FOR_SECOND_MOST_VALUABLE").on("change", (function () {
  setSHOULD_GO_FOR_SECOND_MOST_VALUABLE($("#SHOULD_GO_FOR_SECOND_MOST_VALUABLE").is(":checked"));
  $("#SHOULD_GO_FOR_SECOND_MOST_VALUABLE").is(":checked") && ($("#CLICK_ITEM").prop("checked", !0), setCLICK_ITEM(!0));
}));

$("#CLICK_CONFIRM").on("change", (function () {
  const isChecked = $("#CLICK_CONFIRM").is(":checked");

  if(!isChecked){
    setSHOULD_BYPASS_CONFIRM(false);
  }

  setCLICK_CONFIRM(isChecked);
  ShowOrHide();
}));

SwitchOption("SHOULD_SHOW_BANNER");
SwitchOption("USE_ITEM_DB", true);
SwitchOption("SHOULD_CLICK_NEOPET", true);
SwitchOption("SHOULD_ANNOTATE_IMAGE");
SwitchOption("SHOULD_SOUND_ALERTS");
SwitchOption("SHOULD_ENTER_OFFER", true);
ValueOption("PAUSE_AFTER_BUY_MS");


//######################################################################################################################################

// AutoBuyer Setters;
function setSHOULD_BYPASS_CONFIRM(value) { chrome.storage.local.set({SHOULD_BYPASS_CONFIRM: value}, (function () {})) }

//AutoAttic Setters;
function setATTIC_RESTOCK_LIST(value) { chrome.storage.local.set({ATTIC_RESTOCK_LIST: value}, (function () {})) }

// AutoSDB Setters
function setGALLERY_LIST(value) { chrome.storage.local.set({GALLERY_LIST: value}, (function () {})) }

// AutoPricer Setters;
function setBLACKLIST_SW(value) { chrome.storage.local.set({BLACKLIST_SW: value}, (function() {})) }

// AutoKQ Setters;
function setBLACKLIST_KQ(value) { chrome.storage.local.set({BLACKLIST_KQ: value}, (function() {})) }

// AutoBuyer Setters;

/*$("#RUN_AUTOBUYER_FROM").on("change", (function () {
  updateLastRefreshMs()
}));

$("#RUN_AUTOBUYER_TO").on("change", (function () {
  updateLastRefreshMs()
}));*/

ValueOption("MIN_FIVE_SECOND_RULE_REFRESH");
ValueOption("MAX_FIVE_SECOND_RULE_REFRESH");

$("#SHOULD_BYPASS_CONFIRM").on("change", function () {
  const isChecked = $("#SHOULD_BYPASS_CONFIRM").is(":checked");
  setSHOULD_BYPASS_CONFIRM(isChecked);

  // Setting the min and max click confirms to not override the bypass clicks;
  if(isChecked){
    setVARIABLE("MIN_CLICK_CONFIRM", 10000);
    setVARIABLE("MAX_CLICK_CONFIRM", 10000);
  }

  ShowOrHide();
});

SwitchOption("SHOULD_OPEN_NEW_TABS_FOR_HAGGLING");
SwitchOption("SHOULD_ONLY_REFRESH_ON_CLEAR");
SwitchOption("SHOULD_MULTICLICK_CAPTCHA");
SwitchOption("SHOULD_USE_SIMPLER_HAGGLES", true);
SwitchOption("SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS", true);

ValueOption("MIN_HAGGLE_POWER");
ValueOption("MAX_HAGGLE_POWER");
SwitchOption("SHOULD_TAKE_SCREENSHOTS");
SwitchOption("SHOULD_CHANGE_DOCUMENT_DATA");

// AutoAttic Data Binding;

/*$("#RUN_AUTOATTIC_FROM").on("change", (function () {
  updateLastRefreshMs()
}));

$("#RUN_AUTOATTIC_TO").on("change", (function () {
  updateLastRefreshMs()
}));*/

SwitchOption("ATTIC_SHOULD_GO_FOR_SECOND_MOST_VALUABLE", true);
ListOption("ATTIC_RESTOCK_LIST");
SwitchOption("ATTIC_USE_ITEM_DB", true);

// AutoSDB Data Binding;

SwitchOption("AUTOSDB_ENABLED");

ValueOption("MIN_SUBMIT_QUICKSTOCK");
ValueOption("MAX_SUBMIT_QUICKSTOCK");

ListOption("GALLERY_LIST");

// AutoPricer Data Binding;

SwitchOption("SHOULD_USE_NEON", true);
ValueOption("MAX_WAIT_PER_REFRESH");
SwitchOption("SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING", true);
ValueOption("FIXED_PRICING_PERCENTAGE");
ValueOption("MIN_PRICING_PERCENTAGE");
ValueOption("MAX_PRICING_PERCENTAGE");
ValueOption("MIN_WAIT_PER_REFRESH");
ValueOption("MAX_WAIT_PER_REFRESH");
ValueOption("RESUBMIT_TYPE", true);
ValueOption("MIN_RESUBMITS_PER_ITEM");
ValueOption("MAX_RESUBMITS_PER_ITEM");
ValueOption("RESUBMITS_PER_ITEM");
ValueOption("MIN_RESUBMIT_WAIT_TIME");
ValueOption("MAX_RESUBMIT_WAIT_TIME");
ValueOption("MIN_NEW_SEARCH_WAIT_TIME");
ValueOption("MAX_NEW_SEARCH_WAIT_TIME");
SwitchOption("USE_BLACKLIST_SW", true);

ListOption("BLACKLIST_SW");

SwitchOption("SHOULD_SUBMIT_AUTOMATICALLY");
SwitchOption("SHOULD_IMPORT_SALES");
ValueOption("MIN_WAIT_AFTER_PRICING_ITEM");
ValueOption("MAX_WAIT_AFTER_PRICING_ITEM");
ValueOption("MIN_SHOP_NAVIGATION_COOLDOWN");
ValueOption("MAX_SHOP_NAVIGATION_COOLDOWN");
ValueOption("MIN_SHOP_SEARCH_FOR_INPUT_BOX");
ValueOption("MAX_SHOP_SEARCH_FOR_INPUT_BOX");
ValueOption("MIN_SHOP_CLICK_UPDATE");
ValueOption("MAX_SHOP_CLICK_UPDATE");
ValueOption("MIN_TYPING_SPEED");
ValueOption("MAX_TYPING_SPEED");
SwitchOption("SHOULD_ENTER_PIN", true);
ValueOption("NEOPETS_SECURITY_PIN");
ValueOption("MIN_WAIT_BEFORE_UPDATE");
ValueOption("MAX_WAIT_BEFORE_UPDATE");
ValueOption("MIN_WAIT_BAN_TIME");
ValueOption("MAX_WAIT_BAN_TIME");
ValueOption("MIN_PAGE_LOAD_FAILURES");
ValueOption("MAX_PAGE_LOAD_FAILURES");
ValueOption("PRICING_TYPE", true);
ValueOption("PERCENTAGE_PRICING_ALGORITHM_TYPE", true);
ValueOption("FIXED_PRICING_ALGORITHM_TYPE", true);
ValueOption("FIXED_PRICING_VALUE");
ValueOption("MIN_FIXED_PRICING");
ValueOption("MAX_FIXED_PRICING");
SwitchOption("SHOULD_CHECK_IF_FROZEN_SHOP");

// AutoKQ Data Binding;

ValueOption("MAX_INSTA_BUY_PRICE");
ValueOption("MAX_SPENDABLE_PRICE");
SwitchOption("USE_BLACKLIST_KQ", true);
SwitchOption("SHOULD_DELETE_SHOP_LAYOUTS");

ListOption("BLACKLIST_KQ");

// AutoBD;

SwitchOption("AUTOBD_ENABLED");

//AutoDaily;

SwitchOption("AUTODAILY_ENABLED");

function setAUTODAILY_LIST(value) { chrome.storage.local.set({AUTODAILY_LIST: value}, (function () {})) }

ListOption("AUTODAILY_LIST");

ValueOption("MIN_WAIT_ACCEPT_QUEST");
ValueOption("MAX_WAIT_ACCEPT_QUEST");

// Miscellaneous Data Binding;

SwitchOption("SHOULD_SHARE_STORES_TO_VISIT");
SwitchOption("SHOULD_SHARE_RESTOCK_LIST");
SwitchOption("SHOULD_SHARE_SHOP_STOCK");
SwitchOption("SHOULD_SHARE_SALES_HISTORY");
SwitchOption("SHOULD_SHARE_BLACKLISTS");
SwitchOption("SHOULD_SHARE_PIN");
SwitchOption("SHOULD_SHARE_ATTIC_LAST_REFRESH");
SwitchOption("SHOULD_SHARE_HISTORY");
SwitchOption("SHOULD_SHARE_AUTOKQ_LOG");
SwitchOption("SHOULD_SHARE_NEOBUYER_MAILS");


// The Void Within

async function TheVoidWithinData(){
  ValueOption("MIN_TVW_VISIT");
  ValueOption("MAX_TVW_VISIT");
  SwitchOption("IS_RUNNING_TVW_PROCESS");
  SwitchOption("TVW_AUTOBD_ENABLED");
}

TheVoidWithinData();

//######################################################################################################################################


function confirmReset() {
  if (confirm("Do you want to reset all your AutoBuyer+ settings?")) {
    if (confirm("Are you sure you want reset all your AutoBuyer+ settings? This action cannot be undone unless you have a backup of you configuration presets.")) {
      resetSettings();
    }
  }
}

function resetSettings() {
  chrome.storage.local.get(null, function (items) {
    var keysToRemove = Object.keys(items);
    chrome.storage.local.remove(keysToRemove, function () {
      console.log("Settings cleared");
      location.reload();
    });
  });
}

var resetButton = document.getElementById("reset");

chrome.storage.local.get({
  SEND_TO_SDB_AFTER_PURCHASE: !1,
  BUY_UNKNOWN_ITEMS_PROFIT: 1e5,
  ITEM_DB_MIN_RARITY: 1,
  USE_BLACKLIST: !1,
  BLACKLIST: [],
  ENABLED: !0,
  USE_ITEM_DB: !0,
  ITEM_DB_MIN_PROFIT_NPS: 1e4,
  ITEM_DB_MIN_PROFIT_PERCENT: .5,
  HIGHLIGHT: !0,
  CLICK_ITEM: !0,
  CLICK_CONFIRM: !0,
  SHOULD_SHOW_BANNER: !0,
  MIN_REFRESH: 3500,
  MAX_REFRESH: 5000,
  MIN_REFRESH_STOCKED: 37500,
  MAX_REFRESH_STOCKED: 45000,
  ITEMS_TO_CONSIDER_STOCKED: 1,
  MIN_CLICK_ITEM_IMAGE: 500,
  MAX_CLICK_ITEM_IMAGE: 1e3,
  MIN_CLICK_CONFIRM: 100,
  MAX_CLICK_CONFIRM: 200,
  MIN_OCR_PAGE: 750,
  MAX_OCR_PAGE: 1100,
  SHOULD_CLICK_NEOPET: !0,
  SHOULD_ANNOTATE_IMAGE: !0,
  SHOULD_SOUND_ALERTS: !0,
  SHOULD_ENTER_OFFER: !0,
  SHOULD_GO_FOR_SECOND_MOST_VALUABLE: !1,
  STORES_TO_CYCLE_THROUGH_WHEN_STOCKED: [2, 58],
  PAUSE_BETWEEN_MINUTES: [],
  RESTOCK_LIST: defaultDesiredItems,
  ATTIC_ENABLED: !0,
  ATTIC_HIGHLIGHT: !0,
  ATTIC_CLICK_ITEM: !0,
  ATTIC_ITEM_DB_MIN_PROFIT_NPS: 1e4,
  ATTIC_ITEM_DB_MIN_PROFIT_PERCENT: .5,
  ATTIC_MIN_BUY_TIME: 500,
  ATTIC_MAX_BUY_TIME: 1e3,
  ATTIC_MIN_REFRESH: 2500,
  ATTIC_MAX_REFRESH: 3500,
  ATTIC_SHOULD_REFRESH: !1,
  ATTIC_LAST_REFRESH_MS: -1,
  SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES: !0,
  SHOULD_SHOW_CHROME_NOTIFICATIONS: !0,
  PAUSE_AFTER_BUY_MS: 18000,

  // AutoBuyer;
  RUN_AUTOBUYER_FROM_MS: 1712473200000,
	RUN_AUTOBUYER_TO_MS: 1712559599000,
  MIN_FIVE_SECOND_RULE_REFRESH: 5000,
  MAX_FIVE_SECOND_RULE_REFRESH: 10000,
  SHOULD_BYPASS_CONFIRM: false,
  SHOULD_OPEN_NEW_TABS_FOR_HAGGLING: false,
  SHOULD_ONLY_REFRESH_ON_CLEAR: false,
  SHOULD_MULTICLICK_CAPTCHA: false,
  SHOULD_USE_SIMPLER_HAGGLES: true,
  SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS: false,
  MIN_HAGGLE_POWER: 0.75,
  MAX_HAGGLE_POWER: 0.85,
  SHOULD_CHANGE_DOCUMENT_DATA: false,
  SHOULD_TAKE_SCREENSHOTS: false,

  // AutoAttic;
  ATTIC_LAST_REFRESH_MS: 0,
  RUN_AUTOATTIC_FROM_MS: 1712473200000,
	RUN_AUTOATTIC_TO_MS: 1712559599000,
  ATTIC_SHOULD_GO_FOR_SECOND_MOST_VALUABLE: false,
  ATTIC_USE_ITEM_DB: false,
  ATTIC_RESTOCK_LIST: defaultDesiredItems,
  ATTIC_NEXT_START_WINDOW: -1,
  ATTIC_NEXT_END_WINDOW: -1,

  // AutoSDB;
  AUTOSDB_ENABLED: false,
  MIN_SUBMIT_QUICKSTOCK: 5000,
  MAX_SUBMIT_QUICKSTOCK: 10000,
  GALLERY_LIST: [],

  // AutoPricer;
  IS_TURBO: false,
  SHOULD_USE_NEON: false,
  PRICING_TYPE: "Percentage",
  SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING: false,
  PERCENTAGE_PRICING_ALGORITHM_TYPE: "Zeroes",
  FIXED_PRICING_PERCENTAGE: 15,
  MIN_PRICING_PERCENTAGE: 10,
  MAX_PRICING_PERCENTAGE: 20,
  FIXED_PRICING_ALGORITHM_TYPE: "True Absolute",
  FIXED_PRICING_VALUE: 1000,
  MIN_FIXED_PRICING: 200,
  MAX_FIXED_PRICING: 800,
  SHOULD_CHECK_IF_FROZEN_SHOP: false,

  // AutoKQ
  MAX_INSTA_BUY_PRICE: 0,
  MAX_SPENDABLE_PRICE: 60000,
  USE_BLACKLIST_KQ: false,
  BLACKLIST_KQ: ["Yellow Negg", "Purple Negg", "Green Negg", "Partitioned Negg", "Super Icy Negg"],
  SHOULD_DELETE_SHOP_LAYOUTS: false,

  // AutoBD;
  AUTOBD_ENABLED: false,

  // AutoDaily;
  AUTODAILY_ENABLED: false,
  AUTODAILY_LIST: [],
  MIN_WAIT_ACCEPT_QUEST: 2000,
  MAX_WAIT_ACCEPT_QUEST: 5000,

  // Shop Wizard;
  MIN_WAIT_BAN_TIME: 300000,
  MAX_WAIT_BAN_TIME: 900000,
  MIN_WAIT_PER_REFRESH: 10000,
  MAX_WAIT_PER_REFRESH: 20000,
  RESUBMIT_TYPE: "Absolute",
  MIN_RESUBMITS_PER_ITEM: 2,
  MAX_RESUBMITS_PER_ITEM: 5,
  RESUBMITS_PER_ITEM: 5,
  MIN_RESUBMIT_WAIT_TIME: 10000,
  MAX_RESUBMIT_WAIT_TIME: 40000,
  MIN_NEW_SEARCH_WAIT_TIME: 10000,
  MAX_NEW_SEARCH_WAIT_TIME: 30000,
  USE_BLACKLIST_SW: false,
  BLACKLIST_SW: [
    'Secret Laboratory Map',
    'Piece of a treasure map',
    'Petpet Laboratory Map',
    'Forgotten Shore Map Piece',
    'Underwater Map Piece',
    'Spooky Treasure Map',
    'Mau Codestone',
    'Tai-Kai Codestone',
    'Lu Codestone',
    'Vo Codestone',
    'Eo Codestone',
    'Main Codestone',
    'Zei Codestone',
    'Orn Codestone',
    'Har Codestone',
    'Bri Codestone',
    'Mag Codestone',
    'Vux Codestone',
    'Cui Codestone',
    'Kew Codestone',
    'Sho Codestone',
    'Zed Codestone',
    'One Dubloon Coin',
    'Two Dubloon Coin',
    'Five Dubloon Coin',
    'Ten Dubloon Coin',
    'Twenty Dubloon Coin',
    'Fifty Dubloon Coin',
    'One Hundred Dubloon Coin',
    'Two Hundred Dubloon Coin',
    'Five Hundred Dubloon Coin',
    'Baby Paint Brush'
  ],

  // Shop Stock Page Settings;
  SHOULD_SUBMIT_AUTOMATICALLY: false,
  SHOULD_IMPORT_SALES: false,
  MIN_SHOP_NAVIGATION_COOLDOWN: 20000,
  MAX_SHOP_NAVIGATION_COOLDOWN: 40000,
  MIN_WAIT_AFTER_PRICING_ITEM: 10000,
  MAX_WAIT_AFTER_PRICING_ITEM: 20000,
  MIN_SHOP_SEARCH_FOR_INPUT_BOX: 5000,
  MAX_SHOP_SEARCH_FOR_INPUT_BOX: 10000,
  MIN_SHOP_CLICK_UPDATE: 10000,
  MAX_SHOP_CLICK_UPDATE: 20000,
  MIN_TYPING_SPEED: 200,
  MAX_TYPING_SPEED: 500,
  SHOULD_ENTER_PIN: true,
  NEOPETS_SECURITY_PIN: "0000",
  MIN_WAIT_BEFORE_UPDATE: 10000,
  MAX_WAIT_BEFORE_UPDATE: 20000,
  MIN_PAGE_LOAD_FAILURES: 10000,
  MAX_PAGE_LOAD_FAILURES: 20000,
  AUTOPRICER_STATUS: "Inactive",
  SHOP_INVENTORY: [],

  // Save and load;
  SHOULD_SHARE_STORES_TO_VISIT: false,
  SHOULD_SHARE_RESTOCK_LIST: false,
  SHOULD_SHARE_SHOP_STOCK: false,
  SHOULD_SHARE_SALES_HISTORY: false,
  SHOULD_SHARE_BLACKLISTS: false,
  SHOULD_SHARE_PIN: false,
  SHOULD_SHARE_ATTIC_LAST_REFRESH: false,
  SHOULD_SHARE_HISTORY: false,
  SHOULD_SHARE_AUTOKQ_LOG: false,
  SHOULD_SHARE_NEOBUYER_MAILS: false,

  // The Void Within
  MIN_TVW_VISIT: 120000,
	MAX_TVW_VISIT: 300000,
  IS_RUNNING_TVW_PROCESS: false,
  TVW_AUTOBD_ENABLED: false,
}, (function (_) {

  $("#PAUSE_AFTER_BUY_MS").val(_.PAUSE_AFTER_BUY_MS);
  $("#SEND_TO_SDB_AFTER_PURCHASE").prop("checked", _.SEND_TO_SDB_AFTER_PURCHASE);
  $("#SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES").prop("checked", _.SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES);
  $("#SHOULD_SHOW_CHROME_NOTIFICATIONS").prop("checked", _.SHOULD_SHOW_CHROME_NOTIFICATIONS);
  $("#USE_BLACKLIST").prop("checked", _.USE_BLACKLIST);
  $("#BLACKLIST").val(_.BLACKLIST.join("\n"));
  $("#ITEM_DB_MIN_RARITY").val(_.ITEM_DB_MIN_RARITY);
  $("#BUY_UNKNOWN_ITEMS_PROFIT").val(_.BUY_UNKNOWN_ITEMS_PROFIT);
  $("#ATTIC_ENABLED").prop("checked", _.ATTIC_ENABLED);
  $("#ATTIC_SHOULD_REFRESH").prop("checked", _.ATTIC_SHOULD_REFRESH);
  $("#ATTIC_HIGHLIGHT").prop("checked", _.ATTIC_HIGHLIGHT);
  $("#ATTIC_CLICK_ITEM").prop("checked", _.ATTIC_CLICK_ITEM);
  $("#ATTIC_ITEM_DB_MIN_PROFIT_NPS").val(_.ATTIC_ITEM_DB_MIN_PROFIT_NPS);
  $("#ATTIC_ITEM_DB_MIN_PROFIT_PERCENT").val(_.ATTIC_ITEM_DB_MIN_PROFIT_PERCENT);
  $("#ATTIC_MIN_BUY_TIME").val(_.ATTIC_MIN_BUY_TIME);
  $("#ATTIC_MAX_BUY_TIME").val(_.ATTIC_MAX_BUY_TIME);
  $("#ATTIC_MIN_REFRESH").val(_.ATTIC_MIN_REFRESH);
  $("#ATTIC_MAX_REFRESH").val(_.ATTIC_MAX_REFRESH)
  
  $("#ITEM_DB_MIN_PROFIT_NPS").val(_.ITEM_DB_MIN_PROFIT_NPS);
  $("#ITEM_DB_MIN_PROFIT_PERCENT").val(_.ITEM_DB_MIN_PROFIT_PERCENT);
  $("#USE_ITEM_DB").prop("checked", _.USE_ITEM_DB);
  $("#MIN_REFRESH").val(_.MIN_REFRESH);
  $("#MAX_REFRESH").val(_.MAX_REFRESH);
  $("#MIN_REFRESH_STOCKED").val(_.MIN_REFRESH_STOCKED);
  $("#MAX_REFRESH_STOCKED").val(_.MAX_REFRESH_STOCKED);
  $("#STORES_TO_CYCLE_THROUGH_WHEN_STOCKED").val("[" + _.STORES_TO_CYCLE_THROUGH_WHEN_STOCKED + "]");
  $("#PAUSE_BETWEEN_MINUTES").val("[" + _.PAUSE_BETWEEN_MINUTES + "]");
  $("#ITEMS_TO_CONSIDER_STOCKED").val(_.ITEMS_TO_CONSIDER_STOCKED);
  $("#MIN_CLICK_ITEM_IMAGE").val(_.MIN_CLICK_ITEM_IMAGE);
  $("#MAX_CLICK_ITEM_IMAGE").val(_.MAX_CLICK_ITEM_IMAGE);
  $("#MIN_CLICK_CONFIRM").val(_.MIN_CLICK_CONFIRM);
  $("#MAX_CLICK_CONFIRM").val(_.MAX_CLICK_CONFIRM);
  $("#MIN_OCR_PAGE").val(_.MIN_OCR_PAGE);
  $("#MAX_OCR_PAGE").val(_.MAX_OCR_PAGE);
  $("#ENABLED").prop("checked", _.ENABLED);
  $("#HIGHLIGHT").prop("checked", _.HIGHLIGHT);
  $("#CLICK_ITEM").prop("checked", _.CLICK_ITEM);
  $("#CLICK_CONFIRM").prop("checked", _.CLICK_CONFIRM);
  $("#SHOULD_SHOW_BANNER").prop("checked", _.SHOULD_SHOW_BANNER);
  $("#SHOULD_CLICK_NEOPET").prop("checked", _.SHOULD_CLICK_NEOPET);
  $("#SHOULD_ANNOTATE_IMAGE").prop("checked", _.SHOULD_ANNOTATE_IMAGE);
  $("#SHOULD_SOUND_ALERTS").prop("checked", _.SHOULD_SOUND_ALERTS);
  $("#SHOULD_ENTER_OFFER").prop("checked", _.SHOULD_ENTER_OFFER);
  $("#SHOULD_GO_FOR_SECOND_MOST_VALUABLE").prop("checked", _.SHOULD_GO_FOR_SECOND_MOST_VALUABLE);
  $("#RESTOCK_LIST").val(_.RESTOCK_LIST.join("\n"));

  $("#MIN_FIVE_SECOND_RULE_REFRESH").val(_.MIN_FIVE_SECOND_RULE_REFRESH);
  $("#MAX_FIVE_SECOND_RULE_REFRESH").val(_.MAX_FIVE_SECOND_RULE_REFRESH);
  $("#SHOULD_BYPASS_CONFIRM").prop("checked", _.SHOULD_BYPASS_CONFIRM);
  $("#SHOULD_OPEN_NEW_TABS_FOR_HAGGLING").prop("checked", _.SHOULD_OPEN_NEW_TABS_FOR_HAGGLING);
  $("#SHOULD_ONLY_REFRESH_ON_CLEAR").prop("checked", _.SHOULD_ONLY_REFRESH_ON_CLEAR);
  $("#SHOULD_MULTICLICK_CAPTCHA").prop("checked", _.SHOULD_MULTICLICK_CAPTCHA);
  $("#SHOULD_USE_SIMPLER_HAGGLES").prop("checked", _.SHOULD_USE_SIMPLER_HAGGLES);
  $("#SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS").prop("checked", _.SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS);
  $("#MIN_HAGGLE_POWER").val(_.MIN_HAGGLE_POWER);
  $("#MAX_HAGGLE_POWER").val(_.MAX_HAGGLE_POWER);
  $("#SHOULD_CHANGE_DOCUMENT_DATA").prop("checked", _.SHOULD_CHANGE_DOCUMENT_DATA);
  $("#MIN_PAGE_LOAD_FAILURES").val(_.MIN_PAGE_LOAD_FAILURES);
  $("#MAX_PAGE_LOAD_FAILURES").val(_.MAX_PAGE_LOAD_FAILURES);

  // AutoBuyer Settings;
  $("#SHOULD_TAKE_SCREENSHOTS").prop("checked", _.SHOULD_TAKE_SCREENSHOTS);

  // AutoAttic Settings;
  $("#ATTIC_SHOULD_GO_FOR_SECOND_MOST_VALUABLE").prop("checked", _.ATTIC_SHOULD_GO_FOR_SECOND_MOST_VALUABLE);
  $("#ATTIC_USE_ITEM_DB").prop("checked", _.ATTIC_USE_ITEM_DB);
  $("#ATTIC_RESTOCK_LIST").val(_.ATTIC_RESTOCK_LIST.join("\n"));

  // AutoSDB;
  $("#AUTOSDB_ENABLED").prop("checked", _.AUTOSDB_ENABLED);
  $("#MIN_SUBMIT_QUICKSTOCK").val(_.MIN_SUBMIT_QUICKSTOCK);
  $("#MAX_SUBMIT_QUICKSTOCK").val(_.MAX_SUBMIT_QUICKSTOCK);
  $("#GALLERY_LIST").val(_.GALLERY_LIST.join("\n"));

  // AutoPricer;
  $("#IS_TURBO").prop("checked", _.IS_TURBO);
  $("#SHOULD_USE_NEON").prop("checked", _.SHOULD_USE_NEON);
  $("#PRICING_TYPE").val(_.PRICING_TYPE);
  $("#SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING").prop("checked", _.SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING);
  $("#PERCENTAGE_PRICING_ALGORITHM_TYPE").val(_.PERCENTAGE_PRICING_ALGORITHM_TYPE);
  $("#FIXED_PRICING_PERCENTAGE").val(_.FIXED_PRICING_PERCENTAGE);
  $("#MIN_PRICING_PERCENTAGE").val(_.MIN_PRICING_PERCENTAGE);
  $("#MAX_PRICING_PERCENTAGE").val(_.MAX_PRICING_PERCENTAGE);
  $("#FIXED_PRICING_ALGORITHM_TYPE").val(_.FIXED_PRICING_ALGORITHM_TYPE);
  $("#FIXED_PRICING_VALUE").val(_.FIXED_PRICING_VALUE);
  $("#SHOULD_CHECK_IF_FROZEN_SHOP").prop("checked", _.SHOULD_CHECK_IF_FROZEN_SHOP);
  $("#MIN_FIXED_PRICING").val(_.MIN_FIXED_PRICING);
  $("#MAX_FIXED_PRICING").val(_.MAX_FIXED_PRICING);

  // SW Settings;
  $("#MIN_WAIT_BAN_TIME").val(_.MIN_WAIT_BAN_TIME);
  $("#MAX_WAIT_BAN_TIME").val(_.MAX_WAIT_BAN_TIME);
  $("#MIN_WAIT_PER_REFRESH").val(_.MIN_WAIT_PER_REFRESH);
  $("#MAX_WAIT_PER_REFRESH").val(_.MAX_WAIT_PER_REFRESH);
  $("#RESUBMIT_TYPE").val(_.RESUBMIT_TYPE);
  $("#MIN_RESUBMITS_PER_ITEM").val(_.MIN_RESUBMITS_PER_ITEM);
  $("#MAX_RESUBMITS_PER_ITEM").val(_.MAX_RESUBMITS_PER_ITEM);
  $("#RESUBMITS_PER_ITEM").val(_.RESUBMITS_PER_ITEM);
  $("#MIN_RESUBMIT_WAIT_TIME").val(_.MIN_RESUBMIT_WAIT_TIME);
  $("#MAX_RESUBMIT_WAIT_TIME").val(_.MAX_RESUBMIT_WAIT_TIME);
  $("#MIN_NEW_SEARCH_WAIT_TIME").val(_.MIN_NEW_SEARCH_WAIT_TIME);
  $("#MAX_NEW_SEARCH_WAIT_TIME").val(_.MAX_NEW_SEARCH_WAIT_TIME);
  $("#USE_BLACKLIST_SW").prop("checked", _.USE_BLACKLIST_SW);
  $("#BLACKLIST_SW").val(_.BLACKLIST_SW.join("\n"));

  // KQ Settings;
  $("#MAX_INSTA_BUY_PRICE").val(_.MAX_INSTA_BUY_PRICE);
  $("#MAX_SPENDABLE_PRICE").val(_.MAX_SPENDABLE_PRICE);
  $("#USE_BLACKLIST_KQ").prop("checked", _.USE_BLACKLIST_KQ);
  $("#BLACKLIST_KQ").val(_.BLACKLIST_KQ.join("\n"));
  $("#SHOULD_DELETE_SHOP_LAYOUTS").prop("checked", _.SHOULD_DELETE_SHOP_LAYOUTS);

  // AutoBD Settings;
  $("#AUTOBD_ENABLED").prop("checked", _.AUTOBD_ENABLED);

  // AutoDaily Settings;
  $("#AUTODAILY_ENABLED").prop("checked", _.AUTODAILY_ENABLED);
  $("#AUTODAILY_LIST").val(_.AUTODAILY_LIST.join("\n"));
  $("#MIN_WAIT_ACCEPT_QUEST").val(_.MIN_WAIT_ACCEPT_QUEST);
  $("#MAX_WAIT_ACCEPT_QUEST").val(_.MAX_WAIT_ACCEPT_QUEST);

  // Shop Stock Page Settings;
  $("#SHOULD_SUBMIT_AUTOMATICALLY").prop("checked", _.SHOULD_SUBMIT_AUTOMATICALLY);
  $("#SHOULD_IMPORT_SALES").prop("checked", _.SHOULD_IMPORT_SALES);
  $("#MIN_SHOP_NAVIGATION_COOLDOWN").val(_.MIN_SHOP_NAVIGATION_COOLDOWN);
  $("#MAX_SHOP_NAVIGATION_COOLDOWN").val(_.MAX_SHOP_NAVIGATION_COOLDOWN);
  $("#MIN_WAIT_AFTER_PRICING_ITEM").val(_.MIN_WAIT_AFTER_PRICING_ITEM);
  $("#MAX_WAIT_AFTER_PRICING_ITEM").val(_.MAX_WAIT_AFTER_PRICING_ITEM);
  $("#MIN_SHOP_SEARCH_FOR_INPUT_BOX").val(_.MIN_SHOP_SEARCH_FOR_INPUT_BOX);
  $("#MAX_SHOP_SEARCH_FOR_INPUT_BOX").val(_.MAX_SHOP_SEARCH_FOR_INPUT_BOX);
  $("#MIN_SHOP_CLICK_UPDATE").val(_.MIN_SHOP_CLICK_UPDATE);
  $("#MAX_SHOP_CLICK_UPDATE").val(_.MAX_SHOP_CLICK_UPDATE);

  // Security Settings;
  $("#MIN_TYPING_SPEED").val(_.MIN_TYPING_SPEED);
  $("#MAX_TYPING_SPEED").val(_.MAX_TYPING_SPEED);
  $("#SHOULD_ENTER_PIN").prop("checked", _.SHOULD_ENTER_PIN);
  $("#NEOPETS_SECURITY_PIN").val(_.NEOPETS_SECURITY_PIN);
  $("#MIN_WAIT_BEFORE_UPDATE").val(_.MIN_WAIT_BEFORE_UPDATE);
  $("#MAX_WAIT_BEFORE_UPDATE").val(_.MAX_WAIT_BEFORE_UPDATE);

  //Load and save;
  $("#SHOULD_SHARE_STORES_TO_VISIT").prop("checked", _.SHOULD_SHARE_STORES_TO_VISIT);
  $("#SHOULD_SHARE_RESTOCK_LIST").prop("checked", _.SHOULD_SHARE_RESTOCK_LIST);
  $("#SHOULD_SHARE_SHOP_STOCK").prop("checked", _.SHOULD_SHARE_SHOP_STOCK);
  $("#SHOULD_SHARE_SALES_HISTORY").prop("checked", _.SHOULD_SHARE_SALES_HISTORY);
  $("#SHOULD_SHARE_BLACKLISTS").prop("checked", _.SHOULD_SHARE_BLACKLISTS);
  $("#SHOULD_SHARE_PIN").prop("checked", _.SHOULD_SHARE_PIN);
  $("#SHOULD_SHARE_ATTIC_LAST_REFRESH").prop("checked", _.SHOULD_SHARE_ATTIC_LAST_REFRESH);
  $("#SHOULD_SHARE_HISTORY").prop("checked", _.SHOULD_SHARE_HISTORY);
  $("#SHOULD_SHARE_AUTOKQ_LOG").prop("checked", _.SHOULD_SHARE_AUTOKQ_LOG),
  $("#SHOULD_SHARE_NEOBUYER_MAILS").prop("checked", _.SHOULD_SHARE_NEOBUYER_MAILS);

  ShowOrHide();

  // The Void Within
  $("#MIN_TVW_VISIT").val(_.MIN_TVW_VISIT);
  $("#MAX_TVW_VISIT").val(_.MAX_TVW_VISIT);
  $("#IS_RUNNING_TVW_PROCESS").prop("checked", _.IS_RUNNING_TVW_PROCESS);
  $("#TVW_AUTOBD_ENABLED").prop("checked", _.TVW_AUTOBD_ENABLED);
}));