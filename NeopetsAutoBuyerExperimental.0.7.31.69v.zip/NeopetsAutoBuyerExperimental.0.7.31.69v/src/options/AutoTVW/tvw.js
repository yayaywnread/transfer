setDEFAULT("OWNED_PETS", []);
setDEFAULT("VOLUNTEER_SHIFTS", []);
setDEFAULT("IS_RUNNING_TVW_PROCESS", false);
setDEFAULT("IS_LOADING_SHIFTS", false);

const loadPetDataButton = document.getElementById("load-pet-data");

LoadPetsListener(loadPetDataButton);

function LoadPetsListener(button){
    button.addEventListener("click", StartLoadOwnedPetsProcess);
}

const loadShiftDataButton = document.getElementById("load-shift-data");

function LoadShiftsListener(button){
    button.addEventListener("click", StartLoadVolunteeringShiftsProcess);
}

// ExpandTable.js

var AddListenerLogicOverride = AddListenerLogic;

AddListenerLogic = async function(key, shift){
    const clone = dataPointClone.cloneNode(true);

    HandleVisualControllers(clone, true, true);

    if(shift != undefined){
        const timeInput = clone.querySelector(".tvw-time");
            
        timeInput.value = FormatTime(new Date(shift["time"]));
    }

    const petSelectElement = clone.querySelector(".pets-dropdown"),
          shiftSelectElement = clone.querySelector(".shifts-dropdown");

    return new Promise(async (resolve, reject) => {
        const volunteerShifts = await getVARIABLE("VOLUNTEER_SHIFTS");

        var pet = "";

        try { pet = shift["pet"] } catch { pet = ""; }

        LoadData(volunteerShifts, shiftSelectElement, loadShiftDataButton, LoadShiftsListener, key, true)

        const ownedPets = await getVARIABLE("OWNED_PETS");

        LoadData(ownedPets, petSelectElement, loadPetDataButton, LoadPetsListener, pet);

        function LoadData(data, element, button, callback, defaultSelection = "", isNamingRow = false){
            if (data.length > 0) {
                element.addEventListener("change", function(){
                    ProcessDataPoints();
                })

                LoadDataInSelect(element, data, defaultSelection);

                if(isNamingRow){
                    const shiftName = clone.querySelector(".controller-name");

                    if(pet == undefined || pet.length == 0){
                        shiftName.textContent = `${element.value}`;
                    } else shiftName.textContent = `${element.value} - ${pet}`;
                }
            } else {
                const selectParent = element.parentNode;
                element.remove();

                const clone = button.cloneNode(true);
                clone.removeAttribute("href");
                clone.removeAttribute("target");
                
                if (typeof callback === 'function') {
                    callback(clone);
                }
    
                selectParent.appendChild(clone);
            }
        }

        resolve(clone);
    });
};

// FormatTime(); Formatting the time for the input fields;
function FormatTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');
    const hours = String(date.getHours()).padStart(2, '0');
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
}

ProcessDataPoints = function(){
    const data = {};
    const dataPoints = document.querySelectorAll(".data-point");

    dataPoints.forEach(function(dataPoint){
        const time = dataPoint.querySelector(".tvw-time").value,
              name = dataPoint.querySelector(".shifts-dropdown").value,
              pet = dataPoint.querySelector(".pets-dropdown").value;

        const shiftName = dataPoint.querySelector(".controller-name");
        shiftName.textContent = `${name} - ${pet}`;

        var shift = {
            name: name,
            time: time,
            pet: pet
        }

        data[shift.name] = {
            time: time,
            pet: pet
        }
    });

    setVARIABLE("VOLUNTEER_OBJECTS", data);
}

//////////////////////////////////////////////////////////////////////////////

LoadShiftTimes();

async function LoadShiftTimes(){
    setDEFAULT("VOLUNTEER_OBJECTS", {});

    const volunteerData = await getVARIABLE("VOLUNTEER_OBJECTS");

    Object.keys(volunteerData).forEach(async function(key){
        const shift = volunteerData[key];

        const clone = await AddListenerLogic(key, shift);

        dataContainer.appendChild(clone);
    });
}

CheckIfUserLoadedPets();

BattledomeData();

LoadTVWBattles();

async function LoadTVWBattles(){
    const tvwBattles = await getVARIABLE("TVW_BATTLES"),
            battleSelected = await getVARIABLE("TVW_BATTLE_SELECTED"),
            battleSelector = document.getElementById("TVW_BATTLE");
    
    if(tvwBattles.length == 0) return;

    LoadDataInSelect(battleSelector, tvwBattles, battleSelected);

    if(battleSelected == "") setVARIABLE("TVW_BATTLE_SELECTED", battleSelector.value);

    battleSelector.addEventListener("change", function(){
        setVARIABLE("TVW_BATTLE_SELECTED", battleSelector.value);
    });
}

//////////////////////////////////////////////////////////////////////////////


// Bot status messages;
StatusManagement();

var timerContainer = document.querySelector('.timeContainer');

// StatusManagement(); Change the "Status" text in the GUI;
async function StatusManagement(){
    var tvwStatus = await getVARIABLE("TVW_STATUS");

    // Setting a base status;
    if(tvwStatus == undefined){
        tvwStatus = "Inactive";
        setVARIABLE("TVW_STATUS", "Inactive");
    }

    const statusTag = document.getElementById("status-tag");

    ShowOrHideLoading(tvwStatus);
    statusTag.textContent = tvwStatus;
    setDEFAULT("IS_RUNNING_TVW_PROCESS", false);

    // Updates constantly the GUI information;
    async function UpdateGUIData() {
        ShowOrHideLoading(tvwStatus);
        statusTag.textContent = tvwStatus;
        tvwStatus = await getVARIABLE("TVW_STATUS");
    }

    // Update page data;
    setInterval(function() {
        UpdateGUIData();
    }, 100);
}