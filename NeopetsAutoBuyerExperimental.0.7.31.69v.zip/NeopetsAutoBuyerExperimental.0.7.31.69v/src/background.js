importScripts("../../Lib/ExtPay.js");
importScripts("../../Lib/moment.js");
importScripts("../../Lib/moment-timezone-with-data.js");

chrome.runtime.onInstalled.addListener(function(e) {
	"install" == e.reason || e.reason

	if(e.reason == "install") {
		const autoPricerDefaultSettings = {
			// Toolbar;
			UPDATE_STATUS_A: false,
			UPDATE_DATE: "",
			UPDATE_VERSION: "",
			IS_UP_TO_DATE: false,
			LATEST_DOWNLOAD_LINK: "",
			LATEST_EXPERIMENTAL_DOWNLOAD_LINK: "",
			QUICKLINKS: ["AutoBuyer+", "AutoAttic+", "AutoPricer", "AutoKQ"],

			// AutoBuyer;
			SHOPS_SETTINGS: {
				"0": {
					"refreshWhenCleared": false,
					"goForSecond": false,
					"minRefresh": 37500,
					"maxRefresh": 45000,
					"minUnstockedRefresh": 3500,
					"maxUnstockedRefresh": 5000,
					"minItemsToConsiderStocked": 1,
				}
			},
			RUN_AUTOBUYER_FROM_MS: 1712473200000,
			RUN_AUTOBUYER_TO_MS: 1712559599000,
			IS_DEFAULT_SHOP_TIME: true,
			SHOULD_BYPASS_CONFIRM: false,
			SHOULD_OPEN_NEW_TABS_FOR_HAGGLING: false,
			SHOULD_ONLY_REFRESH_ON_CLEAR: false,
			SHOULD_USE_CUSTOM_HAGGLE_MULTIPLIERS: false,
			MIN_HAGGLE_POWER: 0.75,
			MAX_HAGGLE_POWER: 0.85,
			SHOULD_MULTICLICK_CAPTCHA: false,
			SHOULD_CHANGE_DOCUMENT_DATA: false,
			PAUSE_AFTER_BUY_MS: 18000,
			HAS_UPDATE_ALERT_TRIGGERED: false,
			SHOULD_TAKE_SCREENSHOTS: false,

			// Database;
			DATABASE_LAST_UPDATE: new Date().getTime(),
			DATABASE: [],
			DATABASE_ARRAY: [],

			//AutoAttic;
			ATTIC_HAS_REFRESHED: false,
			ATTIC_SHOULD_REFRESH: false,
			RUN_AUTOATTIC_FROM_MS: 1712473200000,
			RUN_AUTOATTIC_TO_MS: 1712559599000,
			IS_DEFAULT_ATTIC_TIME: true,
			ATTIC_RESTOCK_LIST: [],
			ATTIC_NEXT_START_WINDOW: 0,
        	ATTIC_NEXT_END_WINDOW: 0,

			// AutoSDB;
			AUTOSDB_ENABLED: false,
			MIN_SUBMIT_QUICKSTOCK: 5000,
			MAX_SUBMIT_QUICKSTOCK: 10000,
			SDB_LIST: [],
			SDB_HISTORY: [],
			/*IS_QUICKSTOCK_WINDOW_OPEN: false,*/
			GALLERY_LIST: [],

			// AutoPricer;
			SHOULD_USE_NEON: false,
			PRICING_TYPE: "Percentage",
			SHOULD_USE_RANDOM_PERCENTAGES_FOR_PRICING: false,
			PERCENTAGE_PRICING_ALGORITHM_TYPE: "Zeroes",
			FIXED_PRICING_PERCENTAGE: 15,
			MIN_PRICING_PERCENTAGE: 10,
			MAX_PRICING_PERCENTAGE: 20,
			FIXED_PRICING_ALGORITHM_TYPE: "Fixed",
			FIXED_PRICING_VALUE: 1000,
			MIN_FIXED_PRICING: 200,
			MAX_FIXED_PRICING: 800,
			IS_RETRYING_SEARCH: false,
			SHOULD_CHECK_IF_FROZEN_SHOP: false,
			SHOP_HISTORY: [],
			SHOULD_IMPORT_SALES: false,

			// AutoKQ;
			START_AUTOKQ_PROCESS: false,
			AUTOKQ_STATUS: "Inactive",
			KQ_INVENTORY: [],
			SUBMIT_AUTOKQ_PROCESS: false,
			MAX_INSTA_BUY_PRICE: 0, 
			MAX_SPENDABLE_PRICE: 60000,
    		USE_BLACKLIST_KQ: false,
    		BLACKLIST_KQ: ["Yellow Negg", "Purple Negg", "Green Negg", "Partitioned Negg", "Super Icy Negg"],
			SHOULD_DELETE_SHOP_LAYOUTS: false,
			KQ_TRACKER: [],

			// AutoBD;
			AUTOBD_ENABLED: false,
			BD_PET: "",
			IS_LOADING_BD_WEAPONS: false,
			BD_WEAPONS: {},
			BD_TURNS: {
				"1": {
					"Attack 1": "Nothing",
					"Attack 2": "Nothing",
					"Ability": "Nothing",
				}
			},

			// AutoDaily;
			AUTODAILY_ENABLED: false,
			ITEMS_TO_PURCHASE_TODAY: 0,
			ITEMS_PURCHASED_TODAY: 0,
			HAS_PURCHASE_QUEST: false,
			HAS_GROOMING_QUEST: false,
			GROOMING_ITEM_NAME: "",
			SPINNING_WHEEL_TYPE: "nowheel",
			HAS_CUSTOMIZE_QUEST: false,
			HAS_REMOVED_CLOTHES: false,
			REMOVED_PIECE: "",
			HAS_GAME_QUEST: false,
			HAS_FOOD_QUEST: false,
			FOOD_ITEM: "",
			AUTODAILY_TRACKER: [],
			AUTODAILY_LIST: [],
			DESTINATION_PET: "",
			MIN_WAIT_ACCEPT_QUEST: 2000,
			MAX_WAIT_ACCEPT_QUEST: 5000,
			LAST_DATE_CHECKED: null,
		
			// Shop Wizard;
			MIN_WAIT_BAN_TIME: 300000,
			MAX_WAIT_BAN_TIME: 900000,
			RESUBMIT_TYPE: "Absolute",
			MIN_RESUBMITS_PER_ITEM: 2,
			MAX_RESUBMITS_PER_ITEM: 5,
			RESUBMITS_PER_ITEM: 5,
			MIN_RESUBMIT_WAIT_TIME: 10000,
			MAX_RESUBMIT_WAIT_TIME: 40000,
			USE_BLACKLIST_SW: false,
			BLACKLIST_SW: [
				'Secret Laboratory Map',
				'Piece of a treasure map',
				'Petpet Laboratory Map',
				'Forgotten Shore Map Piece',
				'Underwater Map Piece',
				'Spooky Treasure Map',
				'Mau Codestone',
				'Tai-Kai Codestone',
				'Lu Codestone',
				'Vo Codestone',
				'Eo Codestone',
				'Main Codestone',
				'Zei Codestone',
				'Orn Codestone',
				'Har Codestone',
				'Bri Codestone',
				'Mag Codestone',
				'Vux Codestone',
				'Cui Codestone',
				'Kew Codestone',
				'Sho Codestone',
				'Zed Codestone',
				'One Dubloon Coin',
				'Two Dubloon Coin',
				'Five Dubloon Coin',
				'Ten Dubloon Coin',
				'Twenty Dubloon Coin',
				'Fifty Dubloon Coin',
				'One Hundred Dubloon Coin',
				'Two Hundred Dubloon Coin',
				'Five Hundred Dubloon Coin',
				'Baby Paint Brush'
			],
			
			// Shop Stock Page Settings;
			SHOULD_SUBMIT_AUTOMATICALLY: false,
			MIN_SHOP_CLICK_UPDATE: 10000,
			MAX_SHOP_CLICK_UPDATE: 20000,
			SHOULD_ENTER_PIN: true,
			NEOPETS_SECURITY_PIN: "0000",

			//Miscellaneous;
			AUTOPRICER_STATUS: "Inactive",
			SHOP_INVENTORY: [],
			MIN_PAGE_LOAD_FAILURES: 10000,
			MAX_PAGE_LOAD_FAILURES: 20000,

			// Save and load;
			SHOULD_SHARE_STORES_TO_VISIT: false,
			SHOULD_SHARE_RESTOCK_LIST: false,
			SHOULD_SHARE_SHOP_STOCK: false,
			SHOULD_SHARE_SALES_HISTORY: false,
			SHOULD_SHARE_BLACKLISTS: false,
			SHOULD_SHARE_PIN: false,
			SHOULD_SHARE_ATTIC_LAST_REFRESH: false,
			SHOULD_SHARE_HISTORY: false,
			SHOULD_SHARE_AUTOKQ_LOG: false,
			SHOULD_SHARE_NEOBUYER_MAILS: false,

			// AutoBuyer+ Mail;
			EMAIL_LIST: [],
			SKIP_CURRENT_MAIL: false,
			CURRENT_MAIL_INDEX: -1,
			RETRIEVED_NEWEST_EMAIL: false,

			// The Void Within;
			TAB_ID: null,
			OWNED_PETS: [],
			VOLUNTEER_SHIFTS: [],
			VOLUNTEER_OBJECTS: {},
			TVW_STATUS: "Inactive",
			IS_LOADING_PETS: false,
			IS_LOADING_SHIFTS: false,
			IS_RUNNING_TVW_PROCESS: false,
			MIN_TVW_VISIT: 120000,
			MAX_TVW_VISIT: 300000,
			TVW_BATTLES: [],
			TVW_BATTLE_SELECTED: "",
			LAST_DATE_BATTLED: "",
		};

		chrome.storage.local.set(autoPricerDefaultSettings, function (){});
	}
})

chrome.runtime.onStartup.addListener(() => {
    CheckVersionWhenBackgroundActive();
});

function setVARIABLE(propertyName, value) {
	var storageObject = {};
	storageObject[propertyName] = value;
	chrome.storage.local.set(storageObject, function () {});
}

function getVARIABLE(variable) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get([variable], function (result) {
            var value = result[variable];

            resolve(value);
        });
    });
}

async function CheckVersionWhenBackgroundActive(){
    chrome.storage.local.set({ "UPDATE_DATE": "" });
	chrome.storage.local.set({ "UPDATE_VERSION": "" });

    // If the version checker has not been run, check the latest version of the extension;
    var currentVersion = chrome.runtime.getManifest().version;
    var apiUrl = "https://api.github.com/repos/Unovamata/AutoBuyerPlus/releases/latest";
    var githubLatestVersion = await FetchLatestGitHubVersion(apiUrl);
    var parsedVersion = githubLatestVersion.replace("v", "");
	setVARIABLE("UPDATE_VERSION", parsedVersion);
    var isLatestVersion = parsedVersion == currentVersion;

    switch(parsedVersion){
        // Github's API can't be reached or user is using a VPN;
        case 'a':
			var fetchedVersion = await FetchLatestGithubTag();

			isLatestVersion = fetchedVersion == currentVersion;

			// The version could not be parsed at all;
			if(fetchedVersion != "a") setVARIABLE("UPDATE_VERSION", fetchedVersion);
			setVARIABLE("UPDATE_STATUS_A", isLatestVersion);  

			if(isLatestVersion) FetchDatabaseData();
        break;

        // Unknown error;
        case 'b':
            setVARIABLE("UPDATE_STATUS_A", false);
        break;

        // Normal version checking;
        default:
			setVARIABLE("UPDATE_STATUS_A", isLatestVersion);
			FetchDatabaseData();
        break;
    }

    if(isLatestVersion) ChangeIcon("icons/icon128.png");
    else ChangeIcon("icons/redicon128.png");

    async function FetchLatestGitHubVersion(apiUrl) {
        try {
            // Checking the Github API for the latest extension version;
            const response = await fetch(apiUrl);

            if (!response.ok) {
                return 'a'; // API can't be reached;
            }

            // Parsing the data and returning it;
            const data = await response.json();

            const githubLatestVersion = data.tag_name,
				  githubLatestFiles = data.assets[0].browser_download_url,
				  githubLatestExperimentalFiles = data.assets[1].browser_download_url;

			setVARIABLE("LATEST_DOWNLOAD_LINK", githubLatestFiles);  
			setVARIABLE("LATEST_EXPERIMENTAL_DOWNLOAD_LINK", githubLatestExperimentalFiles);  

            return githubLatestVersion;
        } catch (error) {
			ErrorMessage(error);

            return 'b'; // Error in the execution;
        }
    }

	function ErrorMessage(error){
		var errorMessage = "";

		var propertyNames = Object.getOwnPropertyNames(error);

		propertyNames.forEach(function(property) {
			var descriptor = Object.getOwnPropertyDescriptor(error, property);

			errorMessage += property + ":" + error[property] + ":" + PropsToStr(descriptor);
		});

		setVARIABLE("ERROR_STATUS", errorMessage);  
		setVARIABLE("LATEST_DOWNLOAD_LINK", "");  

		function PropsToStr(obj) {
			var str = '';

			for (prop in obj) {
				str += prop + "=" + obj[prop] + ",";
			}

			return str;
		}
	}

	async function FetchLatestGithubTag() {
		try {
			const response = await fetch('https://github.com/Unovamata/AutoBuyerPlus/tags');
			if (!response.ok) return 'a'; // API can't be reached;
	
			const html = await response.text();
	
			const classString = 'Link--primary Link">',
				startPosition = html.indexOf(classString);
			
			if (startPosition === -1) {
				return 'a'; // API can't be reached;
			}

			var processedVersion = html.substring(startPosition + classString.length);
			processedVersion = processedVersion.split("v")[0];
	
			return processedVersion;
		} catch (error) {
			throw error;
		}
	}

    // Function to change the icon
    function ChangeIcon(iconPath) {
        chrome.action.setIcon({ path: iconPath });
    }

	async function FetchDatabaseData(){
		try {
			const databaseResponse = await fetch("https://raw.githubusercontent.com/Unovamata/AutoBuyerPlus/main/Autobuyer/DB/database.json");
			
			if(!databaseResponse.ok) return;

			setVARIABLE("DATABASE_LAST_UPDATE", new Date().getTime());

			const json = await databaseResponse.json(),
				  keys = Object.keys(json),
				  array = [];

			for(var i = 0; i < keys.length; i++){
				const key = keys[i];

				var price = json[key],
					originalPrice;

				originalPrice = price;

				var item = {Name: key, Price: price};

				switch (originalPrice){
					case "Unpriced":
						array.push(item);
					break;

					case "NO TRADE": continue; break;

					default:
						item.Price = parseInt(json[key].replace(/,/g, "").replace(" NP", ""));
						array.push(item);
					break;
				}
			}

			array.sort((a, b) => b.Price - a.Price);

			setVARIABLE("DATABASE_ARRAY", array);
			setVARIABLE("DATABASE", json);
		} catch {}
	}
}

CheckVersionWhenBackgroundActive();

var extpay = ExtPay("restock-highligher-autobuyer");
extpay.startBackground();
	
// Attic Captcha Warning after 3 seconds;
setTimeout(() => {
	chrome.storage.local.get({WARNING_ACK: false, EXT_P_S: true}, data => {
		if(!data.WARNING_ACK && data.EXT_P_S){
			var storageObject = {};
			storageObject["ATTIC_SHOULD_REFRESH"] = false;
			chrome.storage.local.set(storageObject, function () {});

			chrome.tabs.create({ url: "../../src/options/Warning/warning.html" });
		}
	});
}, 1000)

// Open index page when the extension icon is clicked;
chrome.action.onClicked.addListener(async () => {
	const acknowledgedWarning = await getVARIABLE("WARNING_ACK");

	if(acknowledgedWarning) chrome.tabs.create({ url: "../../src/options/Autobuyer/autobuyer.html" });
	else chrome.tabs.create({ url: "../../src/options/Warning/warning.html" });
});

chrome.webNavigation.onErrorOccurred.addListener((function(e) {
	chrome.storage.local.get({
		SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES: !0
	}, (function(t) {
		t.SHOULD_REFRESH_THROUGH_PAGE_LOAD_FAILURES && ("outermost_frame" !== e.frameType || "net::ERR_HTTP_RESPONSE_CODE_FAILURE" !== e.error || setTimeout((function() {
			chrome.tabs.reload(e.tabId, (function() {}))
		}), 1e4))
	}))
}), {
	url: [{
		urlMatches: "(.*neopets.com/halloween/garage.phtml)|(.*neopets.com/objects.phtml?(.)*type=shop(.)*)|(.*neopets.com/objects.phtml?(.)*obj_type=([0-9]+)(.)*)"
	}]
});

var hasTriggeredAutoDaily = false, hasTriggeredAutoTVWBD = false;

// The Void Within
CheckCurrentVolunteerTime();

// CheckCurrentVolunteerTime(); Checks if the Volunteer Shift windows have passed;
async function CheckCurrentVolunteerTime(){
	var currentTime = Date.now(),
		NSTTime = TimezoneDate(currentTime);

	if(IsMidnight(NSTTime)){
		hasTriggeredAutoDaily = false;
		hasTriggeredAutoTVWBD = false;
	}

	const acknowledgedWarning = await getVARIABLE("WARNING_ACK");

	// AutoDaily;
	AutoDailyTrigger(NSTTime, acknowledgedWarning);

	// AutoTVWBD
	AutoTVWBD(NSTTime, acknowledgedWarning);

	var shifts = await getVARIABLE("VOLUNTEER_OBJECTS"),
		volunteerTime = []
		passedWindows = [];

	if(volunteerTime == undefined){
		setVARIABLE("VOLUNTEER_OBJECTS", {}),
		shifts = {},
		volunteerTime = [];	
	}

	Object.keys(shifts).forEach(function(key){
		volunteerTime.push(shifts[key]["time"]);
	});

	// Checks the volunteer times and adds them for confirmation;
	volunteerTime.forEach(function(window){
		if(currentTime >= window){
			passedWindows.push(window);
		}
	});

	var tabId = await getVARIABLE("TAB_ID"),
		isRunningTVWProcess = await getVARIABLE("IS_RUNNING_TVW_PROCESS"),
		isShiftComplete = isRunningTVWProcess && tabId == null && passedWindows.length > 0 && volunteerTime != [];

	// Creates a tab, saves its data, and removes the old shift data;
	if(isShiftComplete){
		chrome.tabs.create({ url: 'https://www.neopets.com/hospital/volunteer.phtml' }, function(tab) {
			setVARIABLE("TAB_ID", tab.id);
			setVARIABLE("VOLUNTEER_TIME", volunteerTime.filter(time => !passedWindows.includes(time)));
		});
	}
}

// Check the shift times every 10 seconds;
setInterval(CheckCurrentVolunteerTime, 10000);

var quickStockPageCreated = false;

// Close the tab once the process has finished its duties;
chrome.runtime.onMessage.addListener(async function(message, sender, sendResponse) {
	switch (message.action) {
		case 'closeTab':
			try {
				var tabId = await getVARIABLE("TAB_ID");
				
				chrome.tabs.remove(tabId, function() {
					sendResponse({ result: 'success' });
					setVARIABLE("TAB_ID", null);
				});
			} catch (error) {
				sendResponse({ result: 'error', message: error.message });
			}
		break;

		case "OpenQuickstockPage":
			if(quickStockPageCreated) return;

			quickStockPageCreated = true;

			chrome.tabs.create({url: "https://www.neopets.com/quickstock.phtml"
			}, (tab) => {
				setTimeout(() => {
					chrome.tabs.remove(tab.id);
					quickStockPageCreated = false;
				}, 5000);
			});
		break;

		case "outdatedVersion":
			// Open a new window when message with action "openWindow" is received
			chrome.tabs.create({ url: "../src/options/Autobuyer/autobuyer.html" });
		break;
	}

	switch (message.type) {
		case "Notification":
			chrome.storage.local.get({
				SHOULD_SHOW_CHROME_NOTIFICATIONS: true,
				SHOULD_SOUND_ALERTS: true
			}, (settings) => {
				if (settings.SHOULD_SHOW_CHROME_NOTIFICATIONS) {
					chrome.notifications.create(message.notificationObject);
				}
				if (settings.SHOULD_SOUND_ALERTS) {
					chrome.tts.speak(message.notificationObject.title, { rate: 1.15 });
				}
			});
		break;

		case "Beep":
			chrome.storage.local.get({ SHOULD_SOUND_ALERTS: true }, (settings) => {
				if (settings.SHOULD_SOUND_ALERTS) {
					// Sound alert functionality here
				}
			});
		break;
	}
});

function TimezoneDate(time){
    return new Date(moment(time).tz("America/Los_Angeles").format("YYYY-MM-DD HH:mm:ss"));
}

function IsMidnight(date) {
    return date.getHours() === 0 && date.getMinutes() === 0 && date.getSeconds() === 0;
}

async function AutoDailyTrigger(NSTTime, acknowledgedWarning){
	const isAutoDailyEnabled = await getVARIABLE("AUTODAILY_ENABLED"),
		  lastDateChecked = await getVARIABLE("LAST_DATE_CHECKED");

	if(!acknowledgedWarning) return;
	if(!isAutoDailyEnabled) return;
		  
	// If the users has read the ToS and the extension hasn't checked the quests today;
	if(!hasTriggeredAutoDaily){
		// Wait 5 minutes before triggering the AutoDaily process;
		setTimeout(RunAutoDaily, 300000);

		hasTriggeredAutoDaily = true;
	}

	function RunAutoDaily(){
		const todayString = NSTTime.toDateString();
	
		var isToday;

		try { isToday = todayString == lastDateChecked; } 
		catch { isToday = false; }

		// If Checked quests today; Stop;
		if(isToday) return;

		// If not, check them;
		chrome.tabs.create({ url: "https://www.neopets.com/questlog/" });
	}
}

async function AutoTVWBD(NSTTime, acknowledgedWarning){
	const isAutoTVWBDEnabled = await getVARIABLE("TVW_AUTOBD_ENABLED"),
		  lastDateBattled = await getVARIABLE("LAST_DATE_BATTLED");

	if(!acknowledgedWarning) return;
	if(!isAutoTVWBDEnabled) return;

	if(!hasTriggeredAutoTVWBD){
		// Wait 5 minutes before triggering the AutoDaily process;
		setTimeout(RunAutoTVWBD, 300000);

		hasTriggeredAutoTVWBD = true;
	}

	function RunAutoTVWBD(){
		const todayString = NSTTime.toDateString();
	
		var isToday;

		try { isToday = todayString == lastDateBattled; } 
		catch { isToday = false; }

		// If Checked quests today; Stop;
		if(isToday) return;

		// If not, check them;
		chrome.tabs.create({ url: "https://www.neopets.com/dome/barracks.phtml" });
	}
}

const optionsPath = "../../src/options/";

chrome.commands.onCommand.addListener(async (command) => {
	const quicklinks = await getVARIABLE("QUICKLINKS");

	function GetLink(linkName){
		var link;

		switch(linkName){
			case "AutoBuyer+":
				link = optionsPath + "Autobuyer/autobuyer.html";
			break;

			case "AutoAttic+":
				link = optionsPath + "AutoAttic/attic.html";
			break;

			case "AutoSDB":
				link = optionsPath + "AutoSDB/autosdb.html";
			break;

			case "History":
				link = optionsPath + "History/history.html";
			break;

			case "Database":
				link = optionsPath + "Database/database.html";
			break;

			case "AutoPricer":
				link = optionsPath + "Autopricer/autopricer.html";
			break;

			case "AutoKQ":
				link = optionsPath + "AutoKQ/autokq.html";
			break;

			case "AutoDaily":
				link = optionsPath + "AutoDaily/autodaily.html";
			break;

			case "AutoBD":
				link = optionsPath + "AutoBD/autobd.html";
			break;

			case "AutoTVW":
				link = optionsPath + "AutoTVW/tvw.html";
			break;

			case "Restock List":
				link = optionsPath + "Tools/restockListGen.html";
			break;

			case "Config Presets":
				link = optionsPath + "Tools/info.html";
			break;

			case "FAQs":
				link = "https://github.com/Unovamata/AutoBuyerPlus/wiki/FAQs";
			break;

			case "Bug Report":
				link = "https://github.com/Unovamata/AutoBuyerPlus/issues";
			break;

			case "Suggestions":
				link = "https://github.com/Unovamata/AutoBuyerPlus/issues/1";
			break;

			default:
				link = optionsPath + "/Autobuyer/autobuyer.html";
			break;
		}

		return link;
	}

	switch (command) {
		case "command-1":
		  	chrome.tabs.create({ url: GetLink(quicklinks[0]) });
		break;
		case "command-2":
		  	chrome.tabs.create({ url: GetLink(quicklinks[1]) });
		break;
		case "command-3":
		  	chrome.tabs.create({ url: GetLink(quicklinks[2]) });
		break;
		case "command-4":
		  chrome.tabs.create({ url: GetLink(quicklinks[3]) });
		break;
		default:
		  	console.log(`Unknown command: ${command}`);
		break;
	}
});