// Item class for item configuration and parsing;
class Item {
    constructor(Name, Price, IsPricing, Index, ListIndex, Stock) {
        this.Name = Name;
        this.Price = Price;
        this.IsPricing = IsPricing;
        this.Index = Index;
        this.ListIndex = ListIndex;
        this.Stock = Stock;
    }
}

function getVARIABLE(variable) {
    return new Promise((resolve, reject) => {
        chrome.storage.local.get([variable], function (result) {
            var value = result[variable];

            resolve(value);
        });
    });
}

function setVARIABLE(propertyName, value) {
    var storageObject = {};
    storageObject[propertyName] = value;
    chrome.storage.local.set(storageObject, function () {});
}

async function setDEFAULT(propertyName, value){
    const variable = await getVARIABLE(propertyName);

    if(variable == null || variable == undefined) setVARIABLE(propertyName, value);
}


//######################################################################################################################################
//// AutoBuyers' Common Functions;

function CalculateItemProfits(database, items, prices, buyUnknownItemsIfProfitMargin, isBlacklistActive, blacklistToNeverBuy) {
    const itemProfits = [];

    for (const itemID of items) {
        if (IsItemInBlacklist(itemID, isBlacklistActive, blacklistToNeverBuy)) {
            itemProfits.push(-99999999);
        } else {
            const itemPrice = database[itemID];
            
            try{
                if (itemPrice == undefined) {
                    //console.warn("Item not found in the database or price not available.");
                    itemProfits.push(buyUnknownItemsIfProfitMargin);
                } else {
                    const userPrice = parseInt(prices[items.indexOf(itemID)]);
                    const profit = itemPrice - userPrice;
                    itemProfits.push(profit);
                }
            } catch { itemProfits.push(buyUnknownItemsIfProfitMargin); }
        }
    }

    return itemProfits;
}

function IsItemInBlacklist(itemName, isBlacklistActive, blacklistToNeverBuy) {
    return isBlacklistActive && blacklistToNeverBuy.includes(itemName);
}

function BestItemName(itemNames, itemPrices, itemProfits, minDBProfitToBuy, minDBProfitPercent) {
    var bestItemName = null;
    var maxProfit = -1;
    var length = itemProfits.length;

    for (var i = 0; i < length; i++) {
        var profit = itemProfits[i];

        var meetsProfitCriteria = profit >= minDBProfitToBuy;
        var meetsPercentCriteria = (profit / itemPrices[i]) >= minDBProfitPercent;

        if (meetsProfitCriteria && meetsPercentCriteria && profit > maxProfit) {
            maxProfit = profit;
            bestItemName = itemNames[i];
        }
    }

    return bestItemName;
}


function FilterItemsByProfitCriteria(itemNames, itemPrices, itemProfits, minDBProfit, minDBProfitPercent) {
    var filteredItems = [];
    
    for (var i = 0; i < itemProfits.length; i++) {
        var meetsProfitCriteria = itemProfits[i] > minDBProfit;
        var meetsPercentCriteria = (itemProfits[i] / itemPrices[i]) > minDBProfitPercent;

        if (meetsProfitCriteria && meetsPercentCriteria) {
            filteredItems.push(itemNames[i]);
        }
    }

    return filteredItems;
}


function PickSecondBestItem(filteredItems, isBuyingSecondMostProfitable){
    var selectedName = filteredItems.length > 0 ? filteredItems[0] : null;

    // If there's an item to buy and isBuyingSecondMostProfitable is true, check for the second best option
    if(selectedName && isBuyingSecondMostProfitable){
        if(filteredItems.length > 1){
            selectedName = filteredItems[1];
            //console.log("Going for the second best item");
        } else if (filteredItems.length == 1){
            selectedName = filteredItems[0];
        }
    }

    return selectedName;
}

function CreateWaitTime(inputDate, atticLastRefresh) {
    const now = TimezoneDate(new Date());
    const lastRestockTime = new Date(atticLastRefresh);

    const lastRestockMinute = lastRestockTime.getMinutes();

    const timeDifference = now - lastRestockTime;

    var extraMinutes = 0, extraSeconds = 0, minutesInterval, extraWindow = 0;
    const fourteenMinutes = 14 * 60 * 1000;

    if(timeDifference < fourteenMinutes){
        minutesInterval = 14;
        extraMinutes = 0;
        extraSeconds = 0;
    } else {
        minutesInterval = 7;
        extraMinutes = 7;
        extraSeconds = 6;
        extraWindow = -1;
    }

    var windowsPassed = Math.floor(timeDifference / (minutesInterval * 60 * 1000)) + 1 + extraWindow;

    const windowStartTime = new Date(lastRestockTime);
    const windowEndTime = new Date(lastRestockTime);

    const secondsToAdd = minutesInterval === 14 ? 10 : 4;

    windowStartTime.setMinutes(lastRestockMinute + minutesInterval * windowsPassed + extraMinutes);
    windowStartTime.setSeconds(lastRestockTime.getSeconds() + 1 * windowsPassed);

    windowEndTime.setMinutes(lastRestockMinute + minutesInterval * windowsPassed + extraMinutes);
    windowEndTime.setSeconds(lastRestockTime.getSeconds() + secondsToAdd * windowsPassed + extraSeconds);

    // Check if the current time is after the end of the current window
    if(now.getTime() >= windowEndTime.getTime()){
        // Move to the next window
        windowsPassed++;
        windowStartTime.setMinutes(lastRestockMinute + minutesInterval * windowsPassed + extraMinutes);
        windowStartTime.setSeconds(lastRestockTime.getSeconds() + (1 * windowsPassed) - 0.5);
        
        windowEndTime.setMinutes(lastRestockMinute + minutesInterval * windowsPassed + extraMinutes);
        windowEndTime.setSeconds(lastRestockTime.getSeconds() + secondsToAdd * (windowsPassed + 1) + extraSeconds);
    }

    return [windowStartTime, windowEndTime];
}


function TimezoneDate(time){
    return new Date(moment(time).tz("America/Los_Angeles").format("YYYY-MM-DD HH:mm:ss"));
}


//// AutoBuyers' Visual Functions;


var bannerElementID = "qpkzsoynerzxsqw";

async function DisplayAutoBuyerBanner(isAlmostAbandonedAttic = false) {
    var isBannerVisible = await getVARIABLE("SHOULD_SHOW_BANNER");
    
    if(!isBannerVisible) return;

    // Creating the banner element;
    const bannerElement = document.createElement("div");
    bannerElement.innerText = "Autobuyer Running";
    bannerElement.id = bannerElementID;

    document.body.appendChild(bannerElement);
    UpdateElementStyle(isAlmostAbandonedAttic);
}

function UpdateElementStyle(isAlmostAbandonedAttic) {
    const topPosition = isAlmostAbandonedAttic ? "0" : "68px";
    
    const style = `
        color: white;
        width: 100%;
        position: fixed;
        height: 35px;
        top: ${topPosition};
        left: 0;
        z-index: 11;
        pointer-events: none;
        text-align: center;
        line-height: 35px;
        font-size: 15px;
        font-family: Verdana, Arial, Helvetica, sans-serif;
        background-color: rgba(0, 0, 0, .8);
        font-weight: bold;
        text-overflow: ellipsis;
        white-space: nowrap;
        overflow: hidden;
    `;

    AddCSSStyle("#" + bannerElementID + " {" + style + "}");
}


function AddCSSStyle(bannerID) {
    const t = document.createElement("style");
    t.textContent = bannerID, document.head.append(t)
}

function UpdateBannerAndDocument(title, message) {
    UpdateBannerStatus(title), UpdateDocument(title, message, true);
}

function UpdateBannerStatus(runningStatus) {
    var bannerElement = document.getElementById(bannerElementID);

    if (bannerElement) {
        // Update the banner text with the running status
        bannerElement.innerText = "Autobuyer Running: " + runningStatus;
    }
}

// Updates the page's title;
function UpdateDocument(title, message, shouldSendMessage) {
    // Update the document title to uppercase
    chrome.storage.local.get({
        SHOULD_CHANGE_DOCUMENT_DATA: false,
    }, (function(autobuyerVariables) {
        // Update the document title to uppercase
        if(autobuyerVariables.SHOULD_CHANGE_DOCUMENT_DATA) document.title = title.toUpperCase();

        if(shouldSendMessage){
            message = `${message} - ${new Date().toLocaleString()}`;
    
            // Send a message to the Chrome runtime
            chrome.runtime.sendMessage({
                neobuyer: "NeoBuyer",
                type: "Notification",
                notificationObject: {
                type: "basic",
                title: title,
                message: message,
                iconUrl: "../../icons/icon48.png",
                },
            });
        }
    }));
}


//// AutoBuyers' Data Controlling Functions;

function GetAccountName(shopName = ''){
    var accountName = "";

    if(shopName === "Attic"){
        accountName = document.querySelector(".user a:nth-of-type(1)").innerText
    } else {
        accountName = document.getElementsByClassName("nav-profile-dropdown-text")[0].innerText.split("Welcome, ")[1];
    }

    return accountName;
}

function SaveToPurchaseHistory(itemName, shopName, price, status) {
    return new Promise(async (resolve, reject) => {
        setDEFAULT("ITEM_HISTORY", []);

        var history = await getVARIABLE("ITEM_HISTORY");
        
        // Determine the current user's account
        var accountName = GetAccountName(shopName);

        var newItem = {
            "Item Name": itemName,
            "Shop Name": shopName,
            "Price": price,
            "Status": status,
            "Date & Time": new Date().toLocaleString(),
            "Account": accountName
        };
        
        //Saving the new history;
        history.push(newItem);

        setVARIABLE("ITEM_HISTORY", history);

        const isAutoSDBEnabled = await getVARIABLE("AUTOSDB_ENABLED");

        if(isAutoSDBEnabled && status == "Bought"){
            setDEFAULT("GALLERY_LIST", []);

            const database = await getVARIABLE("DATABASE"),
                  galleryList = await getVARIABLE("GALLERY_LIST");

            delete newItem["Price"];
            delete newItem["Status"];
            
            const profit = database[newItem["Item Name"]];

            if(galleryList.includes(newItem["Item Name"])){
                newItem["Deposit"] = "Gallery";
            } else if(profit <= 999999) {
                newItem["Deposit"] = "Stock";
            } else {
                newItem["Deposit"] = "Deposit";
            }

            var sdbList = await getVARIABLE("SDB_LIST"),
                sdbHistory = await getVARIABLE("SDB_HISTORY");

            setDEFAULT("SDB_LIST", []);
            setDEFAULT("SDB_HISTORY", []);

            sdbList.push(newItem);
            sdbHistory.push(newItem);

            setVARIABLE("SDB_LIST", sdbList);
            setVARIABLE("SDB_HISTORY", sdbHistory);
        }

        resolve();
    });
}

// PurchaseCaptureScreenshot(); Create a screenshot of a purchased item;
function PurchaseCaptureScreenshot(elements, itemName){
    return new Promise((resolve, reject) => {
        const container = document.createElement('div');

        // GroupElements(); Grouping the elements into one container for the screenshot;
        function GroupElements() {
            container.style.backgroundColor = "white";
            container.style.margin = 0;
            container.style.padding = 0;
    
            elements.forEach(element => {
                const clone = element.cloneNode(true);
                container.appendChild(clone);
            });
            
            const pageTitle = document.querySelector(".page-title__2020");
    
            pageTitle.parentElement.replaceChild(container, pageTitle);
            return container;
        }
    
        const todayString = new Date().toDateString();
    
        modernScreenshot.domToPng(GroupElements()).then(dataUrl => {
            const link = document.createElement('a');
            link.download = `${todayString} - ${itemName}.png`;
            link.href = dataUrl;
            link.click();
            container.remove();
        });
        
        resolve();
    });
}

async function OpenQuickstockPage(){
    const isAutoSDBEnabled = await getVARIABLE("AUTOSDB_ENABLED"),
          sdbList = await getVARIABLE("SDB_LIST");

    if(isAutoSDBEnabled && sdbList.length > 0){
        chrome.runtime.sendMessage({ action: 'OpenQuickstockPage' });
    }
}

function FormatMillisecondsToSeconds(milliseconds) {
    return (milliseconds / 1e3).toFixed(2) + " seconds"
}

function Clamp(num, min, max) {
    if (num <= min) {
        return min;
    }

    if (num >= max) {
        return max;
    }

    return num;
}

//######################################################################################################################################
// Page Error Handling;

var isInErrorPage = false;

// Handle page errors by refreshing;
function HandleServerErrors() {
    chrome.storage.local.get({
        MIN_PAGE_LOAD_FAILURES: 10000,
        MAX_PAGE_LOAD_FAILURES: 20000
    }, (function(autobuyerVariables) {
        var errorRefreshed = false;

        // Destructing the variables extracted from the extension;
        const {
            MIN_PAGE_LOAD_FAILURES: minPageReloadTime,
            MAX_PAGE_LOAD_FAILURES: maxPageReloadTime
        } = autobuyerVariables;

        const errorMessages = [
        "502 Bad Gateway",
        "504 Gateway Time-out",
        "Loading site please wait...",
        "An error occurred while processing your request.",
        "Internal Server Error",
        "Oops, no stock ID",
        "You have been directed to this page from the wrong place!"
        ];
    
        const pageText = document.body.innerText;
        
        // Page errors and captchas;
        if (errorMessages.some(message => pageText.includes(message))) {
            const indexOfMessage = errorMessages.findIndex(message => pageText.includes(message));

            
            switch(indexOfMessage){
                case 2:
                    UpdateDocument("Captcha page detected", "Captcha page detected. Pausing.", true);
                    return;
                break;

                // Oops, no stock ID;
                case 5:
                case 6:
                    window.location.href = "https://www.neopets.com/objects.phtml?type=shop&obj_type=1";
                break;

                default:
                    function RefreshWindow() {
                        if (!errorRefreshed) {
                            errorRefreshed = true;
                            
                            location.reload();
                        }
                    }
    
                    setTimeout(RefreshWindow, GetRandomFloat(minPageReloadTime, maxPageReloadTime));
                break;
            }
        }
        
        // Browser errors;
        else if(window.location.title == "www.neopets.com"){
            setTimeout(() => { location.reload(); }, GetRandomFloat(minPageReloadTime, maxPageReloadTime));
        }
    }));
}

// Waits for an element to appear on the page. Can search JQuery and IDs;
function WaitForElement(selector, index = 0, timeout = 5000) {
    return new Promise((resolve) => {
        const intervalId = setInterval(() => {
            let element;

            // Choosing between JQuery or ID selection;
            switch (index) {
                default:
                    element = document.querySelector(selector);
                    break;

                case 1:
                    element = document.getElementById(selector);
                    break;

                case 2:
                    // This case returns a NodeList, not a single element
                    const elements = document.querySelectorAll(selector);
                    if (elements.length > 0) {
                        element = elements[0];
                    }
                    break;

                case 3:
                    // This case returns a NodeList, not a single element
                    element = document.querySelectorAll(selector);
                    break;

                case 4:
                    const allElements = document.querySelectorAll('*');

                    for (const selectedElement of allElements) {
                        // Check if the element's text content contains the target text
                        if (selectedElement.textContent.includes(selector)) {
                            element = selectedElement;
                            break;
                        }
                    }
                break;

                case 5:
                    element = document.getElementsByClassName(selector);
                break;
            }

            if (element) {
                clearInterval(intervalId);
                clearTimeout(timeoutId);
                resolve(element); // Resolve with the found element
            }
        }, 1000);

        // Set a timeout to stop searching after the specified time
        const timeoutId = setTimeout(() => {
            clearInterval(intervalId);
            resolve(null); // Resolve with null if not found within the time limit
        }, timeout);
    });
}

async function WaitForTextContent(element, text, breakText = undefined, type = 0) {
    return new Promise((resolve) => {
        const intervalId = setInterval(() => {
            const elementText = element.textContent.trim();

            switch (type){
                case 0:
                    if(elementText === breakText){
                        clearInterval(intervalId);
                        resolve();
                    }
        
                    if (elementText === text) {
                        clearInterval(intervalId);
                        resolve();
                    }
                break;

                case 1:
                    if (elementText != text) {
                        clearInterval(intervalId);
                        resolve();
                    }
                break;
            }
        }, 1000);
    });
}

//######################################################################################################################################

// Email management;
class Email {
    constructor(Entry, ID, Author, Date, Subject, Title, Contents, Read){
        this.Entry = Entry;
        this.ID = ID;
        this.Author = Author;
        this.Date = Date;
        this.Subject = Subject;
        this.Title = Title;
        this.Contents = Contents;
        this.Read = Read;
    }
}

//######################################################################################################################################


//Page management;
function ShowOrHideLoading(status){
    const loadingIcon = document.getElementById("loading");

    if(status.includes("Complete") || status.includes("Inactive") || 
       status.includes("Updated!") || status.includes("Sleep") || 
       status.includes("Stopped") || status.includes("Cancelled") ||
       status.includes("Usable")){
        loadingIcon.style.display = 'hidden';
        loadingIcon.style.width = '0%';
        loadingIcon.style.height = '0%';
    } else {
        loadingIcon.style.visibility = 'visible';
        loadingIcon.style.width = '4%';
        loadingIcon.style.height = '4%';
    }
}


//######################################################################################################################################

function GenerateMouseEvent(){
    return new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
        view: window,
        button: 0
    });
}

function GetRandomInt(min, max) { return Math.floor(Math.random() * (max - min + 1) + min); }

function GetRandomIntExclusive(min, max) { return Math.floor(Math.random() * (max - min) + min); }

function GetRandomFloat(min, max) { return Math.random() * (max - min + 1) + min; }

function GetRandomFloatExclusive(min, max) { return Math.random() * (max - min) + min; }


// Number with NP at the end;
function FormatNPNumber(input) {
    return input.toLocaleString() + " NP"
}

function ParseNPNumber(input){
    return Number(input.replace(/[^\d.-]/g, ''));
}

//If a value is NaN or not, then it'll display one option or the other;
function CheckIsNaNDisplay(input, outputTrue, outputFalse){
    return isNaN(input) ? outputTrue : outputFalse;
}

function PageIncludes(input){
    return document.body.innerText.includes(input);
}

// Waits 'X' amount of milliseconds. 'await Sleep(min, max)';
function Sleep(min, max, showConsoleMessage = true) {
    const milliseconds = GetRandomFloat(min, max);
    //if(showConsoleMessage) console.log(`Sleeping for ${milliseconds / 1000} seconds...`, min, max);
    return new Promise(resolve => setTimeout(resolve, milliseconds));
}

function Sleep(sleepTime) {
    return new Promise(resolve => setTimeout(resolve, sleepTime));
}

//######################################################################################################################################

//Charts

function ShowAndHideTabs(tabsToShow, tabsToHide){
    tabsToHide.forEach(function(id){
        var hide = document.getElementById(id);
        hide.style.display = 'none';
    });

    tabsToShow.forEach(function(id){
        var show = document.getElementById(id);
        show.style.display = 'initial';
    });
}

function ShowAndHideElements(tabsToShow, tabsToHide){
    tabsToHide.forEach(function(element){
        element.style.display = 'none';
    });

    tabsToShow.forEach(function(element){
        element.style.display = 'initial';
    });
}


// Function to separate the dataset by month and year
function FormatDatasetByMonthAndYear(dataset, monthIndex) {
    var separatedData = {};
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

    // Iterate over each entry in the dataset
    dataset.forEach(function(entry) {
        // Splitting the date;
        var dateParts = entry['Date & Time'].split('/');
        var year = parseInt(dateParts[2], 10);
        var month = parseInt(dateParts[0], 10) - 1;
        var key = months[month] + " " + year;
        
        // Initialize an array for the key if it doesn't exist
        if (!separatedData[key]) {
            separatedData[key] = [];
        }

        // Push the entry to the corresponding array
        separatedData[key].push(entry);
    });

    return separatedData;
}

const showEntries = 15;

// Format for the percentage datalabels in the charts;
function FormatDatalabelsOptions(){
    return options = {
        tooltips: {
            enabled: false
        },
        plugins: {
            datalabels: {
            formatter: (value, ctx) => {
                const datapoints = ctx.chart.data.datasets[0].data
                const total = datapoints.reduce((total, datapoint) => total + datapoint, 0)
                const percentage = value / total * 100
                return percentage.toFixed(2) + "%";
            },
            color: '#fff',
            backgroundColor: 'rgba(3, 169, 244, 0.5)',
            borderColor: ['rgba(3, 169, 244, 0.6)'],
            borderRadius: 5,
            borderWidth: 2,
            font: {
                weight: 'bold',
                family: "Cafeteria",
                size: 20,
            },
            }
        }
    };
}

var notEnoughData = "Additional data is necessary for analytics to operate effectively...";
var chartSize = "400px";

// Create a chart with datalabels;
function CreateChartWithLabels(id, type, labels, data, options){
    const canvas = document.getElementById(id),
    context = canvas.getContext("2d");

    if(!CheckIfEnoughData(canvas, data)) return false;

    new Chart(context, {
        type: type,
        data: {
            labels: labels,
            datasets: [
                {
                    data: data,
                    backgroundColor: GenerateRGBAArray(labels.length),
                    borderColor: ['rgba(255, 255, 255, 1)'],
                    borderWidth: 3
                }
            ]
        },
        options: options,
        plugins: [ChartDataLabels],
    });

    return true;
}

// Create a Bar chart;
function CreateBarChart(id, type, labels, data, options, datasetName = "Data") {
    const canvas = document.getElementById(id),
    context = canvas.getContext("2d");

    if(!CheckIfEnoughData(canvas, data)) return false;

    var datasets = []; // Array to store datasets

    // Iterate over each pet name and create a dataset
    labels.forEach(function(label, index) {
        var dataset = {
            label: label,
            backgroundColor: CalculateColorInIndex(index, labels.length),
            data: [data[index]]
        };
        datasets.push(dataset);
    });
    
    new Chart(context, {
        type: type,
        data: {
            labels: [datasetName],
            datasets: datasets // Use the dynamically created datasets
        },
        options: options
    });

    return true;
}

// Create a Bar chart;
function CreateTimelineChart(id, labels, data, datasetName = "Data") {
    const canvas = document.getElementById(id),
    context = canvas.getContext("2d");

    if(!CheckIfEnoughData(canvas, data)) return false;

    var chartData = { labels: labels, datasets: [] };
    
    // Create a single dataset containing all the data points
    var dataset = {
        label: datasetName,
        data: data,
        borderColor: CalculateColorInIndex(0, 1), // Assuming you want a single color for all data points
        backgroundColor:  CalculateColorInIndex(0, 1),
        borderWidth: 3,
        fill: false
    };

    chartData.datasets.push(dataset);

    // Set up Chart.js with a line chart configuration
    new Chart(context, {
        type: 'line',
        data: chartData,
        options: {
            responsive: true,
            title: {
                display: true,
                text: 'Data Occurrences Timeline'
            },
        }
    });

    return true;
}

// Generate a RGBA array for charts that require a color array to function;
function GenerateRGBAArray(divisions) {
    var rgbaArray = [];

    if(divisions == 1) return ["rgba(3, 169, 244, 1)"]

    for (var i = 0; i < divisions; i++) {
        rgbaArray.push(CalculateColorInIndex(i, divisions));
    }

    return rgbaArray;
}

// Based on an input index, it returns a color based on a base color;
function CalculateColorInIndex(index, divisions){
    if(divisions == 1) return ["rgba(3, 169, 244, 1)"]

    var alpha = 1 - (index / (divisions - 1)) * 0.8;
    return `rgba(${[3, 169, 244].join(', ')}, ${alpha.toFixed(1)})`;
}

// Resize the chart in case of page size changes in an interval;
function ResizeChartInterval(id, sizeX, sizeY = ""){
    ResizeChart(id, sizeX, sizeY);

    var hasUpdated = false;

    setInterval(function(){
        hasUpdated = ResizeChart(id, sizeX, sizeY, hasUpdated);
    }, 100);
}

function ResizeChart(id, sizeX, sizeY = "", hasUpdated) {
    var canvas = document.getElementById(id);
    canvas.style.width = sizeX;

    if (sizeY == "") {
        canvas.style.height = sizeX;
    } else {
        canvas.style.height = sizeY;
    }

    // Get the Chart.js instance associated with the canvas
    if(!hasUpdated){
        var chartInstance = Chart.getChart(id);

        if (chartInstance) {
            chartInstance.resize();
            chartInstance.update();
        }

        return true;
    }

    return true;
}

function CheckIfEnoughData(canvas, data){
    if(AreAllZeroes(data)){
        canvas.parentElement.textContent = notEnoughData;
        canvas.remove();
        return false;
    }

    return true;
}

function AreAllZeroes(data){
    return data.every(datapoint => datapoint === 0)
}

//######################################################################################################################################


function EncryptData(input, key, counter = 5){
    var keyArray = StringToArray32(key);
    var textBytes = aesjs.utils.utf8.toBytes(input);
    
    // Encrypting the data;
    var aesCtr = new aesjs.ModeOfOperation.ctr(keyArray, new aesjs.Counter(counter));
    var encryptedBytes = aesCtr.encrypt(textBytes);
    var encryptedHex = aesjs.utils.hex.fromBytes(encryptedBytes);

    return encryptedHex;
}

function DecryptData(encryptedMessage, key, counter = 5){
    var keyArray = StringToArray32(key);

    // Converting the data to bytes for decrypting;
    var encryptedBytes = aesjs.utils.hex.toBytes(encryptedMessage);
    
    // Decrypting instance;
    var aesCtr = new aesjs.ModeOfOperation.ctr(keyArray, new aesjs.Counter(counter));
    var decryptedBytes = aesCtr.decrypt(encryptedBytes);
    
    // Convert our bytes back into text;
    var decryptedText = aesjs.utils.utf8.fromBytes(decryptedBytes);

    return decryptedText;
}

function StringToArray32(inputString) {
    // Ensure input string is at least 32 characters long
    while (inputString.length < 32) {
        inputString += inputString; // Pad with itself if shorter
    }
    // Truncate to 32 characters if longer
    inputString = inputString.substring(0, 32);

    // Convert each character to ASCII and store in the array
    const array32 = [];
    for (let i = 0; i < inputString.length; i++) {
        array32.push(inputString.charCodeAt(i));
    }
    
    return array32;
}

function InjectExternalScript(url) {
    var script = document.createElement('script');
    script.src = url;
    script.async = true;
    document.body.appendChild(script);

    return script;
}

const updateAlert = "AutoBuyer+ Update Required. Navigate to the AutoBuyer+ Github page and update the extension. All processes will stop until you download the latest version of AutoBuyer+...";
const updateBanner = "AutoBuyer+ Update Required";

/*
function ExtensionDeactivate(){
	var extensionId = chrome.runtime.id;

	chrome.management.setEnabled(extensionId, false, () => {
		if (chrome.runtime.lastError) {
			console.error(chrome.runtime.lastError);
		} else {
			console.log("Extension disabled");
		}
	});
}
*/


//######################################################################################################################################

// CheckIfUserLoadedPets(); Loading pets & GUI Load Pets Button;
async function CheckIfUserLoadedPets(){
    setDEFAULT("BD_WEAPONS", {});
    setDEFAULT("OWNED_PETS", []);
    setDEFAULT("TVW_BATTLES", []);
    setDEFAULT("TVW_BATTLE_SELECTED", "");

    var ownedPets = await getVARIABLE("OWNED_PETS"),
        weaponData = await getVARIABLE("BD_WEAPONS"),
        battlesData = await getVARIABLE("TVW_BATTLES");

    const ownedPetsSelector = document.getElementById("OWNED_PETS"),
          battlesSelector = document.getElementById("TVW_BATTLE"),
          bdPetSelector = document.getElementById("BD_OWNED_PETS");

    if(ownedPetsSelector){
        if(ownedPets.length == 0){
            var loadPetDataButton = $("#loadPetData").clone();
            loadPetDataButton.find(':first-child').removeClass("autobuyerButton").addClass("volunteerButton");
            loadPetDataButton.on('click', StartLoadOwnedPetsProcess);
    
            ownedPetsSelector.parentNode.appendChild(loadPetDataButton[0]);
            ownedPetsSelector.remove();
        }
    }

    if(battlesSelector){
        if(battlesData.length == 0){
            var loadBattleDataButton = $("#load-battle-data").clone();
            loadBattleDataButton.find(':first-child').addClass("volunteerButton");
            loadBattleDataButton.on('click', StartLoadBattlesAvailable);
    
            battlesSelector.parentNode.appendChild(loadBattleDataButton[0]);
            battlesSelector.remove();
        }
    }

    if(bdPetSelector){
        var weaponDataSize = Object.keys(weaponData).length;

        if(weaponDataSize == 0){
            var loadWeaponDataButton = $("#load-pet-weapons").clone();
            loadWeaponDataButton.find(':first-child').removeClass("autobuyerButton").addClass("volunteerButton");
            loadWeaponDataButton.on('click', function(){
                if(ownedPets.length == 0) StartLoadOwnedPetsProcess();
                StartLoadPetsWeaponsProcess();
            });
    
            bdPetSelector.parentNode.appendChild(loadWeaponDataButton[0]);
            bdPetSelector.remove();
        }
    }
}

function StartLoadOwnedPetsProcess(){
    setVARIABLE("IS_LOADING_PETS", true);
    chrome.tabs.create({ url: "https://www.neopets.com/quickref.phtml", active: true });

    setInterval(async function(){
        ownedPets = await getVARIABLE("OWNED_PETS");

        if(ownedPets.length > 0){
            location.reload();
        }
    }, 1000);
}

function StartLoadVolunteeringShiftsProcess(){
    setVARIABLE("IS_LOADING_SHIFTS", true);
    chrome.tabs.create({ url: "https://www.neopets.com/hospital/volunteer.phtml", active: true });

    setInterval(async function(){
        shifts = await getVARIABLE("VOLUNTEER_SHIFTS");
        
        if(shifts.length > 0){
            location.reload();
        }
    }, 1000);
}

function StartLoadBattlesAvailable(){
    setVARIABLE("TVW_AUTOBD_ENABLED", true);

    setInterval(async function(){
        battlesData = await getVARIABLE("TVW_BATTLES");

        if(battlesData.length > 0){
            location.reload();
        }
    }, 1000);
}

function StartLoadPetsWeaponsProcess(){
    setVARIABLE("BD_WEAPONS", {});
    setVARIABLE("IS_LOADING_BD_WEAPONS", true);
    chrome.tabs.create({ url: "https://www.neopets.com/dome/neopets.phtml", active: true });

    setInterval(async function(){
        weaponData = await getVARIABLE("BD_WEAPONS");

        if(Object.keys(weaponData).length > 0){
            location.reload();
        }
    }, 1000);
}

async function BattledomeData(){
    CheckIfUserLoadedPets();

    // Navigating to Quickref Page for Pet Loading;
    const loadPetsButton = document.getElementById("loadPetData");
    loadPetsButton.addEventListener('click', StartLoadOwnedPetsProcess);

    const loadWeaponsButton = document.getElementById("load-pet-weapons");
    loadWeaponsButton.addEventListener('click', StartLoadPetsWeaponsProcess);

    ProcessPetData("BD_PET", "BD_OWNED_PETS");

    var bdPetName = await getVARIABLE("BD_PET");

    const weaponNameDisplay = document.querySelector(".battledome-div").cloneNode(true);

    const bdPetSelector = document.getElementById("BD_OWNED_PETS");

    setDEFAULT("BD_WEAPONS", {});

    const weaponContainerElement = document.querySelector(".weapon-container"),
          abilityContainerElement = document.querySelector(".ability-container"),
          weaponData = await getVARIABLE("BD_WEAPONS");

    if(Object.keys(weaponData).length == 0) return;

    if(bdPetName == "") return;

    var weapons = weaponData[bdPetName]["Weapons"],
        abilities = weaponData[bdPetName]["Abilities"];

    LoadPetBattledomeData();

    bdPetSelector.addEventListener("change", async function(){
        setVARIABLE("BD_PET", bdPetSelector.value);

        bdPetName = await getVARIABLE("BD_PET");

        weapons = weaponData[bdPetName]["Weapons"],
        abilities = weaponData[bdPetName]["Abilities"];

        LoadPetBattledomeData();
    });

    function LoadPetBattledomeData(){
        weaponContainerElement.innerHTML = "";

        LoadBattledomeDataOnGUI(weapons, weaponContainerElement);

        abilityContainerElement.innerHTML = "";

        LoadBattledomeDataOnGUI(abilities, abilityContainerElement);

        function LoadBattledomeDataOnGUI(data, parent){
            data = data.filter(x => x != "");

            if(data.length == 0){
                CreateWeaponField("Nothing");
                return;
            }

            for(var i = 0; i < data.length; i++){
                const dataPoint = data[i];

                if(dataPoint == "Nothing") continue;
    
                CreateWeaponField(dataPoint);
            }

            function CreateWeaponField(dataPoint){
                const input = weaponNameDisplay.cloneNode(true);
        
                input.querySelector("input").value = dataPoint;
    
                parent.appendChild(input);
            }
        }
    }

    const attackSelectors = document.querySelectorAll(".attack-dropdown");

    LoadTurnOptionSelection(attackSelectors, weapons);

    const abilitySelectors = document.querySelectorAll(".ability-dropdown");

    LoadTurnOptionSelection(abilitySelectors, abilities);

    function LoadTurnOptionSelection(element, dataset){
        dataset.unshift("Nothing");

        element.forEach(function(select){
            for(var i = 0; i < dataset.length; i++){
                const option = dataset[i];

                if(option == "") continue;

                const optionElement = document.createElement('option');
    
                optionElement.value = option;
                optionElement.text = option;
                select.appendChild(optionElement);
            };
        });
    }
}

// Handle the Volunteer information in the GUI to translate it to the Volunteer Centre page.
async function ProcessPetData(variableName, selectorName) {
    const petSelector = document.querySelector(`#${selectorName}`),
          ownedPets = await getVARIABLE("OWNED_PETS");
    
    setDEFAULT(variableName, "");

    var selectedPet = await getVARIABLE(variableName);

    petSelector.addEventListener("change", function(event){
        setVARIABLE(variableName, petSelector.value);
    });

    // LoadOwnedPets(); Loading the information in the pet select fields;
    async function LoadOwnedPets() {
        // Loading the pet names in the pet select fields;
        ownedPets.forEach(petName => {
            const optionElement = document.createElement("option");
            optionElement.value = petName;
            optionElement.textContent = petName;
            
            petSelector.appendChild(optionElement);
        });

        if(selectedPet == ""){
            selectedPet = petSelector.value;
            setVARIABLE(variableName, selectedPet);
        } else {
            petSelector.value = selectedPet;
        }
    }
    
    LoadOwnedPets();
}


//######################################################################################################################################

function CloseWindow(){
    if(window.history.length == 1){
        window.close();
    }
}

async function IsAutoDailyEnabled(){
    setDEFAULT("AUTODAILY_ENABLED", false);
    const isAutoDailyEnabled = await getVARIABLE("AUTODAILY_ENABLED");

    return isAutoDailyEnabled;
}

function GeneralStorePushForm(){
    // Select the form element
    const form = document.querySelector('#content > table > tbody > tr > td.content > form');
        
    const oii = form.querySelector("input[type=hidden]:nth-child(1)");
    
    oii.value = "81";
    
    form.submit();
}

async function InventoryConsumeItem(itemName, action, hasQuestFlag, itemNameFlag, hrefIfFails){
    const items = await WaitForElement(".grid-item", 3),
          filteredItem = Array.from(items).filter(item => item.innerText.includes(itemName))[0];

    if(filteredItem){
        const divItem = filteredItem.querySelector("div");
        divItem.click();

        const actionMenu = await WaitForElement("iteminfo_select_action", 1),
              selectMenu = actionMenu.querySelector("select"),
              options = selectMenu.querySelectorAll("option"),
              optionsArray = Array.from(options);

        const selectedPet = await getVARIABLE("DESTINATION_PET"),
              filteredOption = optionsArray.filter(value => value.innerText.includes(action) && value.innerText.includes(selectedPet))[0],
              optionIndex = optionsArray.indexOf(filteredOption);

        selectMenu.selectedIndex  = optionIndex;

        const submitButton = await WaitForElement("#iteminfo_select_action > div");
        submitButton.classList.remove("disabledButton");
        submitButton.click();

        setVARIABLE(hasQuestFlag, false);
        setVARIABLE(itemNameFlag, "");
        window.location.href = "https://www.neopets.com/questlog/";
    } else {
        setVARIABLE(hasQuestFlag, true);
        setVARIABLE(itemNameFlag, "");
        window.location.href = hrefIfFails;
    }
}

function IsToday(dateToCheck) {
    // Get the current date
    let today = new Date();

    // Get the year, month, and day for the current date
    let todayYear = today.getFullYear();
    let todayMonth = today.getMonth();
    let todayDay = today.getDate();

    // Get the year, month, and day for the date to check
    dateToCheck = new Date(dateToCheck);
    let checkYear = dateToCheck.getFullYear();
    let checkMonth = dateToCheck.getMonth();
    let checkDay = dateToCheck.getDate();

    // Compare year, month, and day
    return todayYear === checkYear && todayMonth === checkMonth && todayDay === checkDay;
}

//######################################################################################################################################

function LoadDataInSelect(selectElement, data, selectedOption = ""){
    data.forEach(function(value){
        const optionElement = document.createElement("option");
              optionElement.value = value;
              optionElement.textContent = value;

        selectElement.appendChild(optionElement);
    });

    if(selectedOption != "") selectElement.value = selectedOption;
}


function ActivateExpandCollapseListeners(buttonSelector, classSelector){
    const button = document.getElementById(buttonSelector);

    button.addEventListener("click", function(){
        const dataRows = document.querySelectorAll(".data-point");

        dataRows.forEach(function(element){
            if(!element.classList.contains("hidden")){
                const button = element.querySelector(classSelector);

                button.click();
            }
        });
    });
}