// Get the URL of the current script
const scriptUrl = document.currentScript.src;

// Extract the part before "src"
const srcPath = scriptUrl.substring(0, scriptUrl.indexOf("src") + 3),
      toolbar = `${srcPath}/toolbar`,
      layout = `${toolbar}/Layout`;

// Construct URLs regardless of route;
const logoURL = `${srcPath}/logo.png`,
      shopIconURL = `${toolbar}/autobuyer.svg`,
      atticIconURL = `${toolbar}/attic.svg`,

      sdbIconURL = `${toolbar}/sdb.svg`,
      databaseIconURL = `${toolbar}/db.svg`,
      historyIconURL = `${toolbar}/history.svg`,

      swIconURL = `${toolbar}/sw.svg`,
      npIconURL = `${toolbar}/np.svg`,
      tpIconURL = `${toolbar}/tp.png`,

      exploreIconURL = `${toolbar}/explore.svg`,
      autoDailyIconURL = `${toolbar}/autodaily.svg`,
      autoBDIconURL = `${toolbar}/bd.svg`,
      autoTVWIconURL = `${toolbar}/tvw.png`,

      toolsIconURL = `${toolbar}/tools.svg`,
      restockListIconURL = `${toolbar}/restocklist.svg`,
      configPresetsIconURL = `${toolbar}/suggestions.svg`,
      faqsIconURL = `${toolbar}/faqs.svg`,
      bugReportIconURL = `${toolbar}/bugreport.png`,
      suggestionsIconURL = `${toolbar}/suggestions.svg`,

      mailIconURL = `${toolbar}/neomail.svg`,
      newMailIconURL = `${toolbar}/newneomail.svg`;

// Manual section;
const manualIconURL = `${toolbar}/mymanual-icon.svg`,
      manualContainerURL = `${layout}/Manual-tag.png`,
      manualHandleURL = `${layout}/Handle-manual.png`;

// Top right toolbar;
const experimentalIconURL = `${toolbar}/experimental.svg`,
      discordIconURL = `${toolbar}/discord.svg`,
      coffeeIconURL = `${toolbar}/coffee.svg`,
      githubIconURL = `${toolbar}/Github.svg`,
      plusCoinIconURL = `${layout}/plus-coin.svg`;

// BAI-kun;
const baiKunNeutralURL = `${layout}/emotions/Neutral.png`,
      closeIconURL = `${layout}/close.svg`,
      arrowIconURL = `${layout}/arrow.svg`;

// Styles
const layoutCSS = `${toolbar}/layout.css`;

// Links
const autoBuyerURL = `${srcPath}/options/Autobuyer/autobuyer.html`,
      autoAtticURL = `${srcPath}/options/AutoAttic/attic.html`,
      autoSDBURL = `${srcPath}/options/AutoSDB/autosdb.html`,
      autopricerURL = `${srcPath}/options/Autopricer/autopricer.html`,
      autoKQURL = `${srcPath}/options/AutoKQ/autokq.html`,
      autoDailyURL = `${srcPath}/options/AutoDaily/autodaily.html`,
      autoBDURL = `${srcPath}/options/AutoBD/autobd.html`,
      autoTVWURL = `${srcPath}/options/AutoTVW/tvw.html`,
      historyURL = `${srcPath}/options/history/history.html`,
      databaseURL = `${srcPath}/options/Database/database.html`,
      restockListURL = `${srcPath}/options/Tools/restockListGen.html`,
      configPresetsURL = `${srcPath}/options/Tools/info.html`,
      mailURL = `${srcPath}/options/Mail/mail.html`,
      layoutUrl = `${srcPath}/options/Layout/layout.html`;

// Scripts
function ExtractPageType() {
    var url = window.location.href;

    // Extracting the page's name;
    const lastIndex = url.lastIndexOf('/');
    const htmlIndex = url.indexOf('.html');
    const pageName = url.substring(lastIndex + 1, htmlIndex);
    
    return pageName;
}

const pageName = ExtractPageType();
const baseManualUrl = "https://github.com/Unovamata/AutoBuyerPlus/wiki/";
var manualReferenceUrl = "";

switch(pageName){
    case "autobuyer":
        manualReferenceUrl = baseManualUrl + "AutoBuyer";
    break;

    case "attic":
        manualReferenceUrl = baseManualUrl + "AutoAttic";
    break;

    case "autopricer":
        manualReferenceUrl = baseManualUrl + "AutoPricer";
    break;

    case "autokq":
        manualReferenceUrl = baseManualUrl + "AutoKQ";
    break;

    case "history":
        manualReferenceUrl = baseManualUrl + "History";
    break;

    case "database":
        manualReferenceUrl = baseManualUrl + "Database";
    break;

    case "restockListGen":
        manualReferenceUrl = baseManualUrl + "Restock-List-Generator";
    break;

    case "info":
        manualReferenceUrl = baseManualUrl + "Export-&-Load-Settings-Presets";
    break;

    case "mail":
        manualReferenceUrl = baseManualUrl + "Mail";
    break;
}

const toolbarHTML = 
`<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="${layoutCSS}">
    </head>
<body>

<div id="background" class="background-properties">
    <div id="background-top-shadow" class="background-properties"></div>
    <div id="background-container" class="background-properties">
        <a><img id="autobuyer-logo" class="background-properties" src=${logoURL}></a>
        <div id="background-top" class="background-properties">
            <div id="background-gradient" class="background-properties"></div>
            <div id="star-pattern" class="background-properties"></div>
        </div>
    </div>

    <div class="hover-menu text">
        <ul>
            <li>
                <a href="${autoBuyerURL}" class = "toolbar-category dropdown-category"> 
                    <img  class = "dropdown-icon" src="${shopIconURL}"> 
                    AutoBuyer+
                </a>
            </li>
            <li>
                <a href="${autoAtticURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${atticIconURL}"> 
                    AutoAttic+ 
                </a>
            </li>
        </ul>
    </div>

    <div class="hover-menu text">
        <ul>
            <li>
                <a href="${autoSDBURL}" class = "toolbar-category dropdown-category"> 
                    <img  class = "dropdown-icon" src="${sdbIconURL}"> 
                    AutoSDB 
                </a>
            </li>
            <li>
                <a href="${historyURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${historyIconURL}"> 
                    History 
                </a>
            </li>
            <li>
                <a href="${databaseURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${databaseIconURL}"> 
                    Database
                </a>
            </li>
        </ul>
    </div>

    <div class="hover-menu text">
        <ul>
            <li>
                <a href="${autopricerURL}" class = "toolbar-category dropdown-category"> 
                    <img  class = "dropdown-icon" src="${npIconURL}"> 
                    AutoPricer 
                </a>
            </li>
            <li>
                <a href="${autoKQURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${tpIconURL}"> 
                    AutoKQ 
                </a>
            </li>
        </ul>
    </div>

    <div class="hover-menu text">
        <ul>
            <li>
                <a href="${autoBDURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${autoBDIconURL}"> 
                    AutoBD 
                </a>
            </li>
            <li>
                <a href="${autoDailyURL}" class = "toolbar-category dropdown-category"> 
                    <img  class = "dropdown-icon" src="${autoDailyIconURL}"> 
                    AutoDaily 
                </a>
            </li>
            <li>
                <a href="${autoTVWURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${autoTVWIconURL}"> 
                    AutoTVW 
                </a>
            </li>
        </ul>
    </div>

    <div class="hover-menu text">
        <ul>
            <li>
                <a href="${restockListURL}" class = "toolbar-category dropdown-category"> 
                    <img  class = "dropdown-icon" src="${restockListIconURL}"> 
                    List Generator
                </a>
            </li>
            <li>
                <a href="${configPresetsURL}" class = "toolbar-category dropdown-category">
                    <img  class = "dropdown-icon" src="${configPresetsIconURL}"> 
                    Config Presets 
                </a>
            </li>
            <li>
                <div class="hover-submenu">
                    <ul>
                        <a href="https://github.com/Unovamata/AutoBuyerPlus/wiki/FAQs" rel="noopener noreferrer" target="_blank" class = "toolbar-category dropdown-category" draggable="false"> 
                            <img  class = "dropdown-icon" src="${faqsIconURL}"> 
                            FAQs 
                        </a>
                        <a href="https://github.com/Unovamata/AutoBuyerPlus/issues" rel="noopener noreferrer" target="_blank" class = "toolbar-category dropdown-category" draggable="false"> 
                            <img  class = "dropdown-icon" src="${bugReportIconURL}"> 
                            Bug Report 
                        </a>
                        <a href="https://github.com/Unovamata/AutoBuyerPlus/issues/1" rel="noopener noreferrer" target="_blank" class = "toolbar-category dropdown-category" draggable="false"> 
                            <img  class = "dropdown-icon" src="${suggestionsIconURL}"> 
                            Suggestions
                        </a>
                    </ul>
                </div>

                <a class = "toolbar-category dropdown-category"> 
                    <img  class="dropdown-icon" src="${toolsIconURL}"> 
                    Github 
                    <img  class="dropleft-arrow" draggable="false" src="../../toolbar/dropdown-arrow.png">
                </a>
            </li>
        </ul>
    </div>

    <div class="round-toolbar-button">
        <a id="plus-coins" class="toolbar-link">
            <img src="${plusCoinIconURL}">
            <a id="plus-coins-available" class="text toolbar-link">0</a>
        </a>
        <a id="github-button" class="toolbar-link" draggable="false" href="https://github.com/Unovamata/AutoBuyerPlus" target="_blank">
            <img src="${githubIconURL}">
        </a>
        <a id="coffee-button" class="toolbar-link" draggable="false" href="https://buymeacoffee.com/unovamata" target="_blank">
            <img src="${coffeeIconURL}">
        </a>
        <a id="discord-button" class="toolbar-link" draggable="false" href="https://discord.com/invite/USnT8ayRE6" target="_blank">
            <img src="${discordIconURL}">
        </a>
        <a id="experimental-button" class="toolbar-link orange-toolbar-link" draggable="false" href="https://github.com/Unovamata/AutoBuyerPlus/releases/download/0.7.30.64v/NeoBuyerExperimental.0.7.30.64v.rar" target="_blank">
            <img src="${experimentalIconURL}">
        </a>
    </div>

    <div id="baikun-speech-bubble-container" class="text">
        <a id="baikun-speech-bubble-name-handle">BAI-kun</a>
        <a id="baikun-speech-bubble">
            <div id="dialog-box"></div>
            <div id="speech-tab-container">
                <div class="tab tab-border">
                    <div class="tab-dot"></div>
                </div>
            </div>
            <div id="close-speech-bubble"><img src="${closeIconURL}"></div>
            <div id="speech-navigation">
                <img id="left-navigation" src="${arrowIconURL}">
                <img id="right-navigation" src="${arrowIconURL}">
            </div>
        </a>
    </div>
    <div id="baikun-container"></div>

    <table class="shortcut-table" height="30%">
        <tr>
            <td class="table-row-border">
                <a href="https://example.com" class="text">Link 1
                    <td class="table-row-border table-row-corner"><img src="${configPresetsIconURL}"></td>
                </a>
            </td>
        </tr>
        <tr>
            <td class="table-row-border">
                <a href="https://example.com" class="text">Link 2
                    <td class="table-row-border table-row-corner"><img src="${configPresetsIconURL}"></td>
                </a>
            </td>
        </tr>
        <tr>
            <td class="table-row-border">
                <a href="https://example.com" class="text">Link 3
                    <td class="table-row-border table-row-corner"><img src="${configPresetsIconURL}"></td>
                </a>
            </td>
        </tr>
        <tr>
            <td class="table-row-border">
                <a href="https://example.com" class="text">Link 4
                    <td class="table-row-border table-row-corner"><img src="${configPresetsIconURL}"></td>
                </a>
            </td>
        </tr>
    </table>

    <div id="background-bottom-shadow" class="text"></div>
    <div class="background-properties">
        <div id="background-bottom" class="background-properties">
            <div id="background-gradient" class="background-properties"></div>
            <div id="star-pattern" class="background-properties"></div>
            <div id="bottom-text-warning" class="text">AutoBuyer+ is not affiliated to Neopets. Names are owned by Neopets. The software is provided as-is. Use it wisely to avoid freezes with your Neopet account(s).</div>
        </div>
        
        <div id="manual-wrapper">
            <a href="${manualReferenceUrl}" target="_blank">
                <div id="manual">
                    <img id="manual-button" class="manual-scale" src="${manualContainerURL}">
                    <img id="manual-tag-handle" class="manual-scale" src="${manualHandleURL}">
                    <a class="text manual-text">Manual</a>
                </div>
        
                <img id="manual-icon" src="${manualIconURL}">
            </a>
        </div>

        <div id="version-text" class="text">0.8v</div>

        <div id="bai-kun-inventory" class="inventory-box">
            <img id="inventory-arrow" src="../../toolbar/dropdown-arrow.png">
            <div id="inventory-container" class="inventory-box">
                <div class="round-toolbar-button inventory-cell inventory-item">
                    <img src="../../toolbar/Github.svg">
                    <a class="inventory-count text">0</a>
                </div>
                <div class="round-toolbar-button inventory-cell inventory-item">
                    <img src="../../toolbar/Github.svg">
                    <a class="text inventory-count">0</a>
                </div>
                <div class="round-toolbar-button inventory-cell inventory-item">
                    <img src="../../toolbar/Github.svg">
                    <a class="text inventory-count">0</a>
                </div>
                <div class="round-toolbar-button inventory-cell inventory-item bai-kun-mood">
                    <img src="${baiKunNeutralURL}">
                </div>
                <div class="round-toolbar-button inventory-cell inventory-status-bar">
                    <div class="filling-rectangle" style="background-color: #8aff63;"></div>
                </div>
                <!--<div class="round-toolbar-button inventory-cell inventory-status-bar">
                    <div class="filling-rectangle" style="background-color: #ff7d63;"></div>
                </div>-->
                <div class="round-toolbar-button inventory-cell inventory-status-bar">
                    <div class="filling-rectangle" style="background-color: #39c5fd;"></div>
                </div>
                <div class="round-toolbar-button inventory-cell inventory-status-bar">
                    <div class="filling-rectangle" style="background-color: #ff7d63;"></div>
                </div>
            </div>
        </div>

        <div id="options-panel"></div>
    </div>
</div>
</body>
</html>`;

const saveIconURL = `${layout}/settings.svg`;

const updateHTML = `
<!DOCTYPE html>
    <html>
        <head>
            <link rel="stylesheet" href="${layoutCSS}">
        </head>

    <body>
        <div id="update-screen" class="update">
            <div id="update-gradient" class="background-properties update"></div>
            <div id="update-pattern" class="background-properties"></div>
        </div>

        <div>
            <img class="update-icon update" src="${closeIconURL}">

            <div class="update-status">
                <h1 id="update-title" class="update text"></h1>

                <div class="justified update text" id="update-message">

                </div>
            </div>

            <div class="update-options center-buttons update">
                    <a href="" target="_blank" id="download-latest"><button class="update-button">Download Latest Version</button></a>
                    <a href="https://github.com/Unovamata/AutoBuyerPlus/issues" id="update-bug-report" target="_blank"><button class="update-button">Bug Report</button></a>
                    <a href="https://github.com/Unovamata/AutoBuyerPlus/wiki/FAQs#1-how-can-i-update-autobuyer-correctly" target="_blank"><button class="update-button">How to Install</button></a>
            </div>

            <button id="download-settings-button" class="image-button text update update-image-button">
                <img src="${saveIconURL}" draggable="false">
                Download Settings
            </button>
        </div>
    
    </body>
</html>`;

var width = window.innerWidth,
    height = window.innerHeight;

ProcessToolbar();

async function ProcessToolbar(){
    // Create a container element for the off-screen rendering
    const offScreenContainer = document.createElement('div'),
        isLatest = await getVARIABLE("UPDATE_STATUS_A");

    offScreenContainer.innerHTML = toolbarHTML;

    if(!isLatest){
        offScreenContainer.innerHTML = updateHTML
        document.body.appendChild(offScreenContainer);
        try { 
            document.getElementById("ref").remove();
            document.getElementById("update-pattern").style.backgroundImage = `url(${layout}/pattern.svg)`; 
        } catch {}
        
        const latestDownloadA = document.getElementById("download-latest"),
              latestDownloadLink = await getVARIABLE("LATEST_DOWNLOAD_LINK"),
              isLatestDownloadLinkValid = latestDownloadLink != undefined || latestDownloadLink != "";

        // Automatic download;
        if(isLatestDownloadLinkValid){
            latestDownloadA.href = latestDownloadLink;
        }
        
        // Manual download;
        else {
            latestDownloadA.href = "https://github.com/Unovamata/AutoBuyerPlus/releases/latest";
        }

        const versionStatus = await getVARIABLE("UPDATE_VERSION"),
            isVersionValid = versionStatus != 'a' && versionStatus != 'b',
            isConnectivityIssue = versionStatus == 'a',
            isUnknownError = versionStatus == 'b';

        const updateTitle = document.getElementById("update-title"),
              updateMessage = document.getElementById("update-message"),
              bugReportA = document.getElementById("update-bug-report");
        
        function CreateParagraph(text){
            const p = document.createElement("p");
            p.textContent = text;

            updateMessage.appendChild(p);
        }

        if(isVersionValid) {
            updateTitle.textContent = "AutoBuyer+ Update Required";

            CreateParagraph(`You are currently using an older version of AutoBuyer+. The latest version available is ${versionStatus}v, whereas you are currently using version ${chrome.runtime.getManifest().version}v.`);
            CreateParagraph(`We advise you to update to the latest version as soon as possible. These updates contain critical fixes or optimizations that allow NeoBuyer+ to become undetectable to TNT.`);
            CreateParagraph(`Please take the necessary steps to update NeoBuyer+ to the latest version to continue enjoying its features seamlessly and securely. NeoBuyer+'s usage has been locked until said update occurs.`);
            CreateParagraph(`Thank you for your attention to this matter.`);

            bugReportA.style.display = "none";
        } 

        else if(isConnectivityIssue) {
            updateTitle.textContent = "Connectivity Issues";

            CreateParagraph(`There was an issue trying to reach out to AutoBuyer+'s version check API servers.`);
            CreateParagraph(`Ensure you have a stable internet connection and refresh the extension data in the "Extensions" Chromium page. AutoBuyer+'s usage has been locked for your safety.`);
            CreateParagraph(`Thank you for your attention to this matter.`);

            latestDownloadA.style.display = "none";
        }

        else {
            updateTitle.textContent = "Unknown Error";

            var error = await getVARIABLE("ERROR_STATUS");  

            CreateParagraph(`There was an issue while trying to initialize AutoBuyer+. Please refresh the extension context in the "Extensions" page.`);
            CreateParagraph(`Please report this bug by pasting this issue:`);
            CreateParagraph(`${error}`);
            CreateParagraph(`Thank you for your attention to this matter.`);

            latestDownloadA.style.display = "none";
        }

        const downloadSettingsButton = document.getElementById("download-settings-button");

        var AESScript = null, PresetsScript = null;

        downloadSettingsButton.addEventListener("click", function(event){
            try { 
                if(AESScript == null){
                    AESScript = InjectExternalScript(`${srcPath}/inject/AES.js`);
                    PresetsScript = InjectExternalScript(`${srcPath}/options/tools/configPresets.js`);

                    // Calling all variables of the extension;
                    chrome.storage.local.get(null, function(items) {
                        SaveData(items);
                    });

                    AESScript.remove();
                    PresetsScript.remove();
                }
            } catch {}
        });

        return;
    }

    document.body.appendChild(offScreenContainer);

    const experimentalBuildURL = await getVARIABLE("LATEST_EXPERIMENTAL_DOWNLOAD_LINK");

    document.getElementById("experimental-button").href = experimentalBuildURL;
    document.getElementById("background").style.backgroundImage = `url(${layout}/BG.png)`;
    document.getElementById("star-pattern").style.backgroundImage = `url(${layout}/pattern.svg)`;
    document.getElementById("background-bottom-shadow").style.backgroundImage = `url(${layout}/bottom-shadow.png)`;
    document.getElementById("baikun-speech-bubble-container").style.display = "none";

    const optionsPanel = document.getElementById("options-panel"),
        referenceOptionsPanel = document.getElementById("ref");

        referenceOptionsPanel.id = "options-panel";

    optionsPanel.parentElement.replaceChild(referenceOptionsPanel, optionsPanel);

    const warningBox = document.getElementById("background-bottom");

    var warningTop = warningBox.getBoundingClientRect().top,
        warningBoxFloor = 0
        displayInventory = false;

    const baikunInventory = document.getElementById("bai-kun-inventory")

    baikunInventory.remove();

    /*try {
        const arrowInventory = document.getElementById("inventory-arrow");

        // Check if the clicked element is the border
        baikunInventory.addEventListener("click", function(event){
            if (event.target === baikunInventory || event.target === arrowInventory) {
                displayInventory = !displayInventory;
                adjustMenuPosition();
            }
        });

        function adjustMenuPosition() {
            width = window.innerWidth,
            height = window.innerHeight;
                
            var arrowInventoryTop = arrowInventory.getBoundingClientRect().top;
                warningTop = warningBox.getBoundingClientRect().top;
    
            // Calculate warningBox position relative to windowHeight
            warningBoxFloor = height - warningTop + (height - warningTop) / 1.8;
    
            // Calculate adjusted bottomPosition based on displayInventory flag
            if (displayInventory) {
                baikunInventory.style.top = ``;
                baikunInventory.style.bottom = `0px`;
                arrowInventory.style.transform = 'rotate(0deg)';
            } else {
                var position = height - arrowInventoryTop + arrowInventoryTop - warningBoxFloor;
                baikunInventory.style.top = `${position}px`;
                baikunInventory.style.bottom = ``;
                arrowInventory.style.transform = "rotate(180deg)";
            }
        }
    
        setInterval(function() {
            adjustMenuPosition();
        }, 100);
    } catch {}*/

    function DrawToolbar(numTeeth, toothY, toothSpace) {
        let clipPath = 'polygon(';
        const icons = [shopIconURL, sdbIconURL, swIconURL, exploreIconURL, toolsIconURL, mailIconURL],
            hasArrow = [true, true, true, true, true, false],
            menus = document.querySelectorAll(".hover-menu");

        var currentIconIndex = 0;

        // Calculate points for each tooth
        for (let i = 0; i <= numTeeth; i++) {
            let x = (i / numTeeth) * 100;  // x coordinate in percentage
            
            // Calculate y coordinate based on tooth-y and tooth-space
            let y = (i % 2 === 0) ? '100%' : `calc(100% - (${toothY} * ${toothSpace}))`;
            
            // Append point to clipPath string
            clipPath += `${x}% ${y}`;
            
            // Add comma and space unless it's the last point
            if (i < numTeeth) {
                clipPath += ', ';
            }

            var canPlaceIcon = i % 2 == 0 && i > 8 && i < 24 && currentIconIndex < icons.length;

            if (canPlaceIcon) {
                var container = document.createElement("div"),
                    a = document.createElement("a"),
                    icon = document.createElement("img"),
                    arrow = document.createElement("img");
            
                container.className = 'navigation-container';
                container.dataset.index = currentIconIndex; // Assign index to container
                container.style.left = `${x}%`;
                container.appendChild(a);
            
                var currentIcon = icons[currentIconIndex];
            
                icon.className = 'navigation-option';
                icon.dataset.index = currentIconIndex; // Assign index to icon
                icon.src = `${currentIcon}`;
                icon.draggable = false;
                a.appendChild(icon);
            
                if (currentIcon === mailIconURL) {
                    var mailIcon = document.createElement("img");
                    mailIcon.className = 'neomail-notification';

                    mailIcon.src = newMailIconURL;

                    mailIcon.draggable = false;
                    a.appendChild(mailIcon);

                    a.href = mailURL;
                }
                
                function ToggleMenu(event) {
                    var eventType = event.type;
                    var elementUnderMouse = event.target;
                    var index = elementUnderMouse.dataset.index;
                
                    // Hide all menus if index is 4
                    if (index == 5) {
                        for (let menu of menus) {
                            menu.style.display = 'none'; // Hide all menus
                        }
                        return; // Exit function early as we don't need further processing
                    }
                
                    // Check if the event target has a valid index
                    if (index !== undefined) {
                        selectedMenu = menus[index];
                    }
                
                    if (eventType === 'mouseover') {
                        if (index !== undefined) {
                            selectedMenu.style.display = 'flex'; // Show the menu
                            selectedMenu.style.left = `${x}%`; // Adjust position if needed
                        }
                    } else if (eventType === 'mouseout') {
                        // Check if the mouse is still over the selectedMenu or its container
                        var relatedTarget = event.relatedTarget;

                        try {
                            if (!selectedMenu.contains(relatedTarget) && !container.contains(relatedTarget)) {
                                selectedMenu.style.display = 'none'; // Hide the menu
                            }
                        } catch {}
                    }
                }

                var selectedMenu = menus[currentIconIndex];

                    try {
                        selectedMenu.style.left = `${x}%`;
                        selectedMenu.style.display = 'none'; // Initially hide the menu

                        selectedMenu.addEventListener('mouseover', ToggleMenu);
                        selectedMenu.addEventListener('mouseout', ToggleMenu);
                    } catch {}
                    
                    
                    // Attach event listeners to show and hide the menu on hover
                    container.addEventListener('mouseover', ToggleMenu);
                    container.addEventListener('mouseout', ToggleMenu);

                if (hasArrow[currentIconIndex]) {
                    arrow.src = `${toolbar}/dropdown-arrow.png`;
                    arrow.className = 'dropdown-arrow';
                    arrow.dataset.index = currentIconIndex; // Assign index to arrow
                    arrow.draggable = false;
                    a.appendChild(arrow);
                }
                
                currentIconIndex++;

                document.body.appendChild(container);
            }
            
        }
        
        // Close the polygon with the bottom line
        clipPath += ', 100% 75%, 0% 75%)';
        
        return clipPath;
    }

    // Example usage:
    const numTeeth = 34;  // Number of teeth
    const toothY = '2vh';  // --tooth-y value
    const toothSpace = 1.25;  // --tooth-space value

    const clipPath = DrawToolbar(numTeeth, toothY, toothSpace);
    const backgroundContainer = document.getElementById("background-container");

    backgroundContainer.style.clipPath = clipPath;


    //////////////////////////////////////////////////////////////////////////////

    const toolbarMenuElements = document.querySelectorAll(".toolbar-category");

    toolbarMenuElements.forEach(function(icon){
        icon.addEventListener('dragstart', function(event) {
            const parentText = event.target.parentElement.textContent.trim();

            event.dataTransfer.setData('text/parent', parentText);
        });
    });

    const dropTableRows = document.querySelectorAll(".table-row-corner"),
        isWarningPage = window.location.href.includes("warning");

    if(!isWarningPage){
        LoadQuicklinks();
    } else {
        const shortcutTable = document.getElementsByClassName("shortcut-table"),
              manualWrapper = document.getElementById("manual-wrapper"),
              quicklinkToolbarButtons = document.getElementsByClassName("round-toolbar-button"),
              hoverMenus = document.getElementsByClassName("navigation-container");

        shortcutTable[0].remove();
        manualWrapper.remove();
        quicklinkToolbarButtons[0].remove();

        Array.from(hoverMenus).forEach(function(menu){
            menu.remove();
        });
    }

    function LoadQuicklinks(){
        dropTableRows.forEach(async function(row, index) {
            var quicklinks = await getVARIABLE("QUICKLINKS");
        
            CheckQuicklinkData();
        
            MatchData(quicklinks[index]);
        
            row.addEventListener('dragover', function(event) {
                event.preventDefault();
            });
            
            row.addEventListener('drop', async function(event) {
                event.preventDefault();
                
                // Get the data of the dragged element
                const data = event.dataTransfer.getData('text/parent');
        
                quicklinks = await getVARIABLE("QUICKLINKS");
        
                CheckQuicklinkData();
        
                MatchData(data);
        
                setVARIABLE("QUICKLINKS", quicklinks);
            });
        
            function MatchData(data){
                if(data.length == 0) return;
        
                const imgElement = row.querySelector("img"),
                    aElement = row.parentElement.querySelector("a");
        
                var href = "";
        
                switch(data){
                    case "AutoBuyer+":
                        MatchIconAndURL(shopIconURL);
                        href = autoBuyerURL;
                    break;
        
                    case "AutoAttic+":
                        MatchIconAndURL(atticIconURL);
                        href = autoAtticURL;
                    break;
        
                    case "AutoSDB":
                        MatchIconAndURL(sdbIconURL);
                        href = autoSDBURL;
                    break;
        
                    case "History":
                        MatchIconAndURL(historyIconURL);
                        href = historyURL;
                    break;
        
                    case "Database":
                        MatchIconAndURL(databaseIconURL);
                        href = databaseURL;
                    break;
        
                    case "AutoPricer":
                        MatchIconAndURL(npIconURL);
                        href = autopricerURL;
                    break;
        
                    case "AutoKQ":
                        MatchIconAndURL(tpIconURL);
                        href = autoKQURL;
                    break;
        
                    case "AutoDaily":
                        MatchIconAndURL(autoDailyIconURL);
                        href = autoDailyURL;
                    break;
        
                    case "AutoBD":
                        MatchIconAndURL(autoBDIconURL);
                        href = autoBDURL;
                    break;
        
                    case "AutoTVW":
                        MatchIconAndURL(autoTVWIconURL);
                        href = autoTVWURL;
                    break;
        
                    case "Restock List":
                        MatchIconAndURL(restockListIconURL);
                        href = restockListURL;
                    break;
        
                    case "Config Presets":
                        MatchIconAndURL(configPresetsIconURL);
                        href = configPresetsURL;
                    break;
                    
                    case "Github":
                        return;
                    break;
        
                    case "FAQs":
                        MatchIconAndURL(faqsIconURL);
                        href = "https://github.com/Unovamata/AutoBuyerPlus/wiki/FAQs";
                    break;
        
                    case "Bug Report":
                        MatchIconAndURL(bugReportIconURL);
                        href = "https://github.com/Unovamata/AutoBuyerPlus/issues";
                    break;
        
                    case "Suggestions":
                        MatchIconAndURL(suggestionsIconURL);
                        href = "https://github.com/Unovamata/AutoBuyerPlus/issues/1";
                    break;
                }
        
                aElement.textContent = data;
                aElement.href = href;
        
                function MatchIconAndURL(icon){
                    imgElement.src = icon;
                    quicklinks[index] = data;
                }
            }
        
            async function CheckQuicklinkData(){
                if(quicklinks == undefined){
                    setVARIABLE("QUICKLINKS", ["AutoBuyer+", "AutoAttic+", "AutoPricer", "AutoKQ"]);
                    quicklinks = await getVARIABLE("QUICKLINKS");
                }
            }
        });
    }

    //////////////////////////////////////////////////////////////////////////////

    const menuDisplayButtons = document.querySelectorAll(".image-button"),
          menuPanels = document.querySelectorAll(".right-column > div");

    function DeactivateMenuSections(selectedMenu, menuDisplayButtons){
        menuPanels.forEach(function(menu, index){
            if(index == selectedMenu){
                menu.style.display = "inline";
            } else {
                menu.style.display = "none";
            }
        });
    }

    menuDisplayButtons.forEach(function(button, index){
        button.value = index;

        DeactivateMenuSections(0);

        button.addEventListener("click", function(){
            DeactivateMenuSections(Number(button.value));

            menuDisplayButtons.forEach(function(option){
                option.classList.remove("selected-menu");
            });

            button.classList.add("selected-menu");
        });
    });

    //////////////////////////////////////////////////////////////////////////////

    const emailCheckURL = "https://raw.githubusercontent.com/Unovamata/AutoBuyerPlus/main/Autobuyer/Mail/MailDocument.html";

    CheckNewMail();

    // Checks for new NeoBuyer+ mails daily;
    function CheckNewMail(){
        // Fetching the data from the URL to check for new mails;
        fetch(emailCheckURL)
        .then(response => response.text())
        .then(async htmlContent => {
            const parser = new DOMParser();
            const githubDocument = parser.parseFromString(htmlContent, 'text/html');

            // Reading the email contents;
            var ID = githubDocument.getElementById("id").textContent,
                author = githubDocument.getElementById("author").textContent,
                date = githubDocument.getElementById("date").textContent,
                subject = githubDocument.getElementById("subject").textContent,
                title = githubDocument.getElementById("title").innerHTML,
                contents = githubDocument.getElementById("contents").innerHTML;
                read = false;
            
            var extractedEmail = new Email(0, ID, author, date, subject, title, contents, read),
                emailList = await getVARIABLE("EMAIL_LIST");

            const hasEmail = emailList.some(email => email.ID === ID);

            if (!hasEmail) {
                var skipCurrentEmail = await getVARIABLE("SKIP_CURRENT_MAIL");
                var currentIndex = await getVARIABLE("CURRENT_MAIL_INDEX");

                // If the user opted-out from receiving the current message active;
                if(ID != currentIndex){
                    setVARIABLE("SKIP_CURRENT_MAIL", false);
                    setVARIABLE("CURRENT_MAIL_INDEX", currentIndex);
                } else {
                    if(skipCurrentEmail) return;
                }

                // Notificate the user for new mails while also updating the mail list;
                extractedEmail.Entry = emailList.length + 1;
                emailList.unshift(extractedEmail);
                setVARIABLE("EMAIL_LIST", emailList);
            }
        }).catch(error => {
            console.error("An error ocurred during the execution... Try again later...", error);
        });
    }

    // Activates the red dot notification whenever a new mail arrives;
    async function ActivateNewMailNotification(){
        try{
            var emailList = await getVARIABLE("EMAIL_LIST");

            const isUnread = emailList.some(email => email.Read === false);
            var notification = document.getElementsByClassName("neomail-notification")[0];

            if(isUnread) notification.style.visibility = "visible";
            else notification.style.visibility = "hidden";
        } catch {}
    }

    setInterval(ActivateNewMailNotification, 1000);
}

//////////////////////////////////////////////////////////////////////////////