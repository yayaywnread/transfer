//////////////////////////////////////////////////////////////////////////////

ProcessBAIKun();

async function GetContainer(){
    var baiKunContainer = document.getElementById('baikun-container');

    if(baiKunContainer == null){
        await Sleep(0.05);
        baiKunContainer = await GetContainer();
    }
        
    return baiKunContainer;
}

async function ProcessBAIKun(){
    const baiKunContainer = await GetContainer();

    var canvas;

    // Scene Creation;
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, width / height, 0.1, 1000);
    camera.position.z = 6;
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });

    renderer.setSize(width, height);
    renderer.setClearColor(0x000000, 0);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1));

    // Creating the rendering canvas;
    baiKunContainer.appendChild(renderer.domElement);
    canvas = baiKunContainer.children[0];

    //////////////////////////////////////////////////////////////////////////////

    // 3D Model;
    const loader = new THREE.GLTFLoader();
    var model, boxHelper;

    const BAIkunRoute = `${layout}/BAI-kun.glb`

    loader.load(BAIkunRoute, function(gltf) {
        model = gltf.scene;

        // Center and scale the model
        const scale = 0.38;
        model.scale.set(scale, scale, scale); // Scale to 0.38
        scene.add(model);

        mixer = new THREE.AnimationMixer(model);
        gltf.animations.forEach((clip) => {
            mixer.clipAction(clip).play();
        });

        // Calculate the bounding box of the model
        /*boxHelper = new THREE.BoxHelper(model, 0xff0000); // Red color for the bounding box
        scene.add(boxHelper);*/

        // ----------------------------------------------------------------------

        // Outlines;
        const outlineGroup = new THREE.Group();
        scene.add(outlineGroup);

        // Outline Material;
        const outlineMaterial = new THREE.MeshBasicMaterial({
            color: 0x1aa4d9, // Outline color
            side: THREE.BackSide, // Render only back faces
            opacity: 1,
            transparent: true,
        });

        // Adjusting the outlines manually;
        model.traverse(function(child) {
            var isHead = child.name.includes("Head"),
                isTorso = child.name === "Torso",
                isHand = child.name.includes("Hand");
            
            // Is the child supposed to have an outline?
            if (child.isMesh && (isHead || isTorso || isHand)) {
                // Offset relative to child position
                const outlineMesh = new THREE.Mesh(child.geometry, outlineMaterial);
                const outlineOffset = new THREE.Vector3().copy(child.position);

                // Default Scale;
                var scaleXAdjustment = 0.45,
                    scaleYAdjustment = 0.45,
                    scaleZAdjustment = 0.45;

                switch (child.name){
                    case "Torso":
                        outlineOffset.y -= 0.07;
                        scaleXAdjustment = 0.44;
                        scaleYAdjustment = 0.44;
                    break;

                    case "Head":
                        outlineOffset.y -= 0.20;
                        scaleXAdjustment = 0.41;
                    break;

                    case "Hand_L":
                        outlineOffset.y -= 0.08;
                        outlineOffset.x += 0.145;
                        scaleXAdjustment = 0.48;
                        scaleYAdjustment = 0.48;
                    break;

                    case "Hand_R":
                        outlineOffset.y -= 0.08;
                        outlineOffset.x -= 0.145;
                        scaleXAdjustment = 0.48;
                        scaleYAdjustment = 0.48;
                    break;
                }

                // Injecting the model's visual properties;
                outlineMesh.position.copy(outlineOffset);
                outlineMesh.rotation.copy(child.rotation);
                outlineMesh.scale.set(
                    child.scale.x * scaleXAdjustment,
                    child.scale.y * scaleYAdjustment,
                    child.scale.z * scaleZAdjustment
                );
                
                outlineGroup.add(outlineMesh);
            }
        });

        // ----------------------------------------------------------------------

        function animate() {
            requestAnimationFrame(animate);

            // Rotate the model and outline group for some animation
            /*boxHelper.update();*/

            const easingFactor = 0.1; // Adjust this for smoother or faster transitions

            var isOnFreeMovement = !isHoldingMouse && !isStartingClickInArea;


            if(isOnFreeMovement){
                if (isOnGround) {
                    model.rotation.x = lerp(model.rotation.x, 0, easingFactor);
                    model.rotation.y = lerp(model.rotation.y, 0, easingFactor);
                    model.rotation.z = lerp(model.rotation.z, 0, easingFactor);
                } else {
                    const targetX = model.rotation.x + physics.dy / 50;
                    const targetY = model.rotation.y + physics.dx / 50;
                    const targetZ = model.rotation.z + physics.rotationAngle / 50;
            
                    model.rotation.x = lerp(model.rotation.x, targetX, easingFactor);
                    model.rotation.z = lerp(model.rotation.z, targetZ, easingFactor);
        
                    model.rotation.y = lerp(model.rotation.y, targetY, easingFactor);
                }

                function lerp(start, end, factor) {
                    factor = 1 - (1 - factor) * (1 - factor);
                    return start + (end - start) * factor;
                }
            }
            
            outlineGroup.rotation.copy(model.rotation);
            
            renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1));
            renderer.render(scene, camera);
        }

        animate();
    }, undefined, function(error) {
        console.error(error);
    });

    //////////////////////////////////////////////////////////////////////////////

    // BAI-kun Visual Parameters;

    const scale = 500, xBounds = 100, yBounds = 70;
    const physics = { x: outerWidth - 200, y: 0, dx: 0, dy: 0, rotationAngle: 0 };

    var isOnGround = false,
        groundCoordinates,
        outWidth = window.outerWidth, 
        outHeight = window.outerHeight;


    //////////////////////////////////////////////////////////////////////////////

    // Resizing the model canvas based on the display's size;
    setInterval(function() {
        if(!isHoldingMouse) ResizeModelCanvas();
    }, 15);

    window.addEventListener('resize', () => {
        if(!isHoldingMouse) ResizeModelCanvas();
    });

    const speechBubble = document.getElementById("baikun-speech-bubble"),
        nameHandle = document.getElementById("baikun-speech-bubble-name-handle");

    // Adjust the canvas size to match the bounding box dimensions
    const size = new THREE.Vector3(2, 2, 2),
        initialSizeX = size.x * 150,
        initialSizeY = size.y * 150;

    var pixelValue = (initialSizeY * -1) / 3 + (physics.y);

    function ResizeModelCanvas(){
        // Updating the display's size variables for visual fidelity later on;
        outWidth = window.outerWidth; 
        outHeight = 738; //window.outerHeight;

        const pixelRatio = window.devicePixelRatio || 1;

        renderer.setSize(initialSizeX * pixelRatio, initialSizeY * pixelRatio, false);

        const aspectRatio = size.x / size.y;
        camera.aspect = aspectRatio;
        camera.updateProjectionMatrix();

        renderer.domElement.style.height = `39.063vh`;
        renderer.domElement.style.width = `auto`;

        // Convert the model's position accurately regardless of zoom;
        pixelValue = (initialSizeY * -1) / 3 + (physics.y + 15);
        const vhValue = PXToVDisplay(pixelValue, outHeight);
        groundCoordinates = vhValue;
        
        baiKunContainer.style.bottom = `${vhValue}vh`;

        const screenWidth = window.innerWidth;
        const percentage = ((physics.x - xBounds) / screenWidth) * 100;
        baiKunContainer.style.left = `${percentage}%`;

        // ----------------------------------------------------------------------
        
        speechBubble.style.left = `${PXToVDisplay(Clamp(physics.x, 0, outWidth), outWidth)}vw`;
        speechBubble.style.bottom = baiKunContainer.style.bottom;
        nameHandle.style.left = `${PXToVDisplay(Clamp(physics.x, 0, outWidth), outWidth)}vw`;
        nameHandle.style.bottom = `${PXToVDisplay(pixelValue + 128, outHeight)}vh`;

        if(isBAISpeaking){
            speechBubble.style.opacity = 1;
            nameHandle.style.opacity = 1;
        } else {
            speechBubble.style.opacity = 0;
            nameHandle.style.opacity = 0;
        }

        ProcessBAIKunSpeech();
    }

    // PXToVDisplay(); Convert px values to vw/vh;
    function PXToVDisplay(px, size){
        return ((px) / size) * 100;
    }


    //////////////////////////////////////////////////////////////////////////////


    // Message process;

    var conversation = ["Hi, my name is BAI-kun!\nNice to meet you!"], message = "", currentMessage = "";
    var isBAISpeaking = false, isBAIDoneTalking = false;
    var timeoutId = null;

    const dialogBox = document.getElementById("dialog-box"),
          closeBubbleButton = document.getElementById("close-speech-bubble").children[0],
          tabContainer = document.getElementById("speech-tab-container"),
          tabReferences = tabContainer.querySelector(".tab"),
          navigationArrows = document.getElementById("speech-navigation");

    closeBubbleButton.addEventListener("click", function(event){ 
        clearTimeout(timeoutId);
        isBAISpeaking = false;
        isBAIDoneTalking = true;
        message = "";
        currentMessage = "";
        speechBubble.style.opacity = 0;
    });

    var tabClone = null;

    if(conversation.length > 0) ReadFirstMessage();

    function ProcessBAIKunSpeech(){
        if(tabClone == null){
            tabClone = tabContainer.querySelector(".tab").cloneNode();
            isBAISpeaking = true;
        }

        if(conversation.length == 1){
            tabContainer.innerHTML = "";
            navigationArrows.style.display = "none";
        } else {
            navigationArrows.style.display = "block";
        }

        isBAISpeaking = message != "";

        if(!isBAISpeaking) return;

        dialogBox.textContent = currentMessage;

        if(currentMessage.length < message.length){
            currentMessage += message[currentMessage.length];
            isBAIDoneTalking = false;
        } else {
            if(!isBAIDoneTalking){
                isBAIDoneTalking = true;

                timeoutId = setTimeout(function(){
                    isBAISpeaking = false;
                    message = "";
                    currentMessage = "";
                }, 5000);
            }
        }
    }

    const tooltips = document.querySelectorAll(".tooltiptext"),
          leftArrow = document.getElementById("left-navigation"),
          rightArrow = document.getElementById("right-navigation");

    var currentIndex = 0, lastIndex = 0;
    
    tooltips.forEach(function(tooltip){
        tooltip.parentElement.addEventListener("click", function(event){
            currentMessage = "";
            isBAIDoneTalking = false;
            isBAISpeaking = true;
            clearTimeout(timeoutId);

            const messages = tooltip.querySelectorAll(".message");
            conversation = [];
            tabContainer.innerHTML = "";

            if(messages.length > 0){
                conversation.length = 0;
                currentIndex = 0;

                messages.forEach(function(topic){
                    conversation.push(topic.textContent);

                    const tabIcon = tabReferences.cloneNode(true);
                    tabContainer.appendChild(tabIcon);
                });

                SelectCurrentTab();

                ShowAndHideArrows();

                BAIKunBounce();
            } else {
                conversation.push(tooltip.textContent);

                BAIKunBounce();
            }

            ReadFirstMessage();
        });
    });

    leftArrow.addEventListener("click", ReadPastMessage);
    rightArrow.addEventListener("click", ReadNextMessage);

    function ReadFirstMessage(){
        if(conversation.length != 0){
            document.getElementById("baikun-speech-bubble-container").style.display = "block";
            message = conversation[0];
        }
    }

    function ReadNextMessage(){
        lastIndex = currentIndex;

        if(currentIndex < conversation.length - 1) currentIndex++;

        ShowAndHideArrows();

        ResetMessage();
    }

    function ReadPastMessage(){
        lastIndex = currentIndex;

        if(currentIndex > 0) currentIndex--;

        ShowAndHideArrows();

        ResetMessage();
    }

    function ResetMessage(){
        if(lastIndex != currentIndex){
            message = conversation[currentIndex];
            currentMessage = "";
            clearTimeout(timeoutId);
        } 

        SelectCurrentTab();
    }

    function ShowAndHideArrows(){
        if(currentIndex > 0) leftArrow.style.opacity = "1";
        else leftArrow.style.opacity = "0";

        if(currentIndex < conversation.length - 1) rightArrow.style.opacity = "1";
        else rightArrow.style.opacity = "0";
    }

    function SelectCurrentTab(){
        const tabDots = document.querySelectorAll(".tab-dot");

        tabDots.forEach(function(tab, index){
            if(index != currentIndex) {
                tab.parentElement.classList.remove("tab-border");
            } else {
                tab.parentElement.classList.add("tab-border");
            }
        });

        BAIKunBounce();
    }



    //////////////////////////////////////////////////////////////////////////////

    // Gravity Math;
    const gravity = 0.2;
    const damping = 0.99;

    let startX, startY;

    // Function to update ball positions
    function UpdateGravity() {
        physics.dy -= gravity; // Apply gravity on the object;

        if(Math.abs(physics.dx) <= 0.2) physics.dx = 0;
        if(Math.abs(physics.dy) <= 0.19) physics.dy = 0;

        // Update position based on acceleration;
        physics.x += physics.dx;
        physics.y += physics.dy;

        // Damping for wall bouncing and deceleration;
        physics.dx *= damping;
        physics.dy *= damping;

        // Check for collisions with walls and reverse velocity if collided;
        if (physics.x < 0) {
            physics.dx = Math.abs(physics.dx);
        }

        if (physics.x > outWidth) {
            physics.dx = -Math.abs(physics.dx);
        }

        if (physics.y + yBounds > outHeight) {
            physics.dy = -Math.abs(physics.dy);
        }

        if (physics.y < groundCoordinates) {
            physics.y = groundCoordinates;
            physics.dy = Math.abs(physics.dy);
        }

        // Floor the y coordinate for the model to not go OoB;
        physics.x = Clamp(physics.x, 0, outWidth);
        physics.y = Clamp(physics.y, groundCoordinates, outHeight);

        // Angle * Velocity;
        let targetAngle = Math.atan2(physics.dy, physics.dx);

        // Smooth the animation;
        const easingFactor = 0.2;
        physics.rotationAngle = physics.rotationAngle || 0;
        physics.rotationAngle += (targetAngle - physics.rotationAngle) * easingFactor;

        // Reset the rotation when the model is on the ground y;
        if(physics.y <= groundCoordinates + 10){
            physics.rotationAngle = 0;
            isOnGround = true;
        } 
        else {
            isOnGround = false;
        }
        
        if(!isHoldingMouse) baiKunContainer.style.transform = `rotate(${physics.rotationAngle}rad)`; // Rotate based on angle

        requestAnimationFrame(UpdateGravity);
    }

    UpdateGravity();

    //////////////////////////////////////////////////////////////////////////////

    // Mouse Acceleration and Model Movement;

    var isHoldingMouse = false, isStartingClickInArea = false;

    // Positioning
    var mouseX, mouseY, canvasRect;

    // Mouse Acceleration
    var time = null, lastMouseX = null, lastMouseY = null, speedX = 0, speedY = 0;

    // Threshold for detecting drag
    const dragThreshold = 20;

    function MoveWithMouse() {
        // Mouse Movement event
        document.addEventListener('mousemove', (event) => {
            mouseX = event.clientX;
            mouseY = event.clientY;
            canvasRect = canvas.getBoundingClientRect();

            // If the model is not dragged correctly, do not change its position
            if (!isHoldingMouse) return;
            if (!isStartingClickInArea) return;

            // Check if the mouse has moved more than the threshold to be considered a drag
            if (Math.abs(mouseX - startX) > dragThreshold || Math.abs(mouseY - startY) > dragThreshold) {
                if (time == null) {
                    time = Date.now();
                    lastMouseX = mouseX;
                    lastMouseY = mouseY;
                    return;
                }

                var now = Date.now(),
                    dt = now - time,
                    dx = mouseX - lastMouseX,
                    dy = mouseY - lastMouseY;

                speedX = Math.round((dx / dt * 100) / 2);
                speedY = Math.round((dy / dt * 100) / 2);

                time = now;
                lastMouseX = mouseX;
                lastMouseY = mouseY;

                // Resetting the model's physics for dragging; those get in the way
                physics.x = mouseX;
                physics.y = height - mouseY;
                physics.dx = 0;
                physics.dy = 0;
                physics.rotationAngle = 0;

                const canvasWidth = canvas.offsetWidth,
                    canvasHeight = canvas.offsetHeight;

                // Dragging the model through the page
                baiKunContainer.style.left = (mouseX - canvasWidth / 2) + 'px';
                baiKunContainer.style.bottom = (height - mouseY - (canvasHeight / 2)) + 'px';

                speechBubble.style.opacity = 0;
                nameHandle.style.opacity = 0;
            }
        });

        // Clicking event
        document.addEventListener('mousedown', function() {
            // If the model is clicked correctly, allow dragging
            if (IsClickingInArea(mouseX, mouseY, canvasRect)) {
                if (isOnGround) {
                    BAIKunBounce();
                }

                isHoldingMouse = true;
                isStartingClickInArea = true;

                startX = mouseX;
                startY = mouseY;

                time = null;
                lastMouseX = null;
                lastMouseY = null;
            }
        });

        // Mouse click up event
        document.addEventListener('mouseup', function() {
            if (isHoldingMouse && isStartingClickInArea) {
                // Check if the mouse was moved more than the threshold
                if (Math.abs(mouseX - startX) <= dragThreshold && Math.abs(mouseY - startY) <= dragThreshold) {
                    // It's a click, no velocity
                    physics.dx = 0;
                    physics.dy = 0;
                } else {
                    // It's a drag, apply launch velocity
                    physics.dx = speedX;
                    physics.dy = speedY;
                }

                time = null;
                lastMouseX = null;
                lastMouseY = null;
            }

            isHoldingMouse = false;
            isStartingClickInArea = false;
        });
    }

    // IsClickingInArea(); Checks if the user clicked the model
    function IsClickingInArea(x, y, canvasRect) {
        return x >= canvasRect.left + xBounds &&
            x <= canvasRect.right - xBounds &&
            y >= canvasRect.top + yBounds &&
            y <= canvasRect.bottom - yBounds;
    }

    function BAIKunBounce(){
        baiKunContainer.style.animation = 'none';
        baiKunContainer.focus();
        baiKunContainer.style.animation = 'squishAndStretch 0.3s linear';
    }

    MoveWithMouse();
}

//////////////////////////////////////////////////////////////////////////////